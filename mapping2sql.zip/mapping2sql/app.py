"""Mapping2SQL Chat UI — Natural language agent interface."""

import sys
import os
import re
from pathlib import Path
from datetime import datetime
import tempfile

import streamlit as st
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))

from core.parser import MappingParser
from core.generator import SQLGenerator
from core.validator import SQLValidator
from core.llm_engine import LLMEngine
from utils.connection_store import ConnectionStore
from utils.chat_history import ChatHistoryStore

# ── YAML config schema ──────────────────────────────────

CONFIG_SCHEMA = {
    "dialect": {"type": str, "allowed": ["oracle", "mysql"]},
    "naming": {
        "type": dict,
        "required": True,
        "children": {
            "keyword_case": {"type": str, "allowed": ["upper", "lower"]},
            "identifier_case": {"type": str, "allowed": ["upper", "lower", "original"]},
            "quote_identifiers": {"type": bool},
        },
    },
    "formatting": {
        "type": dict,
        "required": False,
        "children": {
            "indent": {"type": str},
            "max_line_length": {"type": int},
            "comma_style": {"type": str, "allowed": ["leading", "trailing"]},
            "each_column_newline": {"type": bool},
            "align_aliases": {"type": bool},
        },
    },
    "select_style": {
        "type": dict, "required": False,
        "children": {
            "column_per_line": {"type": bool},
            "comma_before": {"type": bool},
            "indent_columns": {"type": bool},
        },
    },
    "header_template": {"type": str, "required": False},
    "column_comment_style": {"type": str, "allowed": ["inline", "header"], "required": False},
    "join": {
        "type": dict, "required": False,
        "children": {
            "explicit_only": {"type": bool},
            "indent_on": {"type": bool},
            "each_on_newline": {"type": bool},
        },
    },
    "where": {
        "type": dict, "required": False,
        "children": {
            "each_condition_newline": {"type": bool},
            "operator_align": {"type": bool},
        },
    },
    "aggregation": {
        "type": dict, "required": False,
        "children": {
            "group_by_newline": {"type": bool},
            "having_newline": {"type": bool},
        },
    },
}


def validate_yaml_config(config: dict) -> tuple[bool, list[str]]:
    """Validate a loaded YAML config dict against the schema.

    Returns (is_valid, error_messages).
    """
    errors = []

    def _check(schema, data, path=""):
        for key, spec in schema.items():
            full = f"{path}.{key}" if path else key
            required = spec.get("required", True)
            expected_type = spec.get("type")

            if key not in data:
                if required:
                    errors.append(f"缺少必填字段: `{full}`")
                continue

            value = data[key]
            if expected_type and not isinstance(value, expected_type):
                errors.append(
                    f"`{full}` 类型错误: 期望 {expected_type.__name__}, "
                    f"实际 {type(value).__name__}"
                )
                continue

            if "allowed" in spec and value not in spec["allowed"]:
                opts = ", ".join(repr(a) for a in spec["allowed"])
                errors.append(f"`{full}` 值无效: {value!r} (允许: {opts})")

            if "children" in spec and isinstance(value, dict):
                _check(spec["children"], value, full)

    _check(CONFIG_SCHEMA, config)
    return len(errors) == 0, errors

# ── Page config ────────────────────────────────────────

st.set_page_config(
    page_title="Mapping2SQL 智能体",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS tweaks ─────────────────────────────────────────

st.markdown("""
<style>
    .stChatInput { padding: 0.5rem 0; }
    .stChatMessage { padding: 0.5rem 1rem; }
</style>
""", unsafe_allow_html=True)

# ── Session init ───────────────────────────────────────

DEFAULTS = {
    "messages": [],
    "parsed_doc": None,
    "current_file_name": None,
    "dialect": "oracle",
    "author": "DATA_TEAM",
    "validation": True,
    "conn_store": None,
    "custom_config_path": None,   # Path to user-uploaded SQL standards YAML
    "custom_config_name": None,   # Display name of the uploaded config
}

for key, val in DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = val

if st.session_state.conn_store is None:
    st.session_state.conn_store = ConnectionStore()

store = st.session_state.conn_store

if "chat_store" not in st.session_state:
    st.session_state.chat_store = ChatHistoryStore()


# ── Helpers ────────────────────────────────────────────

def get_llm() -> LLMEngine | None:
    """Build LLMEngine from active connection."""
    active = store.get_active()
    if active:
        return LLMEngine(api_key=active["api_key"],
                         base_url=(active.get("base_url") or None))
    return None


def parse_and_store(uploaded_file) -> str:
    """Parse uploaded file into session state. Returns status message."""
    suffix = Path(uploaded_file.name).suffix
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(uploaded_file.read())
        tmp_path = tmp.name

    try:
        parser = MappingParser()
        doc = parser.parse(tmp_path)
        st.session_state.parsed_doc = doc
        st.session_state.current_file_name = uploaded_file.name

        # Restore chat history for this file
        history = st.session_state.chat_store.load(uploaded_file.name)
        if history:
            st.session_state.messages = history
        else:
            st.session_state.messages = []

        if st.session_state.validation:
            validator = SQLValidator(dialect=st.session_state.dialect)
            result = validator.validate_document(doc)
            if not result.is_valid:
                return f"[OK] 解析成功, 但校验有警告: {result.message}"
            return f"[OK] 解析成功: {doc.table_count} 个表映射, {doc.total_column_count} 个字段"
        return f"[OK] 解析成功: {doc.table_count} 个表映射, {doc.total_column_count} 个字段"
    except Exception as e:
        return f"[ERR] 解析失败: {e}"
    finally:
        try:
            Path(tmp_path).unlink()
        except OSError:
            pass


def generate_sql_for_doc(sql_type: str = "all") -> tuple[dict[str, str], SQLGenerator | None]:
    """Generate SQL from the currently parsed doc. Returns (results, generator)."""
    doc = st.session_state.parsed_doc
    if not doc:
        return {}, None
    llm = get_llm()
    config_path = st.session_state.get("custom_config_path") or None
    generator = SQLGenerator(dialect=st.session_state.dialect, config_path=config_path,
                             llm_engine=llm)
    results = generator.generate(doc, sql_type=sql_type, author=st.session_state.author)
    return results, generator


def get_engine_stats(generator: SQLGenerator) -> str:
    """Return a human-readable engine stats line."""
    total_llm = total_regex = total_failed = 0
    doc = st.session_state.parsed_doc
    if not doc:
        return ""
    for tm in doc.table_mappings:
        for e in generator._build_select_expressions(tm):
            eng = e.get("engine", "regex")
            if eng == "llm":
                total_llm += 1
            elif eng == "llm_failed":
                total_failed += 1
            else:
                total_regex += 1

    parts = []
    if total_llm:
        parts.append(f"LLM: {total_llm}")
    if total_failed:
        parts.append(f"LLM失败: {total_failed}")
    parts.append(f"Regex: {total_regex}")
    return " | ".join(parts)


def build_schema_context(doc) -> str:
    """Build a compact table schema summary for LLM query generation context.

    Returns a string listing each table with its columns and types.
    """
    if not doc:
        return ""
    lines = []
    for tm in doc.table_mappings:
        src_full = f"{tm.source_schema}.{tm.source_table}" if tm.source_schema else tm.source_table
        tgt_full = f"{tm.target_schema}.{tm.target_table}" if tm.target_schema else tm.target_table
        lines.append(f"\n## {tgt_full} (source: {src_full})")
        if tm.table_comment:
            lines.append(f"  描述: {tm.table_comment}")
        if tm.filter_condition:
            lines.append(f"  过滤: {tm.filter_condition}")
        lines.append("  字段:")
        for cm in tm.columns:
            pk = " PK" if cm.is_pk else ""
            col_type = cm.target_type or cm.source_type or ""
            comment = f" -- {cm.comment}" if cm.comment else ""
            lines.append(f"    {cm.target_column} {col_type}{pk}{comment}")
    return "\n".join(lines)


def build_mapping_table(doc) -> str:
    """Render parsed mapping as a markdown table."""
    lines = []
    for i, tm in enumerate(doc.table_mappings):
        lines.append(f"**表映射 #{i+1}: {tm.source_table} -> {tm.target_table}** ({len(tm.columns)} 字段)")
        rows = []
        for cm in tm.columns:
            rule = cm.transform_rule or "直接映射"
            pk = "PK" if cm.is_pk else ""
            rows.append(f"| {cm.source_column} | {cm.source_type or '-'} | {cm.target_column} | {cm.target_type or '-'} | {rule} | {pk} | {cm.comment or ''} |")
        if rows:
            lines.append("| 源字段 | 源类型 | 目标字段 | 目标类型 | 转换规则 | 主键 | 备注 |")
            lines.append("|--------|--------|----------|----------|----------|------|------|")
            lines.extend(rows)
        lines.append("")
    return "\n".join(lines)


# ── Intent parser (keyword-based, no LLM required) ────

def parse_intent(user_text: str) -> dict:
    """Extract structured intent from natural language.

    Returns dict with: action, sql_type, dialect, target_table, etc.
    """
    text = user_text.lower().strip()

    intent = {
        "action": "chat",       # chat | generate | generate_query | change_dialect | download | help
        "sql_type": "all",
        "dialect": None,
        "author": None,
        "target_table": None,
    }

    # ── Free-form analytical query (complex NL → SQL, not simple mapping-based) ──
    _query_keywords = ["帮我查询", "帮我统计", "帮我分析", "帮我生成一个查询",
                       "帮我写一个查询", "帮我写查询", "帮我生成查询",
                       "写一个查询", "写查询", "生成一个查询", "生成查询",
                       "统计一下", "分析一下", "查一下",
                       "帮我找出", "帮我找", "帮我计算", "帮我算",
                       "关联", "join", "子查询", "窗口函数", "排名",
                       "环比", "同比", "top", "前", "透视",
                       "交叉", "维度", "分组统计", "占比", "比率",
                       "帮我生成一个分析", "生成分析"]
    _query_indicators = ["每个", "各种", "不同", "按", "按月", "按季度", "按年",
                         "分组", "汇总", "降序", "升序", "排名", "平均",
                         "累计", "增长率", "超过", "标记为", "风险",
                         "画像", "得分", "总分", "评分", "客户"]

    # Strong indicators: explicit query request
    if any(w in text for w in _query_keywords):
        intent["action"] = "generate_query"
    # "帮我生成XXX" — if contains analysis words and NOT DDL/DML keywords
    elif "帮我生成" in text and not any(w in text for w in ("ddl", "dml", "建表", "插入", "同步", "merge", "合并")):
        if any(w in text for w in _query_indicators + ["查询", "统计", "分析"]):
            intent["action"] = "generate_query"
    # Medium indicators: "查询/统计/分析" + analytical patterns
    elif any(w in text for w in ("查询", "统计", "分析")) and any(w in text for w in _query_indicators):
        intent["action"] = "generate_query"

    # ── Generate intent (standard mapping-based) ──
    if intent["action"] == "chat" and any(w in text for w in ("生成", "generate", "产出", "输出", "写sql", "create", "make")):
        intent["action"] = "generate"
        if any(w in text for w in ("ddl", "建表", "create table", "表结构")):
            intent["sql_type"] = "ddl"
        elif any(w in text for w in ("dml", "insert", "插入", "同步", "etl")):
            intent["sql_type"] = "dml"
        elif any(w in text for w in ("merge", "合并", "增量", "upsert")):
            intent["sql_type"] = "merge"
        elif any(w in text for w in ("query", "查询", "select")):
            intent["sql_type"] = "query"
        elif any(w in text for w in ("全部", "所有", "all", "整个")):
            intent["sql_type"] = "all"

    # ── Dialect change ──
    if any(w in text for w in ("mysql", "my sql")):
        intent["dialect"] = "mysql"
        if intent["action"] == "chat":
            intent["action"] = "change_dialect"
    elif any(w in text for w in ("oracle", "ora")):
        intent["dialect"] = "oracle"
        if intent["action"] == "chat":
            intent["action"] = "change_dialect"

    # ── Download intent ──
    if any(w in text for w in ("下载", "download", "导出", "保存")):
        intent["action"] = "download"

    # ── Help ──
    if any(w in text for w in ("帮助", "help", "说明", "怎么用", "?", "你是谁", "你能做", "功能",
                                "hello", "hi", "你好", "嗨")):
        intent["action"] = "help"

    # ── Show mapping structure ──
    if any(w in text for w in ("查看", "解析", "看看", "展示", "显示", "show", "view", "结构")):
        if intent["action"] == "chat":
            intent["action"] = "show_structure"

    return intent


# ── Sidebar (connections + settings) ───────────────────

with st.sidebar:
    st.markdown("### 🤖 Mapping2SQL")
    st.caption("Mapping 文档 → 自然语言 → SQL")

    # ── Connection status (always visible, compact) ─────
    active_conn = store.get_active()
    api_key = None
    api_base = None

    with st.container(border=True):
        if active_conn:
            api_key = active_conn["api_key"]
            api_base = active_conn.get("base_url") or None
            cols = st.columns([3, 1])
            with cols[0]:
                st.markdown(f"🟢 **{active_conn['name']}**")
            with cols[1]:
                if st.button("断开", use_container_width=True, key="disconnect_btn",
                            type="secondary"):
                    store.active_name = None
                    st.rerun()
        else:
            st.markdown("⚪ **未连接**")

    # ── Connection manager (collapsible) ─────────────────
    with st.expander("⚙️ 连接配置", expanded=(not active_conn)):
        connections = store.list_connections()

        # -- Saved connections --
        if connections:
            conn_names = [c["name"] for c in connections]
            default_idx = 0
            if active_conn:
                try:
                    default_idx = conn_names.index(active_conn["name"])
                except ValueError:
                    pass

            selected = st.selectbox(
                "已保存的连接",
                options=conn_names,
                index=min(default_idx, len(conn_names) - 1),
                key="conn_selector",
            )

            # Check if we're editing this specific connection
            editing = st.session_state.get("_editing")
            is_editing = (editing == selected)

            # -- Detail / Edit card --
            with st.container(border=True):
                conn = store.get_connection(selected)
                if conn:
                    if is_editing:
                        st.caption(f"✏️ 编辑: **{selected}**")
                        edit_name = st.text_input("名称", value=conn["name"], key="edit_name")
                        edit_key = st.text_input("API Key", value=conn["api_key"],
                                                 type="password", key="edit_key")
                        edit_base = st.text_input("Base URL", value=conn.get("base_url", ""),
                                                  placeholder="https://api.example.com", key="edit_base")

                        ce1, ce2, ce3 = st.columns(3)
                        with ce1:
                            if st.button("保存修改", use_container_width=True, key="btn_save_edit",
                                        disabled=not edit_name, type="primary"):
                                store.add_connection(name=edit_name, api_key=edit_key,
                                                    base_url=edit_base)
                                if active_conn and active_conn["name"] == selected:
                                    store.active_name = edit_name
                                st.session_state._editing = None
                                st.rerun()
                        with ce2:
                            if st.button("测试", use_container_width=True, key="btn_test_edit",
                                        disabled=not (edit_name and edit_key)):
                                tllm = LLMEngine(api_key=edit_key, base_url=(edit_base or None))
                                ok, msg = tllm.test_connection()
                                if ok:
                                    st.toast(f"✅ {msg}", icon="✅")
                                else:
                                    st.toast(f"❌ {msg}", icon="❌")
                        with ce3:
                            if st.button("取消", use_container_width=True, key="btn_cancel_edit",
                                        type="secondary"):
                                st.session_state._editing = None
                                st.rerun()
                    else:
                        # Read-only detail view
                        masked_key = conn["api_key"][:8] + "••••••••" if len(conn["api_key"]) > 8 else "••••"
                        st.caption(f"名称: **{conn['name']}**")
                        st.caption(f"API Key: `{masked_key}`")
                        st.caption(f"Base URL: `{conn.get('base_url') or '(官方)'}`")

                        cd1, cd2, cd3, cd4 = st.columns(4)
                        with cd1:
                            disabled_activate = (active_conn and active_conn["name"] == selected)
                            if st.button("激活", use_container_width=True, key="btn_activate",
                                        disabled=disabled_activate):
                                store.active_name = selected
                                st.rerun()
                        with cd2:
                            if st.button("测试", use_container_width=True, key="btn_test"):
                                tllm = LLMEngine(api_key=conn["api_key"],
                                                base_url=(conn.get("base_url") or None))
                                ok, msg = tllm.test_connection()
                                if ok:
                                    st.toast(f"✅ {msg}", icon="✅")
                                else:
                                    st.toast(f"❌ {msg}", icon="❌")
                        with cd3:
                            if st.button("编辑", use_container_width=True, key="btn_edit"):
                                st.session_state._editing = selected
                                st.rerun()
                        with cd4:
                            if st.button("删除", use_container_width=True, key="btn_delete",
                                        type="secondary"):
                                store.delete_connection(selected)
                                if st.session_state.get("_editing") == selected:
                                    st.session_state._editing = None
                                st.rerun()

            st.divider()

        # -- New connection (always a create form, never edit) --
        st.caption("+ 新增连接")
        new_name = st.text_input("名称", placeholder="例如: 公司中转站", key="nc_name")
        new_key = st.text_input("API Key", type="password", placeholder="sk-ant-...", key="nc_key")
        new_base = st.text_input("Base URL", placeholder="https://api.example.com", key="nc_base")

        c1, c2 = st.columns(2)
        with c1:
            if st.button("测试连接", use_container_width=True, key="btn_test_new",
                        disabled=not (new_name and new_key)):
                tllm = LLMEngine(api_key=new_key, base_url=(new_base or None))
                ok, msg = tllm.test_connection()
                if ok:
                    st.toast(f"✅ {msg}", icon="✅")
                else:
                    st.toast(f"❌ {msg}", icon="❌")
        with c2:
            if st.button("保存连接", use_container_width=True, key="btn_save_new",
                        disabled=not (new_name and new_key), type="primary"):
                store.add_connection(name=new_name, api_key=new_key, base_url=new_base)
                store.active_name = new_name
                st.rerun()

    # ── Generation settings (collapsible) ────────────────
    with st.expander("⚙️ 生成设置", expanded=False):
        st.session_state.dialect = st.selectbox(
            "数据库方言",
            ["oracle", "mysql"],
            index=0 if st.session_state.dialect == "oracle" else 1,
        )
        st.session_state.author = st.text_input("创建人", value=st.session_state.author)

        st.divider()

        # -- SQL coding standards config --
        st.caption("📐 SQL 编码规范")
        custom_name = st.session_state.get("custom_config_name")
        if custom_name:
            st.success(f"当前: **{custom_name}**")
        else:
            st.info("当前: **内置默认规范**")

        uploaded_config = st.file_uploader(
            "上传行内 SQL 规范文件 (.yaml)",
            type=["yaml", "yml"],
            key="config_uploader",
            label_visibility="collapsed",
        )

        if uploaded_config:
            import tempfile
            content = uploaded_config.read().decode("utf-8")
            try:
                import yaml
                config_data = yaml.safe_load(content)
                if not isinstance(config_data, dict):
                    st.error("YAML 格式错误: 顶层必须是键值对(mapping)")
                else:
                    valid, errors = validate_yaml_config(config_data)
                    if not valid:
                        st.error("配置校验失败:\n\n" + "\n\n".join(
                            f"- {e}" for e in errors))
                    else:
                        # Save to temp file
                        with tempfile.NamedTemporaryFile(
                            delete=False, suffix=".yaml",
                            mode="w", encoding="utf-8",
                        ) as tmp:
                            tmp.write(content)
                            config_tmp_path = tmp.name
                        st.session_state.custom_config_path = config_tmp_path
                        st.session_state.custom_config_name = uploaded_config.name
                        st.toast("✅ 规范文件校验通过，已生效", icon="✅")
                        st.rerun()
            except yaml.YAMLError as e:
                st.error(f"YAML 语法错误: {e}")

        if custom_name:
            if st.button("恢复默认规范", use_container_width=True, key="btn_reset_config",
                        type="secondary"):
                st.session_state.custom_config_path = None
                st.session_state.custom_config_name = None
                st.rerun()

    # ── Lineage visualization (collapsible, shown when doc parsed) ─────
    with st.expander("🔗 字段血缘", expanded=False):
        doc = st.session_state.parsed_doc
        if not doc:
            st.caption("上传 Mapping 文档后自动展示字段级血缘关系。")
        else:
            # Build a compact lineage table
            for ti, tm in enumerate(doc.table_mappings):
                src_full = f"{tm.source_schema}.{tm.source_table}" if tm.source_schema else tm.source_table
                tgt_full = f"{tm.target_schema}.{tm.target_table}" if tm.target_schema else tm.target_table
                st.caption(f"**表 #{ti+1}:** {src_full} → {tgt_full} ({len(tm.columns)} 字段)")

                # Render lineage rows in a compact table
                rows_html = []
                for ci, cm in enumerate(tm.columns):
                    rule = cm.transform_rule or "直接映射"
                    # Truncate long rules
                    rule_display = rule if len(rule) <= 30 else rule[:28] + "…"
                    rows_html.append(
                        f"<tr style='font-size:12px; border-bottom:1px solid #eee'>"
                        f"<td style='padding:2px 6px; color:#666'>{cm.source_column}</td>"
                        f"<td style='padding:2px 6px; color:#999'>→</td>"
                        f"<td style='padding:2px 6px; color:#333'>{cm.target_column}</td>"
                        f"<td style='padding:2px 6px; color:#888; font-size:11px; max-width:180px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap' title='{rule}'>{rule_display}</td>"
                        f"</tr>"
                    )
                if rows_html:
                    table_html = (
                        "<table style='width:100%; border-collapse:collapse; margin-bottom:8px'>"
                        "<thead><tr style='background:#f5f5f5; font-size:11px'>"
                        "<th style='padding:3px 6px; text-align:left'>源字段</th>"
                        "<th></th>"
                        "<th style='padding:3px 6px; text-align:left'>目标字段</th>"
                        "<th style='padding:3px 6px; text-align:left'>转换规则</th>"
                        "</tr></thead>"
                        "<tbody>" + "".join(rows_html) + "</tbody></table>"
                    )
                    st.markdown(table_html, unsafe_allow_html=True)

    st.caption(f"v1.0 | {datetime.now().year}")


# ── Main: Chat Interface ───────────────────────────────

st.title("🤖 Mapping2SQL 智能体")
st.caption("上传 Mapping 文档，用自然语言告诉我你需要什么 — DDL / DML / MERGE / 查询，Oracle / MySQL 都可以。")

# File upload area (compact, above chat)
upload_col1, upload_col2 = st.columns([3, 1])
with upload_col1:
    uploaded_file = st.file_uploader(
        "📎 上传 Mapping 文档 (.xlsx / .csv / .docx)",
        type=["xlsx", "csv", "docx"],
        label_visibility="collapsed",
        key="chat_file_uploader",
    )
with upload_col2:
    if st.session_state.parsed_doc:
        st.caption(f"📄 {st.session_state.current_file_name}")

# Process uploaded file (with dedup guard)
if uploaded_file:
    file_id = f"{uploaded_file.name}_{uploaded_file.size}"
    last_processed = st.session_state.get("_last_processed_file", "")

    if file_id != last_processed:
        st.session_state._last_processed_file = file_id

        with st.status("正在解析文档...", expanded=True) as fstatus:
            fstatus.update(label="正在读取文件结构...", state="running")
            msg = parse_and_store(uploaded_file)
            fstatus.update(label="解析完成", state="complete", expanded=False)

        st.session_state.messages.append({
            "role": "user",
            "content": f"上传了文件: {uploaded_file.name}",
        })
        st.session_state.messages.append({
            "role": "assistant",
            "content": msg,
        })
        st.session_state.chat_store.save(
            st.session_state.current_file_name, st.session_state.messages)
        st.rerun()

# ── Render chat history ──

for mi, msg in enumerate(st.session_state.messages):
    with st.chat_message(msg["role"]):
        if msg.get("_placeholder"):
            with st.spinner("正在思考..."):
                st.markdown("&nbsp;")
        else:
            st.markdown(msg["content"])
        if msg.get("sql_blocks"):
            blocks = msg["sql_blocks"]
            for bi, (name, sql) in enumerate(blocks.items()):
                st.caption(f"**{name}**")

                edit_key = f"_edit_{mi}_{bi}"
                edited_key = f"_edited_sql_{mi}_{bi}"

                if st.session_state.get(edit_key):
                    # Edit mode
                    edited_sql = st.text_area(
                        "编辑 SQL",
                        value=st.session_state.get(edited_key, sql),
                        height=min(400, max(120, sql.count("\n") * 20 + 40)),
                        key=f"ta_{mi}_{bi}",
                        label_visibility="collapsed",
                    )
                    st.session_state[edited_key] = edited_sql

                    ec1, ec2, ec3 = st.columns([1, 1, 3])
                    with ec1:
                        if st.button("完成", use_container_width=True,
                                    key=f"done_{mi}_{bi}"):
                            # Save edit back to message
                            st.session_state.messages[mi]["sql_blocks"][name] = edited_sql
                            st.session_state[edit_key] = False
                            st.rerun()
                    with ec2:
                        if st.button("取消", use_container_width=True,
                                    key=f"cancel_{mi}_{bi}", type="secondary"):
                            st.session_state[edit_key] = False
                            st.session_state[edited_key] = sql
                            st.rerun()
                    with ec3:
                        st.download_button(
                            label="⬇ 下载",
                            data=edited_sql,
                            file_name=f"{name}.sql",
                            mime="text/plain",
                            key=f"dl_edit_{mi}_{bi}",
                        )
                else:
                    # View mode
                    st.code(sql, language="sql", line_numbers=False)
                    vc_edit, vc_dl, _ = st.columns([0.8, 0.8, 3.4])
                    with vc_edit:
                        if st.button("✏️ 编辑", use_container_width=True,
                                    key=f"edit_{mi}_{bi}"):
                            st.session_state[edit_key] = True
                            st.session_state[edited_key] = sql
                            st.rerun()
                    with vc_dl:
                        st.download_button(
                            label="⬇ 下载",
                            data=sql,
                            file_name=f"{name}.sql",
                            mime="text/plain",
                            key=f"dl_{mi}_{bi}",
                        )

            # Batch download all
            if len(blocks) > 1:
                all_sql = "\n".join(
                    f"-- ==== {n} ====\n{s}\n" for n, s in blocks.items()
                )
                dl_col2, _ = st.columns([1, 4])
                with dl_col2:
                    st.download_button(
                        label="📦 下载全部",
                        data=all_sql,
                        file_name=f"mapping2sql_{len(blocks)}statements.sql",
                        mime="text/plain",
                        key=f"dl_all_{mi}",
                    )
        if msg.get("table"):
            st.markdown(msg["table"])
        if msg.get("stats"):
            st.caption(msg["stats"])

# ── Phase 2: Process pending prompt ──

_pending = st.session_state.get("_pending_prompt", None)

if _pending:
    prompt = _pending
    st.session_state._pending_prompt = None

    # Remove the placeholder message
    if st.session_state.messages and st.session_state.messages[-1].get("_placeholder"):
        st.session_state.messages.pop()

    doc = st.session_state.parsed_doc
    response = ""
    sql_blocks = None
    table_view = None
    stats = None

    try:
        with st.status("正在处理...", expanded=True) as status:
            # ── Build context for LLM ──
            context = {
                "has_file": doc is not None,
                "file_name": st.session_state.current_file_name or "",
                "table_count": doc.table_count if doc else 0,
                "column_count": doc.total_column_count if doc else 0,
                "dialect": st.session_state.dialect,
                "author": st.session_state.author,
                "history": [
                    {"role": m["role"], "content": m["content"][:200]}
                    for m in st.session_state.messages[-6:]
                ],
            }

            llm = get_llm()

            # ── Phase A: Determine what mechanical action to take ──
            # Always run keyword intent parsing (fast, reliable for commands)
            intent = parse_intent(prompt)

            # Try to enrich intent with LLM if available
            if llm and llm.is_available and intent["action"] == "chat":
                status.update(label="正在理解你的意图...", state="running")
                try:
                    llm_intent = llm.chat_intent(prompt, context)
                    if llm_intent.get("action") and llm_intent["action"] != "fallback":
                        intent = llm_intent
                except Exception:
                    pass  # Silent fallback, keyword intent already set

            # ── Phase B: Execute mechanical actions ──
            action_note = ""  # Extra context for LLM chat

            if intent["action"] == "generate":
                if doc:
                    status.update(label="正在生成 SQL 代码...", state="running")
                    sql_type = intent.get("sql_type", "all")
                    sql_blocks, gen = generate_sql_for_doc(sql_type)
                    if sql_blocks:
                        type_label = {"ddl": "DDL", "dml": "DML", "merge": "MERGE", "query": "Query", "all": "全部"}[sql_type]
                        action_note = f"[系统: 已生成 {len(sql_blocks)} 条 {type_label} SQL]"
                        if gen:
                            s = get_engine_stats(gen)
                            if s:
                                stats = f"引擎: {s} | 方言: {st.session_state.dialect} | 作者: {st.session_state.author}"
                    else:
                        action_note = "[系统: SQL 生成失败，文档可能有问题]"
                else:
                    action_note = "[系统: 用户还未上传文件]"

            elif intent["action"] == "change_dialect" and intent.get("dialect"):
                old = st.session_state.dialect
                st.session_state.dialect = intent["dialect"]
                action_note = f"[系统: 方言已从 {old} 切换到 {intent['dialect']}]"

            elif intent["action"] == "show_structure":
                if doc:
                    table_view = build_mapping_table(doc)
                    action_note = "[系统: 已展示当前文档的表结构]"
                else:
                    action_note = "[系统: 用户还未上传文件]"

            elif intent["action"] == "download":
                if doc:
                    status.update(label="正在准备 SQL 文件...", state="running")
                    sql_blocks, _ = generate_sql_for_doc()
                    action_note = "[系统: 已生成全部 SQL 供下载]"
                    stats = f"方言: {st.session_state.dialect} | {st.session_state.current_file_name}"
                else:
                    action_note = "[系统: 没有可下载的内容]"

            elif intent["action"] == "generate_query":
                if doc and llm and llm.is_available:
                    status.update(label="正在根据表结构生成查询 SQL...", state="running")
                    schema_ctx = build_schema_context(doc)
                    sql = llm.generate_sql_from_natural_language(
                        description=prompt,
                        tables=[tm.target_table for tm in doc.table_mappings],
                        dialect=st.session_state.dialect,
                        schema_context=schema_ctx,
                    )
                    if sql:
                        sql_blocks = {"query": sql}
                        action_note = "[系统: LLM 已生成查询 SQL]"
                        stats = f"LLM生成 | 方言: {st.session_state.dialect}"
                    else:
                        action_note = "[系统: LLM 查询生成失败]"

            # ── Phase C: LLM generates natural conversation response ──
            if llm and llm.is_available:
                status.update(label="思考中...", state="running")
                llm_response = llm.chat(prompt, context, action_note)
                if llm_response:
                    response = llm_response

            # ── Phase D: Fallback to template responses (no LLM) ──
            if not response:
                if intent["action"] == "help":
                    response = (
                        "你好！我是 **Mapping2SQL 智能助手**，专门帮你把数据 Mapping 文档转化为标准 SQL 代码。\n\n"
                        "**我能做什么：**\n\n"
                        "| 指令 | 说明 |\n"
                        "|------|------|\n"
                        "| 上传 Excel/CSV/Word 文件 | 解析 Mapping 文档 |\n"
                        "| `生成DDL` | 生成建表语句 |\n"
                        "| `生成DML` | 生成 INSERT...SELECT |\n"
                        "| `生成MERGE` | 生成增量合并语句 |\n"
                        "| `全部生成` | 生成全部 4 种 SQL |\n"
                        "| `切换MySQL` / `切换Oracle` | 切换数据库方言 |\n"
                        "| `展示结构` | 查看解析后的字段映射 |\n"
                        "| `下载` | 下载生成的 SQL 文件 |\n\n"
                        f"当前设置: 方言=**{st.session_state.dialect}** | 创建人=**{st.session_state.author}**\n\n"
                        "上传一个 Mapping 文档就可以开始了！"
                    )
                elif intent["action"] == "generate":
                    if doc and sql_blocks:
                        response = f"已生成 {len(sql_blocks)} 条 SQL 语句，点击展开查看代码。"
                    elif doc:
                        response = "未生成任何 SQL，请检查 Mapping 文档。"
                    else:
                        response = "请先上传 Mapping 文档，然后再告诉我需要生成什么 SQL。"
                elif intent["action"] == "generate_query":
                    if not doc:
                        response = "请先上传 Mapping 文档，我才能根据表结构帮你生成查询 SQL。"
                    elif not llm or not llm.is_available:
                        response = "自由查询需要连接 LLM。请在侧边栏配置 API Key，或使用关键字指令（如「生成DML」）。"
                    elif sql_blocks:
                        response = "已根据你的描述生成查询 SQL，点击展开查看:"
                    else:
                        response = "LLM 未能生成查询，请尝试更具体的描述，或检查 API 连接。"
                elif intent["action"] == "show_structure":
                    if doc:
                        response = f"当前文档: **{st.session_state.current_file_name}**\n\n{table_view}"
                    else:
                        response = "请先上传 Mapping 文档。"
                elif intent["action"] == "change_dialect":
                    response = action_note.replace("[系统: ", "").replace("]", "")
                elif intent["action"] == "download":
                    if doc:
                        response = "以下是全部 SQL，点击展开下载:"
                    else:
                        response = "没有可下载的内容，请先上传文档并生成 SQL。"
                elif doc:
                    response = (
                        f"当前文档: **{st.session_state.current_file_name}** "
                        f"({doc.table_count} 表, {doc.total_column_count} 字段)\n\n"
                        "你可以输入: **生成DDL** / **生成DML** / **全部生成** / **展示结构**"
                    )
                else:
                    response = (
                        "我是 Mapping2SQL 智能助手。请先上传 Mapping 文档（Excel/CSV/Word），"
                        "然后告诉我你需要什么，比如: _\"生成Oracle的DDL\"_"
                    )

            status.update(label="处理完成", state="complete", expanded=False)

    except Exception as e:
        response = f"处理时出现错误: {str(e)[:300]}\n\n请重试或刷新页面。"
        if st.session_state.messages and st.session_state.messages[-1].get("_placeholder"):
            pass  # placeholder already popped above

    # Append assistant response
    st.session_state.messages.append({
        "role": "assistant",
        "content": response,
        "sql_blocks": sql_blocks,
        "table": table_view,
        "stats": stats,
    })

    # Persist to disk
    if st.session_state.current_file_name:
        st.session_state.chat_store.save(
            st.session_state.current_file_name, st.session_state.messages)

    st.rerun()

# ── Phase 1: Capture user input & show immediately ──

if prompt := st.chat_input("用自然语言告诉我你需要的操作..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    st.session_state.messages.append({
        "role": "assistant",
        "content": "⏳ 正在思考...",
        "_placeholder": True,
    })
    st.session_state._pending_prompt = prompt
    st.rerun()
