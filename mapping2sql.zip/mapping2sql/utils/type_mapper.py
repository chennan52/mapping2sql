"""Data type mapping between different databases and general type categories."""

from typing import Optional


# Standard type categories
TYPE_CATEGORIES = {
    "string": ["VARCHAR", "VARCHAR2", "CHAR", "NVARCHAR", "NVARCHAR2", "TEXT", "CLOB",
               "STRING", "NCHAR", "LONG", "LONGTEXT", "MEDIUMTEXT", "TINYTEXT"],
    "integer": ["INT", "INTEGER", "BIGINT", "SMALLINT", "TINYINT", "MEDIUMINT", "NUMBER(10)",
                "NUMBER(38)", "PLS_INTEGER", "BINARY_INTEGER"],
    "decimal": ["DECIMAL", "NUMERIC", "NUMBER", "FLOAT", "DOUBLE", "REAL", "MONEY",
                "BINARY_FLOAT", "BINARY_DOUBLE"],
    "date": ["DATE", "DATETIME", "TIMESTAMP", "TIME", "YEAR", "DATETIME2",
             "TIMESTAMP WITH TIME ZONE", "TIMESTAMP WITH LOCAL TIME ZONE",
             "INTERVAL YEAR TO MONTH", "INTERVAL DAY TO SECOND"],
    "boolean": ["BOOLEAN", "BOOL", "BIT"],
    "binary": ["BLOB", "RAW", "BYTEA", "LONGBLOB", "MEDIUMBLOB", "VARBINARY"],
}

# Oracle-specific type mappings (source type -> target type)
ORACLE_TYPE_MAP = {
    # String types
    "VARCHAR2": lambda size: f"VARCHAR2({size or 255})",
    "CHAR": lambda size: f"CHAR({size or 1})",
    "NVARCHAR2": lambda size: f"NVARCHAR2({size or 255})",
    "CLOB": lambda size: "CLOB",
    # Numeric types
    "NUMBER": lambda size: f"NUMBER({size or '38,0'})",
    "INTEGER": lambda size: "INTEGER",
    "BINARY_FLOAT": lambda size: "BINARY_FLOAT",
    "BINARY_DOUBLE": lambda size: "BINARY_DOUBLE",
    # Date types
    "DATE": lambda size: "DATE",
    "TIMESTAMP": lambda size: "TIMESTAMP",
    "TIMESTAMP WITH TIME ZONE": lambda size: "TIMESTAMP WITH TIME ZONE",
    # LOB types
    "BLOB": lambda size: "BLOB",
    "RAW": lambda size: f"RAW({size or 256})",
}

# MySQL-specific type mappings
MYSQL_TYPE_MAP = {
    # String types
    "VARCHAR": lambda size: f"VARCHAR({size or 255})",
    "CHAR": lambda size: f"CHAR({size or 1})",
    "TEXT": lambda size: "TEXT",
    "LONGTEXT": lambda size: "LONGTEXT",
    # Numeric types
    "INT": lambda size: f"INT({size or 11})",
    "BIGINT": lambda size: "BIGINT",
    "DECIMAL": lambda size: f"DECIMAL({size or '18,2'})",
    "FLOAT": lambda size: "FLOAT",
    "DOUBLE": lambda size: "DOUBLE",
    # Date types
    "DATE": lambda size: "DATE",
    "DATETIME": lambda size: "DATETIME",
    "TIMESTAMP": lambda size: "TIMESTAMP",
    # LOB types
    "BLOB": lambda size: "BLOB",
}

# Cross-database type mapping (Oracle -> MySQL)
CROSS_TYPE_MAP = {
    "VARCHAR2": "VARCHAR",
    "NUMBER": "DECIMAL",
    "CLOB": "LONGTEXT",
    "BLOB": "LONGBLOB",
    "RAW": "VARBINARY",
    "DATE": "DATETIME",
    "TIMESTAMP": "TIMESTAMP",
    "VARCHAR": "VARCHAR",
    "CHAR": "CHAR",
    "INT": "INT",
    "INTEGER": "INT",
    "BIGINT": "BIGINT",
    "FLOAT": "FLOAT",
    "DOUBLE": "DOUBLE",
    "DECIMAL": "DECIMAL",
    "TEXT": "TEXT",
}


class TypeMapper:
    """Maps data types across databases and resolves type compatibility."""

    @staticmethod
    def get_category(dtype: str) -> str:
        """Get the general category of a data type."""
        if not dtype:
            return "unknown"
        upper = dtype.upper().strip()
        # Extract base type without size (e.g., "VARCHAR(100)" -> "VARCHAR")
        base_type = upper.split("(")[0].strip()
        for category, types in TYPE_CATEGORIES.items():
            for t in types:
                if base_type.startswith(t) or t.startswith(base_type):
                    return category
        return "unknown"

    @staticmethod
    def normalize(dtype: str, dialect: str = "oracle") -> str:
        """Normalize a data type to standard form for the given dialect."""
        if not dtype:
            return "VARCHAR2(255)" if dialect == "oracle" else "VARCHAR(255)"

        upper = dtype.upper().strip()
        base = upper.split("(")[0].strip()
        size = TypeMapper._extract_size(upper)

        type_map = ORACLE_TYPE_MAP if dialect == "oracle" else MYSQL_TYPE_MAP
        if base in type_map:
            return type_map[base](size)
        if base in CROSS_TYPE_MAP:
            mapped_base = CROSS_TYPE_MAP[base]
            mapped_map = ORACLE_TYPE_MAP if dialect == "oracle" else MYSQL_TYPE_MAP
            if mapped_base in mapped_map:
                return mapped_map[mapped_base](size)
            return f"{mapped_base}({size or 255})" if mapped_base.endswith("CHAR") else mapped_base

        return dtype

    @staticmethod
    def is_compatible(source_type: str, target_type: str) -> tuple[bool, str]:
        """Check if source type is compatible with target type. Returns (compatible, message)."""
        src_cat = TypeMapper.get_category(source_type)
        tgt_cat = TypeMapper.get_category(target_type)

        if src_cat == "unknown" or tgt_cat == "unknown":
            return True, "类型未知，跳过兼容性检查"

        if src_cat == tgt_cat:
            return True, "类型兼容"

        # Safe conversions
        safe = [
            ("integer", "decimal"), ("integer", "string"),
            ("decimal", "string"), ("date", "string"),
            ("boolean", "integer"), ("boolean", "string"),
        ]
        if (src_cat, tgt_cat) in safe:
            return True, f"可安全转换: {src_cat} -> {tgt_cat}"

        # Lossy conversions (warning)
        lossy = [
            ("decimal", "integer"), ("string", "integer"),
            ("string", "decimal"), ("string", "date"),
            ("string", "boolean"), ("decimal", "boolean"),
        ]
        if (src_cat, tgt_cat) in lossy:
            return True, f"⚠ 可能有数据精度损失: {src_cat} -> {tgt_cat}"

        return False, f"⚠ 不兼容的类型转换: {src_cat} -> {tgt_cat}"

    @staticmethod
    def _extract_size(dtype: str) -> Optional[str]:
        """Extract size parameter from type string like 'VARCHAR(100)' -> '100'."""
        if "(" in dtype and ")" in dtype:
            return dtype.split("(")[1].split(")")[0]
        return None
