-- ==== DWD.DWD_ACCT_DAILY_dml ====
-- ============================================================
-- 程序名称: ETL_ACCT_DAILY_TO_DWD_ACCT_DAILY
-- 功能描述: 从 ODS.ACCT_DAILY 同步数据到 DWD.DWD_ACCT_DAILY
-- 源表: ODS.ACCT_DAILY
-- 目标表: DWD.DWD_ACCT_DAILY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

INSERT INTO DWD.DWD_ACCT_DAILY
(
    acct_no
    ,cust_id
    ,org_code
    ,currency
    ,balance
    ,avail_balance
    ,status_name
    ,open_date
    ,open_month
    ,last_txn_date
    ,frozen_amt
)
SELECT
    acct_no  -- 账号
    ,cust_id  -- 客户号
    ,org_code  -- 机构号
    ,currency  -- 币种
    ,balance  -- 余额
    ,avail_balance  -- 可用余额
    ,CASE WHEN status=1 THEN '正常'
       ELSE '未知'
  END  -- 账户状态名称
    ,open_date  -- 开户日期
    ,DATE_FORMAT(open_date, '%Y%m')  -- 开户月份
    ,COALESCE(last_txn_date, '1900-01-01')  -- 最后交易日期
    ,COALESCE(frozen_amt, 0)  -- 冻结金额
FROM ODS.ACCT_DAILY  s
;

