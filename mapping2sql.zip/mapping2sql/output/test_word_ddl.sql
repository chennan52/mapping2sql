-- ==== unknown_table_ddl ====
-- ============================================================
-- 程序名称: CREATE_unknown_table
-- 功能描述: 创建表 unknown_table
-- 源表: unknown_table
-- 目标表: unknown_table
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

CREATE TABLE unknown_table (
    acct_no  VARCHAR2(20),
    cust_id  VARCHAR2(18),
    org_code  VARCHAR2(12),
    balance  NUMBER(18,2),
    status_name  VARCHAR2(20),
    open_month  VARCHAR2(6),
    last_txn_date  DATE,
    frozen_amt  NUMBER(18,2),
    prod_code  VARCHAR2(8),
    acct_type  VARCHAR2(4),
    etl_date  DATE
);
COMMENT ON COLUMN unknown_table.acct_no IS '账号(PK)';
COMMENT ON COLUMN unknown_table.cust_id IS '客户号';
COMMENT ON COLUMN unknown_table.org_code IS '机构号';
COMMENT ON COLUMN unknown_table.balance IS '余额';
COMMENT ON COLUMN unknown_table.status_name IS '账户状态名称';
COMMENT ON COLUMN unknown_table.open_month IS '开户月份';
COMMENT ON COLUMN unknown_table.last_txn_date IS '最后交易日期(NVL)';
COMMENT ON COLUMN unknown_table.frozen_amt IS '冻结金额(NVL)';
COMMENT ON COLUMN unknown_table.prod_code IS '产品代码';
COMMENT ON COLUMN unknown_table.acct_type IS '账户类型';
COMMENT ON COLUMN unknown_table.etl_date IS 'ETL日期';

