"""Chat history persistence — auto-save and restore per mapping file."""

import json
from pathlib import Path


class ChatHistoryStore:
    """Saves/loads chat history keyed by mapping filename."""

    def __init__(self, base_dir: str = None):
        if base_dir:
            self._dir = Path(base_dir)
        else:
            self._dir = Path.home() / ".mapping2sql" / "chat_history"
        self._dir.mkdir(parents=True, exist_ok=True)

    def _path_for(self, filename: str) -> Path:
        safe = filename.replace("\\", "_").replace("/", "_").replace(":", "_")
        return self._dir / f"{safe}.json"

    def save(self, filename: str, messages: list[dict]) -> None:
        """Persist chat messages to disk."""
        if not messages:
            return
        payload = []
        for m in messages:
            # Strip transient keys (placeholder, sql_blocks, table, stats)
            clean = {
                "role": m.get("role", ""),
                "content": m.get("content", ""),
            }
            if m.get("sql_blocks"):
                clean["sql_blocks"] = m["sql_blocks"]
            payload.append(clean)

        self._path_for(filename).write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def load(self, filename: str) -> list[dict]:
        """Load persisted chat messages, or empty list."""
        path = self._path_for(filename)
        if not path.exists():
            return []
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data
        except (json.JSONDecodeError, OSError):
            pass
        return []

    def delete(self, filename: str) -> bool:
        """Remove persisted history for a file."""
        path = self._path_for(filename)
        if path.exists():
            path.unlink()
            return True
        return False
