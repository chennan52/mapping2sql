"""SQL code generator — converts TableMapping objects to SQL statements via Jinja2 templates."""

from datetime import datetime
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from .models import TableMapping, MappingDocument
from .transformer import TransformEngine
from .formatter import SQLFormatter

_TEMPLATE_DIR = Path(__file__).resolve().parent.parent / "templates"


class SQLGenerator:
    """Generates SQL code from parsed mapping documents using Jinja2 templates."""

    SQL_TYPES = ["ddl", "dml", "merge", "query"]

    def __init__(self, dialect: str = "oracle", config_path: str = None,
                 llm_engine=None):
        self.dialect = dialect.lower()
        self.llm_engine = llm_engine
        self.transformer = TransformEngine(dialect=dialect, llm_engine=llm_engine)
        self.formatter = SQLFormatter(config_path=config_path)
        self._jinja = Environment(
            loader=FileSystemLoader(str(_TEMPLATE_DIR)),
            trim_blocks=False, lstrip_blocks=False,
            keep_trailing_newline=True,
        )

    def _render(self, template_name: str, context: dict) -> str:
        """Render a Jinja2 template, then apply case normalization + cleanup."""
        template = self._jinja.get_template(template_name)
        raw = template.render(**context)
        import re
        # Strip trailing whitespace on each line, collapse 3+ blank lines → 1
        lines = [l.rstrip() for l in raw.splitlines()]
        clean = re.sub(r'\n{3,}', '\n\n', "\n".join(lines))
        result = clean.strip() + "\n"
        # Normalize keyword/identifier case via formatter
        result = self.formatter.normalize_case(result)
        return result

    # ── Public API ────────────────────────────────────

    def generate(self, doc: MappingDocument, sql_type: str = "all",
                 author: str = "DATA_TEAM") -> dict[str, str]:
        if sql_type == "all":
            types = self.SQL_TYPES
        else:
            if sql_type not in self.SQL_TYPES:
                raise ValueError(f"Unsupported SQL type: {sql_type}")
            types = [sql_type]

        results = {}
        for tm in doc.table_mappings:
            for t in types:
                key = f"{tm.target_table}_{t}"
                handler = {
                    "ddl": self.generate_ddl,
                    "dml": self.generate_dml,
                    "merge": self.generate_merge,
                    "query": self.generate_query,
                }[t]
                results[key] = handler(tm, author)

        return results

    def generate_single(self, tm: TableMapping, sql_type: str = "dml",
                         author: str = "DATA_TEAM") -> str:
        handlers = {
            "ddl": self.generate_ddl, "dml": self.generate_dml,
            "merge": self.generate_merge, "query": self.generate_query,
        }
        if sql_type not in handlers:
            raise ValueError(f"Unsupported SQL type: {sql_type}")
        return handlers[sql_type](tm, author)

    def generate_batch(self, docs: list[MappingDocument], sql_type: str = "all",
                       author: str = "DATA_TEAM") -> dict[str, str]:
        all_results = {}
        for doc in docs:
            results = self.generate(doc, sql_type, author)
            all_results.update(results)
        return all_results

    # ── Expression builder ─────────────────────────────

    def _build_source_alias_map(self, tm: TableMapping) -> dict[str, str]:
        alias_map = {}
        _, tbl = self._split_schema_table(tm.source_table)
        alias_map[tm.source_table] = "s"
        if tbl:
            alias_map[tbl] = "s"
        for jc in tm.join_conditions:
            _, jtbl = self._split_schema_table(jc.table)
            alias_map[jc.table] = jc.alias
            if jtbl:
                alias_map[jtbl] = jc.alias
        return alias_map

    def _resolve_column_source(self, cm, tm: TableMapping,
                                alias_map: dict[str, str]) -> str:
        if cm.source_table:
            if cm.source_table in alias_map:
                return alias_map[cm.source_table]
            for tbl, alias in alias_map.items():
                _, bare = self._split_schema_table(tbl)
                if bare and bare == cm.source_table:
                    return alias
        return "s"

    def _build_select_expressions(self, tm: TableMapping) -> list[dict]:
        alias_map = self._build_source_alias_map(tm) if tm.join_conditions else {}
        expressions = []
        for cm in tm.columns:
            col_ref = cm.source_column
            if alias_map:
                src_alias = self._resolve_column_source(cm, tm, alias_map)
                col_ref = f"{src_alias}.{cm.source_column}"

            expr = col_ref
            if cm.transform_rule:
                expr = self.transformer.transform(
                    source_column=col_ref,
                    rule_text=cm.transform_rule,
                    source_type=cm.source_type,
                    target_type=cm.target_type,
                    target_column=cm.target_column,
                )

            if cm.source_column != cm.target_column:
                upper = expr.upper().strip()
                has_alias = " AS " in upper or expr.endswith(cm.target_column)
                is_complex = any(kw in upper for kw in (
                    "CASE", "NVL", "COALESCE", "CAST", "SUM(", "COUNT(",
                    "AVG(", "MAX(", "MIN(", "TO_CHAR(", "DATE_FORMAT(",
                    "SUBSTR(", "CONCAT(",
                ))
                if not has_alias and not is_complex:
                    expr = f"{expr}  AS {cm.target_column}"

            expressions.append({
                "expression": expr,
                "comment": cm.comment,
                "engine": self.transformer.last_engine,
            })
        return expressions

    # ── SQL fragment builders (Python → template strings) ──

    def _format_select_columns(self, entries: list[dict], indent: str = "    ") -> str:
        """Build SELECT column list: each column on its own line, leading comma, inline comment."""
        lines = []
        for i, entry in enumerate(entries):
            comma = "" if i == 0 else ","
            line = f"{indent}{comma}{entry['expression']}"
            if entry.get("comment"):
                line += f"  -- {entry['comment']}"
            lines.append(line)
        return "\n".join(lines)

    def _format_column_list(self, columns: list[str], indent: str = "    ") -> str:
        """Build a column name list with leading commas."""
        lines = []
        for i, col in enumerate(columns):
            comma = "" if i == 0 else ","
            lines.append(f"{indent}{comma}{col}")
        return "\n".join(lines)

    def _format_ddl_columns(self, tm: TableMapping) -> str:
        """Build DDL column definitions (each on its own line, leading comma)."""
        lines = []
        for i, cm in enumerate(tm.columns):
            comma = "" if i == 0 else ","
            line = f"    {comma}{cm.target_column}  {cm.target_type or 'VARCHAR2(255)'}"
            if not cm.nullable and not cm.is_pk:
                line += "  NOT NULL"
            lines.append(line)
        # Add PK constraint at the end
        pk_columns = tm.get_pk_columns()
        if pk_columns:
            pk_list = ", ".join(pk_columns)
            lines.append(f"    ,CONSTRAINT pk_{self._split_schema_table(tm.target_table)[1]} PRIMARY KEY ({pk_list})")
        return "\n".join(lines)

    # ── Context builder ────────────────────────────────

    def _base_context(self, tm: TableMapping, author: str) -> dict:
        src_schema, src_table = self._split_schema_table(tm.source_table)
        tgt_schema, tgt_table = self._split_schema_table(tm.target_table)
        pk_columns = tm.get_pk_columns()
        join_sqls = [jc.to_sql() for jc in tm.join_conditions if jc.to_sql()]

        # Pre-format clauses to avoid Jinja2 whitespace issues
        group_by_str = ""
        if tm.group_by:
            lines = []
            for i, g in enumerate(tm.group_by):
                comma = "" if i == 0 else ","
                lines.append(f"    {comma}{g}")
            group_by_str = "GROUP BY\n" + "\n".join(lines)

        order_by_str = ""
        if tm.order_by:
            lines = []
            for i, o in enumerate(tm.order_by):
                comma = "" if i == 0 else ","
                lines.append(f"    {comma}{o}")
            order_by_str = "ORDER BY\n" + "\n".join(lines)

        # Pre-format JOIN clauses as a single string
        join_str = "\n".join(join_sqls) if join_sqls else ""

        return {
            "source_schema": src_schema,
            "source_table": src_table,
            "target_schema": tgt_schema,
            "target_table": tgt_table,
            "author": author,
            "create_date": datetime.now().strftime("%Y-%m-%d"),
            "table_comment": tm.table_comment,
            "filter_condition": tm.filter_condition,
            "group_by_clause": group_by_str,
            "order_by_clause": order_by_str,
            "join_block": join_str,
            "incremental_key": tm.incremental_key or "etl_date",
            "pk_columns": pk_columns,
            "pk_column": pk_columns[0] if pk_columns else "id",
            "columns": tm.columns,
            "source_alias": "s",
        }

    # ── Generators (template + Python formatting) ──────

    def generate_ddl(self, tm: TableMapping, author: str) -> str:
        ctx = self._base_context(tm, author)
        ctx["column_defs"] = self._format_ddl_columns(tm)
        return self._render("create_table.sql.j2", ctx)

    def generate_dml(self, tm: TableMapping, author: str) -> str:
        ctx = self._base_context(tm, author)
        ctx["select_columns"] = self._format_select_columns(
            self._build_select_expressions(tm))
        ctx["insert_columns"] = self._format_column_list(
            [c.target_column for c in tm.columns])
        return self._render("insert_select.sql.j2", ctx)

    def generate_merge(self, tm: TableMapping, author: str) -> str:
        ctx = self._base_context(tm, author)
        ctx["select_columns"] = self._format_select_columns(
            self._build_select_expressions(tm), indent="            ")
        ctx["non_pk_set"] = self._format_column_list(
            [f"t.{c.target_column} = src.{c.target_column}"
             for c in tm.columns if not c.is_pk],
            indent="        ")
        ctx["insert_cols"] = self._format_column_list(
            [c.target_column for c in tm.columns], indent="        ")
        ctx["values_cols"] = self._format_column_list(
            [f"src.{c.target_column}" for c in tm.columns], indent="        ")
        return self._render("merge.sql.j2", ctx)

    def generate_query(self, tm: TableMapping, author: str) -> str:
        ctx = self._base_context(tm, author)
        ctx["description"] = tm.table_comment or f"查询 {ctx['target_table']}"
        ctx["select_columns"] = self._format_select_columns([
            {"expression": cm.target_column, "comment": cm.comment}
            for cm in tm.columns
        ])
        return self._render("query.sql.j2", ctx)

    # ── Legacy wrappers (used by app.py) ───────────────

    def _generate_ddl(self, tm, author): return self.generate_ddl(tm, author)
    def _generate_dml(self, tm, author): return self.generate_dml(tm, author)
    def _generate_merge(self, tm, author): return self.generate_merge(tm, author)
    def _generate_query(self, tm, author): return self.generate_query(tm, author)

    # ── Utility ───────────────────────────────────────

    @staticmethod
    def _split_schema_table(table_name: str) -> tuple[str, str]:
        if not table_name:
            return "", ""
        parts = table_name.split(".", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
        return "", parts[0]
