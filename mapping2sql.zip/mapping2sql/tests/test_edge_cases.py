"""Boundary-condition and edge-case tests for parser, generator, transformer, and validator."""

import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.models import ColumnMapping, TableMapping, MappingDocument, JoinClause
from core.generator import SQLGenerator
from core.transformer import TransformEngine
from core.validator import SQLValidator


# ═══════════════════════════════════════════════════════
# Generator edge cases
# ═══════════════════════════════════════════════════════

class TestGeneratorEdgeCases:
    """Generator should handle unusual table/column structures cleanly."""

    @pytest.fixture
    def gen(self):
        return SQLGenerator(dialect="oracle")

    def test_single_column_table(self, gen):
        """Table with just one column should still generate valid SQL."""
        tm = TableMapping(source_table="ODS.T1", target_table="DWD.T1")
        tm.columns = [ColumnMapping(
            source_table="ODS.T1", source_column="id",
            target_column="id", is_pk=True,
            source_type="NUMBER", target_type="NUMBER",
        )]
        ddl = gen.generate_ddl(tm, "TEST")
        assert "CREATE TABLE" in ddl
        assert "PRIMARY KEY" in ddl
        assert "id" in ddl

    def test_table_without_pk(self, gen):
        """Table with no PK should still generate DDL (without PK constraint)."""
        tm = TableMapping(source_table="ODS.T1", target_table="DWD.T1")
        tm.columns = [
            ColumnMapping(source_table="ODS.T1", source_column="a",
                         target_column="a"),
            ColumnMapping(source_table="ODS.T1", source_column="b",
                         target_column="b"),
        ]
        ddl = gen.generate_ddl(tm, "TEST")
        assert "CREATE TABLE" in ddl
        assert "PRIMARY KEY" not in ddl.upper()

    def test_table_without_schema_prefix(self, gen):
        """Table names without schema prefix should work."""
        tm = TableMapping(source_table="RAW_TABLE", target_table="CLEAN_TABLE")
        tm.columns = [ColumnMapping(
            source_table="RAW_TABLE", source_column="id",
            target_column="id", is_pk=True,
        )]
        ddl = gen.generate_ddl(tm, "TEST")
        assert "RAW_TABLE" in ddl or "CLEAN_TABLE" in ddl

    def test_special_characters_in_column_names(self, gen):
        """Underscores and mixed case in column names should be preserved."""
        tm = TableMapping(source_table="ODS.T1", target_table="DWD.T1")
        tm.columns = [
            ColumnMapping(source_table="ODS.T1", source_column="CUST_NAME",
                         target_column="cust_name", is_pk=True),
            ColumnMapping(source_table="ODS.T1", source_column="ACCT_BAL_AMT",
                         target_column="acct_bal_amt"),
            ColumnMapping(source_table="ODS.T1", source_column="IS_ACTIVE_FLAG",
                         target_column="is_active_flag"),
        ]
        dml = gen.generate_dml(tm, "TEST")
        assert "CUST_NAME" in dml
        assert "cust_name" in dml
        assert "ACCT_BAL_AMT" in dml
        assert "acct_bal_amt" in dml

    def test_empty_optional_fields(self, gen):
        """Columns with no type, comment, or rule should not break generation."""
        tm = TableMapping(source_table="ODS.T1", target_table="DWD.T1")
        tm.columns = [
            ColumnMapping(source_table="ODS.T1", source_column="a",
                         target_column="a", is_pk=True),
            ColumnMapping(source_table="ODS.T1", source_column="b",
                         target_column="b", comment=""),
            ColumnMapping(source_table="ODS.T1", source_column="c",
                         target_column="c", transform_rule=""),
        ]
        results = gen.generate(MappingDocument(table_mappings=[tm]))
        assert len(results) == 4  # ddl, dml, merge, query
        for sql in results.values():
            assert "{{" not in sql  # no template leaks
            assert len(sql) > 50

    def test_all_generated_sql_ends_with_semicolon_or_newline(self, gen):
        """Every generated SQL should terminate properly."""
        tm = TableMapping(source_table="ODS.T1", target_table="DWD.T1")
        tm.columns = [ColumnMapping(
            source_table="ODS.T1", source_column="id",
            target_column="id", is_pk=True,
        )]
        results = gen.generate(MappingDocument(table_mappings=[tm]))
        for key, sql in results.items():
            assert sql.rstrip().endswith((";", "\n")), \
                f"{key}: output not properly terminated"

    def test_merge_uses_first_pk_for_on_clause(self, gen):
        """MERGE should use the first PK column in the ON clause."""
        tm = TableMapping(source_table="ODS.T1", target_table="DWD.T1")
        tm.columns = [
            ColumnMapping(source_table="ODS.T1", source_column="pk1",
                         target_column="pk1", is_pk=True),
            ColumnMapping(source_table="ODS.T1", source_column="pk2",
                         target_column="pk2", is_pk=True),
            ColumnMapping(source_table="ODS.T1", source_column="val",
                         target_column="val"),
        ]
        merge = gen.generate_merge(tm, "TEST")
        assert "ON (t.pk1 = src.pk1)" in merge


# ═══════════════════════════════════════════════════════
# Transformer edge cases
# ═══════════════════════════════════════════════════════

class TestTransformerEdgeCases:
    """Transformer should handle unusual rule texts gracefully."""

    def test_empty_rule_returns_direct_map(self):
        engine = TransformEngine(dialect="oracle")
        result = engine.transform(source_column="col", rule_text="")
        assert result == "col"
        assert engine.last_engine == "none"

    def test_whitespace_only_rule(self):
        engine = TransformEngine(dialect="oracle")
        result = engine.transform(source_column="col", rule_text="   ")
        assert "col" in result

    def test_rule_with_special_characters(self):
        engine = TransformEngine(dialect="oracle")
        result = engine.transform(
            source_column="rate", rule_text="rate * 100",
            source_type="NUMBER", target_type="NUMBER",
        )
        assert "rate" in result

    def test_unknown_rule_falls_back_with_comment(self):
        engine = TransformEngine(dialect="oracle")
        result = engine.transform(
            source_column="col", rule_text="某种自定义逻辑",
        )
        assert "col" in result
        assert "需人工确认" in result

    def test_direct_map_with_type_mismatch_adds_cast(self):
        engine = TransformEngine(dialect="oracle")
        result = engine.transform(
            source_column="col", rule_text="直接映射",
            source_type="VARCHAR2(100)", target_type="NUMBER",
        )
        assert "CAST" in result.upper()


# ═══════════════════════════════════════════════════════
# Validator edge cases
# ═══════════════════════════════════════════════════════

class TestValidatorEdgeCases:
    """Validator should catch and report various issues."""

    def test_empty_document(self):
        validator = SQLValidator()
        doc = MappingDocument()
        result = validator.validate_document(doc)
        assert not result.is_valid
        assert "未包含任何表映射" in result.message

    def test_table_without_columns(self):
        validator = SQLValidator()
        tm = TableMapping(source_table="ODS.T1", target_table="DWD.T1")
        tm.columns = []
        result = validator.validate_table_mapping(tm)
        assert not result.is_valid
        assert "未包含任何字段映射" in result.message

    def test_table_missing_source(self):
        validator = SQLValidator()
        tm = TableMapping(target_table="DWD.T1")
        result = validator.validate_table_mapping(tm)
        assert not result.is_valid
        assert "缺少源表名" in result.message

    def test_duplicate_target_columns_warns(self):
        validator = SQLValidator()
        tm = TableMapping(source_table="ODS.T1", target_table="DWD.T1")
        tm.columns = [
            ColumnMapping(source_table="ODS.T1", source_column="a",
                         target_column="x"),
            ColumnMapping(source_table="ODS.T1", source_column="b",
                         target_column="x"),  # duplicate
        ]
        result = validator.validate_table_mapping(tm)
        assert any("重复映射" in w for w in result.warnings)

    def test_no_pk_warns(self):
        validator = SQLValidator()
        tm = TableMapping(source_table="ODS.T1", target_table="DWD.T1")
        tm.columns = [
            ColumnMapping(source_table="ODS.T1", source_column="a",
                         target_column="a"),
        ]
        result = validator.validate_table_mapping(tm)
        assert any("未指定主键" in w for w in result.warnings)

    def test_incomplete_transformation_rule_warns(self):
        validator = SQLValidator()
        tm = TableMapping(source_table="ODS.T1", target_table="DWD.T1")
        tm.columns = [
            ColumnMapping(source_table="ODS.T1", source_column="a",
                         target_column="a", transform_rule="当状态=?时则?"),
        ]
        result = validator.validate_table_mapping(tm)
        assert any("?" in w for w in result.warnings)

    def test_empty_sql_is_invalid(self):
        validator = SQLValidator()
        result = validator.validate_sql("")
        assert not result.is_valid

        result2 = validator.validate_sql("   ")
        assert not result2.is_valid


# ═══════════════════════════════════════════════════════
# Parser edge cases (in-memory, no fixture needed)
# ═══════════════════════════════════════════════════════

class TestParserEdgeCases:
    """Parser should handle malformed or unusual inputs."""

    def test_rejects_unsupported_format(self):
        from core.parser import MappingParser
        parser = MappingParser()
        with pytest.raises(ValueError, match="不支持的文件格式"):
            parser.parse("/tmp/test.pdf")

    def test_parse_join_text_bare_on(self):
        from core.parser import MappingParser
        parser = MappingParser()
        joins = parser._parse_join_text("s.cust_id = c.cust_id")
        assert len(joins) == 1
        assert joins[0].join_type == "INNER"
        assert "s.cust_id" in joins[0].on_condition

    def test_parse_join_text_multiple(self):
        from core.parser import MappingParser
        parser = MappingParser()
        joins = parser._parse_join_text(
            "LEFT JOIN ODS.CUST c ON s.cust_id = c.cust_id;\n"
            "INNER JOIN ODS.ACCT a ON s.acct_id = a.acct_id"
        )
        assert len(joins) == 2
        assert joins[0].join_type == "LEFT"
        assert joins[1].join_type == "INNER"

    def test_parse_join_text_empty(self):
        from core.parser import MappingParser
        parser = MappingParser()
        joins = parser._parse_join_text("")
        assert joins == []

    def test_parse_join_text_garbage(self):
        from core.parser import MappingParser
        parser = MappingParser()
        joins = parser._parse_join_text("random text not a join")
        assert joins == []

    def test_match_columns_empty_headers(self):
        from core.parser import MappingParser
        parser = MappingParser()
        result = parser._match_columns([])
        assert result == {}

    def test_match_columns_irrelevant_headers(self):
        from core.parser import MappingParser
        parser = MappingParser()
        result = parser._match_columns(["序号", "备注说明", "额外信息"])
        # Should not match source_column/target_column
        assert "source_column" not in result
        assert "target_column" not in result


# ═══════════════════════════════════════════════════════
# Models edge cases
# ═══════════════════════════════════════════════════════

class TestModelsEdgeCases:
    def test_column_repr(self):
        cm = ColumnMapping(source_table="T", source_column="src",
                          target_column="tgt", transform_rule="直接映射")
        assert "src -> tgt" in repr(cm)

    def test_join_clause_no_table_returns_empty(self):
        jc = JoinClause(join_type="LEFT", alias="x", on_condition="a.id = b.id")
        assert jc.to_sql() == ""

    def test_join_clause_no_on_returns_empty(self):
        jc = JoinClause(join_type="LEFT", table="ODS.T", alias="x")
        assert jc.to_sql() == ""

    def test_mapping_document_empty(self):
        doc = MappingDocument(title="test")
        assert doc.table_count == 0
        assert doc.total_column_count == 0

    def test_table_mapping_empty_pk_list(self):
        tm = TableMapping(source_table="ODS.T", target_table="DWD.T")
        tm.columns = [ColumnMapping(source_table="ODS.T", source_column="a",
                                   target_column="a")]
        assert tm.get_pk_columns() == []

    def test_join_clause_without_alias(self):
        jc = JoinClause(
            join_type="INNER", table="ODS.T2",
            on_condition="s.id = t.id",
        )
        sql = jc.to_sql()
        assert "INNER JOIN ODS.T2" in sql
        assert "ON s.id = t.id" in sql


# ═══════════════════════════════════════════════════════
# Formatter edge cases
# ═══════════════════════════════════════════════════════

class TestFormatterEdgeCases:
    def test_normalize_case_uppercase_keywords(self):
        from core.formatter import SQLFormatter
        fmt = SQLFormatter()
        result = fmt.normalize_case("select col from tbl where col = 1")
        assert "SELECT" in result
        assert "FROM" in result
        assert "WHERE" in result

    def test_normalize_case_preserves_comments(self):
        from core.formatter import SQLFormatter
        fmt = SQLFormatter()
        sql = "-- This is a comment\nSELECT col FROM tbl"
        result = fmt.normalize_case(sql)
        assert "-- This is a comment" in result
        assert "SELECT" in result

    def test_format_loads_default_config(self):
        from core.formatter import SQLFormatter
        fmt = SQLFormatter()
        assert fmt.config["dialect"] == "oracle"
        assert fmt.config["naming"]["keyword_case"] == "upper"

    def test_normalize_case_empty_sql(self):
        from core.formatter import SQLFormatter
        fmt = SQLFormatter()
        assert fmt.normalize_case("") == ""
