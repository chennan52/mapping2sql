"""SQL and Mapping validator — checks correctness before generation."""

from typing import Optional

import sqlparse

from .models import ColumnMapping, TableMapping, MappingDocument
from utils.type_mapper import TypeMapper


class ValidationResult:
    """Result of a validation check."""
    def __init__(self):
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.info: list[str] = []

    @property
    def is_valid(self) -> bool:
        return len(self.errors) == 0

    @property
    def message(self) -> str:
        parts = []
        if self.errors:
            parts.append(f"❌ 错误 ({len(self.errors)}):\n  " + "\n  ".join(self.errors))
        if self.warnings:
            parts.append(f"⚠ 警告 ({len(self.warnings)}):\n  " + "\n  ".join(self.warnings))
        if self.info:
            parts.append(f"ℹ 信息 ({len(self.info)}):\n  " + "\n  ".join(self.info))
        return "\n".join(parts) if parts else "✅ 校验通过"


class SQLValidator:
    """Validates Mapping documents and generated SQL."""

    def __init__(self, dialect: str = "oracle"):
        self.dialect = dialect.lower()
        self.type_mapper = TypeMapper()

    def validate_document(self, doc: MappingDocument) -> ValidationResult:
        """Validate a complete mapping document."""
        result = ValidationResult()

        if not doc.table_mappings:
            result.errors.append("Mapping文档未包含任何表映射")
            return result

        for i, tm in enumerate(doc.table_mappings):
            tm_result = self.validate_table_mapping(tm, f"表映射 #{i+1}")
            result.errors.extend(tm_result.errors)
            result.warnings.extend(tm_result.warnings)
            result.info.extend(tm_result.info)

        if result.is_valid:
            result.info.append(f"文档包含 {doc.table_count} 个表映射, "
                             f"共 {doc.total_column_count} 个字段映射")

        return result

    def validate_table_mapping(self, tm: TableMapping,
                                label: str = "") -> ValidationResult:
        """Validate a single table mapping."""
        result = ValidationResult()
        prefix = f"{label}: " if label else ""

        # Check required fields
        if not tm.source_table:
            result.errors.append(f"{prefix}缺少源表名")
        if not tm.target_table:
            result.errors.append(f"{prefix}缺少目标表名")
        if not tm.columns:
            result.errors.append(f"{prefix}未包含任何字段映射")
            return result

        # Validate each column mapping
        target_columns_seen = set()
        for cm in tm.columns:
            col_result = self._validate_column(cm)
            result.errors.extend(f"{prefix}{e}" for e in col_result.errors)
            result.warnings.extend(f"{prefix}{w}" for w in col_result.warnings)

            if cm.target_column and cm.target_column in target_columns_seen:
                result.warnings.append(
                    f"{prefix}目标字段 '{cm.target_column}' 重复映射")
            target_columns_seen.add(cm.target_column)

        # Check for common issues
        if not tm.get_pk_columns():
            result.warnings.append(f"{prefix}未指定主键字段，建议至少标记一个主键")

        # Validate filter condition is not empty if specified
        if tm.filter_condition and len(tm.filter_condition.strip()) < 3:
            result.warnings.append(f"{prefix}过滤条件过短，请确认: '{tm.filter_condition}'")

        return result

    def _validate_column(self, cm: ColumnMapping) -> ValidationResult:
        """Validate a single column mapping."""
        result = ValidationResult()

        if not cm.source_column:
            result.errors.append(f"缺少源字段名 (目标字段: {cm.target_column or '未知'})")
        if not cm.target_column:
            result.errors.append(f"缺少目标字段名 (源字段: {cm.source_column or '未知'})")

        # Type compatibility check
        if cm.source_type and cm.target_type:
            compatible, msg = self.type_mapper.is_compatible(
                cm.source_type, cm.target_type)
            if not compatible:
                result.errors.append(
                    f"字段 '{cm.source_column}': {msg}")
            elif "⚠" in msg:
                result.warnings.append(
                    f"字段 '{cm.source_column}': {msg}")

        # Validate transformation rule
        if cm.transform_rule:
            rule = cm.transform_rule.strip()
            if rule.startswith("TODO") or rule.startswith("未定义"):
                result.warnings.append(
                    f"字段 '{cm.source_column}': 转换规则未定义")
            if "?" in rule and "CASE" not in rule.upper():
                result.warnings.append(
                    f"字段 '{cm.source_column}': 转换规则可能不完整 (含'?')")

        return result

    def validate_sql(self, sql: str) -> ValidationResult:
        """Basic SQL syntax validation using sqlparse."""
        result = ValidationResult()

        if not sql or not sql.strip():
            result.errors.append("SQL代码为空")
            return result

        try:
            statements = sqlparse.parse(sql)
            if not statements:
                result.errors.append("无法解析SQL代码")
                return result

            for i, stmt in enumerate(statements):
                if not stmt.tokens:
                    result.warnings.append(f"语句 #{i+1} 为空")
                    continue

                # Check for common issues
                sql_upper = str(stmt).upper()
                if "INSERT" in sql_upper and "SELECT" in sql_upper:
                    # Check INSERT column count matches SELECT column count
                    result.info.append(f"语句 #{i+1}: INSERT...SELECT 格式正确")

                if "JOIN" in sql_upper and "ON" not in sql_upper:
                    result.warnings.append(f"语句 #{i+1}: JOIN 缺少 ON 条件")

        except Exception as e:
            result.errors.append(f"SQL解析异常: {str(e)}")

        if result.is_valid and not result.warnings:
            result.info.append("SQL语法校验通过")

        return result

    def validate_mapping_completeness(self, tm: TableMapping) -> ValidationResult:
        """Check if the mapping is complete and ready for code generation."""
        result = ValidationResult()

        total = len(tm.columns)
        mapped = sum(1 for c in tm.columns if c.transform_rule or c.source_column)
        direct = sum(1 for c in tm.columns if not c.transform_rule)

        if total > 0:
            result.info.append(
                f"字段映射: {total} 个 (直接映射: {direct}, "
                f"含转换规则: {total - direct})"
            )

        if mapped == 0 and total > 0:
            result.warnings.append("所有字段均为直接映射，未包含转换规则")

        # Check if there are any unmapped target columns
        unmapped = [c for c in tm.columns if not c.source_column]
        if unmapped:
            result.warnings.append(
                f"以下目标字段无源字段映射: "
                f"{', '.join(c.target_column for c in unmapped)}")

        return result
