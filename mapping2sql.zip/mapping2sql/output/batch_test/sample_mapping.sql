-- ==== unknown_table_ddl ====
-- ============================================================
-- 程序名称: CREATE_unknown_table
-- 功能描述: 创建表 unknown_table
-- 源表: unknown_table
-- 目标表: unknown_table
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

CREATE TABLE unknown_table (
    acct_no  VARCHAR2(20),
    cust_id  VARCHAR2(18),
    org_code  VARCHAR2(12),
    balance  NUMBER(18,2),
    status_name  VARCHAR2(20),
    open_month  VARCHAR2(6),
    last_txn_date  DATE,
    frozen_amt  NUMBER(18,2),
    prod_code  VARCHAR2(8),
    acct_type  VARCHAR2(4),
    etl_date  DATE
);
COMMENT ON COLUMN unknown_table.acct_no IS '账号(PK)';
COMMENT ON COLUMN unknown_table.cust_id IS '客户号';
COMMENT ON COLUMN unknown_table.org_code IS '机构号';
COMMENT ON COLUMN unknown_table.balance IS '余额';
COMMENT ON COLUMN unknown_table.status_name IS '账户状态名称';
COMMENT ON COLUMN unknown_table.open_month IS '开户月份';
COMMENT ON COLUMN unknown_table.last_txn_date IS '最后交易日期(NVL)';
COMMENT ON COLUMN unknown_table.frozen_amt IS '冻结金额(NVL)';
COMMENT ON COLUMN unknown_table.prod_code IS '产品代码';
COMMENT ON COLUMN unknown_table.acct_type IS '账户类型';
COMMENT ON COLUMN unknown_table.etl_date IS 'ETL日期';


-- ==== unknown_table_dml ====
-- ============================================================
-- 程序名称: ETL_unknown_table_TO_unknown_table
-- 功能描述: 从 .unknown_table 同步数据到 .unknown_table
-- 源表: unknown_table
-- 目标表: unknown_table
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

INSERT INTO unknown_table
(
    acct_no
    ,cust_id
    ,org_code
    ,balance
    ,status_name
    ,open_month
    ,last_txn_date
    ,frozen_amt
    ,prod_code
    ,acct_type
    ,etl_date
)
SELECT
    acct_no  -- 账号(PK)
    ,cust_id  -- 客户号
    ,org_code  -- 机构号
    ,balance  -- 余额
    ,CASE WHEN status=1 THEN '正常'
       ELSE '当status=2则'冻结'否则'未知'
  END  -- 账户状态名称
    ,TO_CHAR(YYYYMM, 'YYYYMMDD')  -- 开户月份
    ,NVL(last_txn_date, '1900-01-01')  -- 最后交易日期(NVL)
    ,NVL(frozen_amt, 0)  -- 冻结金额(NVL)
    ,prod_code  -- 产品代码
    ,acct_type  -- 账户类型
    ,etl_date  -- ETL日期
FROM unknown_table  s
;


-- ==== unknown_table_merge ====
-- ============================================================
-- 程序名称: MERGE_unknown_table_TO_unknown_table
-- 功能描述: 增量同步 .unknown_table -> .unknown_table
-- 源表: unknown_table
-- 目标表: unknown_table
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

MERGE INTO unknown_table  t
USING (
    SELECT
            acct_no  -- 账号(PK)
            ,cust_id  -- 客户号
            ,org_code  -- 机构号
            ,balance  -- 余额
            ,CASE WHEN status=1 THEN '正常'
       ELSE '当status=2则'冻结'否则'未知'
  END  -- 账户状态名称
            ,TO_CHAR(YYYYMM, 'YYYYMMDD')  -- 开户月份
            ,NVL(last_txn_date, '1900-01-01')  -- 最后交易日期(NVL)
            ,NVL(frozen_amt, 0)  -- 冻结金额(NVL)
            ,prod_code  -- 产品代码
            ,acct_type  -- 账户类型
            ,etl_date  -- ETL日期
    FROM unknown_table  s
)  src

ON (t.id = src.id)
WHEN MATCHED THEN
    UPDATE SET
        t.acct_no = src.acct_no
        ,t.cust_id = src.cust_id
        ,t.org_code = src.org_code
        ,t.balance = src.balance
        ,t.status_name = src.status_name
        ,t.open_month = src.open_month
        ,t.last_txn_date = src.last_txn_date
        ,t.frozen_amt = src.frozen_amt
        ,t.prod_code = src.prod_code
        ,t.acct_type = src.acct_type
        ,t.etl_date = src.etl_date
WHEN NOT MATCHED THEN
    INSERT (
            acct_no
            ,cust_id
            ,org_code
            ,balance
            ,status_name
            ,open_month
            ,last_txn_date
            ,frozen_amt
            ,prod_code
            ,acct_type
            ,etl_date
    ) VALUES (
            src.acct_no
            ,src.cust_id
            ,src.org_code
            ,src.balance
            ,src.status_name
            ,src.open_month
            ,src.last_txn_date
            ,src.frozen_amt
            ,src.prod_code
            ,src.acct_type
            ,src.etl_date
    )
;


-- ==== unknown_table_query ====
-- ============================================================
-- 程序名称: QUERY_unknown_table
-- 功能描述: 查询 unknown_table
-- 源表: unknown_table
-- 目标表: unknown_table
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

SELECT
    acct_no  -- 账号(PK)
    ,cust_id  -- 客户号
    ,org_code  -- 机构号
    ,balance  -- 余额
    ,status_name  -- 账户状态名称
    ,open_month  -- 开户月份
    ,last_txn_date  -- 最后交易日期(NVL)
    ,frozen_amt  -- 冻结金额(NVL)
    ,prod_code  -- 产品代码
    ,acct_type  -- 账户类型
    ,etl_date  -- ETL日期
FROM unknown_table  t
;

