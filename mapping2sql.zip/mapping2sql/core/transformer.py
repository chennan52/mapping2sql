"""Transformation rule engine — converts mapping rules to SQL expressions.

Uses a two-tier approach:
  1. LLM Engine (primary) — handles complex natural language rules
  2. Regex Rule Parser (fallback) — fast matching for common simple patterns
"""

from typing import Optional
from utils.rule_parser import RuleParser


class TransformEngine:
    """Converts column transformation rules into SQL expressions.

    Supports both Oracle and MySQL dialects with appropriate function names.
    LLM-powered for natural language understanding, regex for fast simple cases.
    """

    def __init__(self, dialect: str = "oracle", llm_engine=None):
        self.dialect = dialect.lower()
        self._llm = llm_engine  # LLMEngine instance (optional)
        self._src_col = ""
        self._last_engine = "none"  # Track which engine was used

    @property
    def last_engine(self) -> str:
        """Returns which engine was used for the last transform: 'llm', 'regex', or 'none'."""
        return self._last_engine

    def transform(self, source_column: str, rule_text: str, source_type: str = "",
                  target_type: str = "", target_column: str = "") -> str:
        """Convert a mapping rule into a SQL expression.

        Uses LLM (when available) for complex/natural language rules,
        falls back to regex for simple patterns.
        """
        self._src_col = source_column
        self._last_engine = "none"

        if not rule_text or rule_text.strip() == "":
            return self._direct_map(source_column, source_type, target_type)

        rule_text = rule_text.strip()

        # ── Tier 1: Try regex for simple, well-defined patterns ──
        parsed = RuleParser.parse(rule_text)
        rule_type = parsed["type"]
        confidence = parsed.get("confidence", 0.0)
        params = parsed.get("params", {})

        # Use regex result if it's a simple rule with high confidence
        if rule_type == "direct":
            self._last_engine = "regex"
            return self._direct_map(source_column, source_type, target_type)

        if rule_type != "unknown" and confidence >= 0.8:
            result = self._apply_regex_rule(rule_type, params, source_column,
                                           source_type, target_type)
            if result and not result.startswith(source_column + "  /*"):
                self._last_engine = "regex"
                return result

        # ── Tier 2: Use LLM for complex/natural language rules ──
        if self._llm and self._llm.is_available:
            prev_failed = self._llm.failed
            llm_result = self._llm.transform_rule_to_sql(
                rule_text=rule_text,
                source_column=source_column,
                source_type=source_type,
                target_column=target_column,
                target_type=target_type,
                dialect=self.dialect,
            )
            if llm_result:
                self._last_engine = "llm"
                return llm_result
            if self._llm.failed > prev_failed:
                self._last_engine = "llm_failed"

        # ── Tier 3: Regex fallback with moderate confidence ──
        if rule_type != "unknown" and confidence >= 0.5:
            result = self._apply_regex_rule(rule_type, params, source_column,
                                           source_type, target_type)
            self._last_engine = "regex"
            return result

        # ── Last resort: pass through with comment ──
        self._last_engine = "regex"
        return f"{source_column}  /* 转换规则: {rule_text} — 需人工确认 */"

    def _apply_regex_rule(self, rule_type: str, params: dict, source_column: str,
                          source_type: str, target_type: str) -> str:
        """Apply a regex-parsed rule to generate SQL expression."""
        handlers = {
            "direct": lambda: self._direct_map(source_column, source_type, target_type),
            "constant": lambda: self._constant(params.get("value", "")),
            "nvl": lambda: self._nvl(source_column, params.get("default", "0")),
            "case_when": lambda: self._case_when(
                source_column, params.get("condition", ""),
                params.get("then_value", ""), params.get("else_value", ""),
            ),
            "type_cast": lambda: self._type_cast(source_column, target_type),
            "sum": lambda: self._aggregate("SUM", params.get("field", source_column)),
            "avg": lambda: self._aggregate("AVG", params.get("field", source_column)),
            "count": lambda: self._aggregate("COUNT", params.get("field", source_column)),
            "max": lambda: self._aggregate("MAX", params.get("field", source_column)),
            "min": lambda: self._aggregate("MIN", params.get("field", source_column)),
            "concat": lambda: self._concat(params.get("fields", [])),
            "substring": lambda: self._substring(
                params.get("field", source_column),
                params.get("start", "1"), params.get("length", None),
            ),
            "date_format": lambda: self._date_format(
                params.get("field", source_column), params.get("format", "YYYYMMDD"),
            ),
            "yoy": lambda: f"-- TODO: 同比计算\n{source_column}",
            "mom": lambda: f"-- TODO: 环比计算\n{source_column}",
            "sql_expression": lambda: self._sql_expression(
                params.get("expression", ""), source_column,
            ),
            "unknown": lambda: f"{source_column}  /* 需人工确认 */",
        }
        handler = handlers.get(rule_type, lambda: source_column)
        return handler()

    def _direct_map(self, source_column: str, source_type: str = "",
                    target_type: str = "") -> str:
        if source_type and target_type and source_type.upper() != target_type.upper():
            return self._type_cast(source_column, target_type)
        return source_column

    def _constant(self, value: str) -> str:
        cleaned = value.strip().strip("'\"")
        return cleaned if cleaned.replace(".", "").replace("-", "").isdigit() else f"'{cleaned}'"

    def _nvl(self, column: str, default: str) -> str:
        default_val = default.strip().strip("'\"")
        if not default_val.replace(".", "").replace("-", "").isdigit():
            default_val = f"'{default_val}'"
        if self.dialect == "oracle":
            return f"NVL({column}, {default_val})"
        return f"COALESCE({column}, {default_val})"

    def _case_when(self, column: str, condition: str, then_val: str,
                   else_val: str) -> str:
        then_str = f"'{then_val}'" if not then_val.strip().replace(".", "").isdigit() else then_val
        lines = [f"CASE WHEN {condition} THEN {then_str}"]
        if else_val:
            else_str = f"'{else_val}'" if not else_val.strip().replace(".", "").isdigit() else else_val
            lines.append(f"       ELSE {else_str}")
        lines.append("  END")
        return "\n".join(lines)

    def _type_cast(self, column: str, target_type: str) -> str:
        if not target_type:
            return column
        return f"CAST({column} AS {target_type})"

    def _aggregate(self, func: str, field: str) -> str:
        has_chinese = any('一' <= c <= '鿿' for c in (field or ""))
        effective = self._src_col if has_chinese else field
        if effective and effective != "*":
            return f"{func}({effective})"
        return f"{func}(*)"

    def _concat(self, fields: list[str]) -> str:
        clean = [f for f in fields if f not in ("和", "与", ",", "，", "+", "||")]
        if len(clean) == 1:
            return clean[0]
        if self.dialect == "oracle":
            return " || ".join(clean)
        return f"CONCAT({', '.join(clean)})"

    def _substring(self, field: str, start: str, length: Optional[str]) -> str:
        if self.dialect == "oracle":
            return f"SUBSTR({field}, {start}, {length})" if length else f"SUBSTR({field}, {start})"
        return f"SUBSTRING({field}, {start}, {length})" if length else f"SUBSTRING({field}, {start})"

    def _date_format(self, field: str, fmt: str) -> str:
        has_chinese = any('一' <= c <= '鿿' for c in (field or ""))
        effective = self._src_col if (has_chinese or not field) else field
        fmt_str = fmt or "YYYYMMDD"
        if self.dialect == "oracle":
            return f"TO_CHAR({effective}, '{fmt_str}')"
        mysql_fmt = fmt_str.replace("YYYY", "%Y").replace("MM", "%m").replace("DD", "%d")
        return f"DATE_FORMAT({effective}, '{mysql_fmt}')"

    def _sql_expression(self, expr: str, source_column: str) -> str:
        return expr.replace("源字段", source_column).replace("字段", source_column)
