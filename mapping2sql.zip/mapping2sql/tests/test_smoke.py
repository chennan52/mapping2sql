"""Smoke tests — parse → generate → format core pipeline.

Run:   python -m pytest tests/test_smoke.py -v
"""

import sys
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.parser import MappingParser
from core.generator import SQLGenerator
from core.models import ColumnMapping, TableMapping, JoinClause
from core.transformer import TransformEngine


# ═══════════════════════════════════════════════════════
# Fixtures
# ═══════════════════════════════════════════════════════

@pytest.fixture(scope="module")
def test_xlsx():
    """Ensure the loan scenario xlsx exists, return its path."""
    p = Path(__file__).parent.parent / "samples" / "test_loan_scenario.xlsx"
    if not p.exists():
        pytest.skip("test_loan_scenario.xlsx not found — run samples/create_loan_scenario.py first")
    return str(p)


@pytest.fixture(scope="module")
def parsed_doc(test_xlsx):
    return MappingParser().parse(test_xlsx)


@pytest.fixture(scope="module")
def generator():
    return SQLGenerator(dialect="oracle")


# ═══════════════════════════════════════════════════════
# 1. Parser smoke
# ═══════════════════════════════════════════════════════

class TestParser:
    def test_parses_excel(self, parsed_doc):
        assert parsed_doc is not None
        assert parsed_doc.table_count == 3

    def test_table_names_are_resolved(self, parsed_doc):
        for tm in parsed_doc.table_mappings:
            assert tm.source_table != "unknown_table"
            assert tm.target_table != "unknown_table"
            assert "." in tm.source_table  # schema.table format

    def test_columns_have_required_fields(self, parsed_doc):
        total = 0
        for tm in parsed_doc.table_mappings:
            assert len(tm.columns) > 0, f"{tm.source_table} has no columns"
            for cm in tm.columns:
                assert cm.source_column, "missing source_column"
                assert cm.target_column, "missing target_column"
                total += 1
        assert total == 43  # 21 + 12 + 10

    def test_pk_detection(self, parsed_doc):
        for tm in parsed_doc.table_mappings:
            pks = tm.get_pk_columns()
            assert len(pks) >= 1, f"{tm.source_table} should have at least 1 PK"

    def test_join_conditions_parsed(self, parsed_doc):
        repay = [tm for tm in parsed_doc.table_mappings
                 if "REPAY" in tm.source_table][0]
        assert len(repay.join_conditions) == 1
        jc = repay.join_conditions[0]
        assert isinstance(jc, JoinClause)
        assert jc.join_type == "LEFT"
        assert "ODS.LN_APPLY" in jc.table
        assert "s.apply_id = a.apply_id" == jc.on_condition


# ═══════════════════════════════════════════════════════
# 2. Generator smoke
# ═══════════════════════════════════════════════════════

class TestGenerator:
    def test_generates_all_types(self, parsed_doc, generator):
        results = generator.generate(parsed_doc, sql_type="all")
        assert len(results) == 12  # 3 tables x 4 types

    def test_ddl_has_create_table(self, parsed_doc, generator):
        for tm in parsed_doc.table_mappings:
            sql = generator.generate_ddl(tm, "TEST")
            assert "CREATE TABLE" in sql.upper()
            assert "PRIMARY KEY" in sql.upper()
            assert tm.target_table.upper() in sql.upper()

    def test_dml_has_insert_select(self, parsed_doc, generator):
        for tm in parsed_doc.table_mappings:
            sql = generator.generate_dml(tm, "TEST")
            assert "INSERT INTO" in sql.upper()
            assert "SELECT" in sql.upper()
            assert "FROM" in sql.upper()

    def test_merge_has_merge_into(self, parsed_doc, generator):
        for tm in parsed_doc.table_mappings:
            sql = generator.generate_merge(tm, "TEST")
            assert "MERGE INTO" in sql.upper()
            assert "WHEN MATCHED" in sql.upper()
            assert "WHEN NOT MATCHED" in sql.upper()

    def test_query_has_select(self, parsed_doc, generator):
        for tm in parsed_doc.table_mappings:
            sql = generator.generate_query(tm, "TEST")
            assert sql.strip().upper().startswith("--") or "SELECT" in sql.upper()

    def test_no_template_syntax_leaks(self, parsed_doc, generator):
        results = generator.generate(parsed_doc, sql_type="all")
        for key, sql in results.items():
            assert "{{" not in sql, f"{key}: leaked {{"
            assert "}}" not in sql, f"{key}: leaked }}"
            assert "{%" not in sql, f"{key}: leaked {{%"
            assert "%}" not in sql, f"{key}: leaked percent-brace"

    def test_dml_has_join(self, parsed_doc, generator):
        repay = [tm for tm in parsed_doc.table_mappings
                 if "REPAY" in tm.source_table][0]
        sql = generator.generate_dml(repay, "TEST")
        assert "LEFT JOIN" in sql
        assert "ON s.apply_id = a.apply_id" in sql

    def test_output_has_no_consecutive_blank_lines(self, parsed_doc, generator):
        results = generator.generate(parsed_doc, sql_type="all")
        for key, sql in results.items():
            prev = None
            for line in sql.splitlines():
                is_blank = (line.strip() == "")
                if prev is True and is_blank:
                    pytest.fail(f"{key}: consecutive blank lines")
                prev = is_blank


# ═══════════════════════════════════════════════════════
# 3. Transformer smoke
# ═══════════════════════════════════════════════════════

class TestTransformer:
    @pytest.mark.parametrize("rule,expected_in", [
        ("直接映射", "col"),              # direct map returns col
        ("空值填0", "NVL"),              # nvl
        ("SUM求和", "SUM"),              # aggregate
        ("日期格式化 YYYYMM", "TO_CHAR"),  # date format
        ("CAST(rate * 100 AS NUMBER(8,4))", "CAST"),  # type cast
    ])
    def test_regex_rules(self, rule, expected_in):
        engine = TransformEngine(dialect="oracle")
        result = engine.transform(source_column="col", rule_text=rule,
                                  source_type="NUMBER", target_type="NUMBER")
        assert expected_in.upper() in result.upper(), \
            f"rule '{rule}': expected '{expected_in}' in '{result}'"

    def test_direct_map_returns_column(self):
        engine = TransformEngine(dialect="oracle")
        result = engine.transform(source_column="my_col", rule_text="直接映射")
        assert result == "my_col"

    def test_mysql_uses_coalesce(self):
        engine = TransformEngine(dialect="mysql")
        result = engine.transform(source_column="col", rule_text="空值填0")
        assert "COALESCE" in result.upper()
        assert "NVL" not in result.upper()

    def test_complex_rule_gets_comment(self):
        """Multi-condition rules beyond regex should get a fallback comment."""
        engine = TransformEngine(dialect="oracle")
        result = engine.transform(
            source_column="status",
            rule_text="当status='A'则为'审批中', 当status='P'则为'已通过', 否则'未知'"
        )
        # Should be handled (either by regex with confidence < 0.8 or fallback)
        assert "status" in result
        assert engine.last_engine in ("regex", "llm", "none")


# ═══════════════════════════════════════════════════════
# 4. Models smoke
# ═══════════════════════════════════════════════════════

class TestModels:
    def test_join_clause_to_sql(self):
        jc = JoinClause(
            join_type="LEFT",
            table="ODS.CUST",
            alias="c",
            on_condition="s.cust_id = c.cust_id",
        )
        sql = jc.to_sql()
        assert "LEFT JOIN" in sql
        assert "ODS.CUST c" in sql
        assert "ON s.cust_id = c.cust_id" in sql

    def test_join_clause_empty_returns_empty(self):
        jc = JoinClause()
        assert jc.to_sql() == ""

    def test_table_mapping_helpers(self):
        tm = TableMapping(source_table="ODS.T1", target_table="DWD.T1")
        cm1 = ColumnMapping(source_table="ODS.T1", source_column="a", target_column="a", is_pk=True)
        cm2 = ColumnMapping(source_table="ODS.T1", source_column="b", target_column="b")
        tm.columns = [cm1, cm2]
        assert tm.get_pk_columns() == ["a"]
        assert tm.get_source_columns() == ["a", "b"]
        assert tm.get_target_columns() == ["a", "b"]


# ═══════════════════════════════════════════════════════
# 5. Round-trip: parse → generate → parse (SQL is valid)
# ═══════════════════════════════════════════════════════

class TestRoundTrip:
    def test_generated_ddl_is_parseable_sql(self, parsed_doc, generator):
        """Generated DDL should at minimum have the right structure."""
        for tm in parsed_doc.table_mappings:
            sql = generator.generate_ddl(tm, "TEST")
            assert ";" in sql, "DDL should end with ;"
            assert "CREATE TABLE" in sql.upper()

    def test_all_columns_appear_in_dml(self, parsed_doc, generator):
        """Every target column should appear in INSERT column list."""
        for tm in parsed_doc.table_mappings:
            sql = generator.generate_dml(tm, "TEST")
            for cm in tm.columns:
                assert cm.target_column in sql, \
                    f"{cm.target_column} missing from DML for {tm.source_table}"
