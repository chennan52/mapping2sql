"""Setup script for Mapping2SQL package."""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="mapping2sql",
    version="1.0.0",
    description="Mapping文档自动生成标准化SQL代码 — 银行数据中台智能工具",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Data Platform Team",
    python_requires=">=3.10",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "pandas>=1.5.0",
        "openpyxl>=3.1.0",
        "python-docx>=0.8.11",
        "click>=8.1.0",
        "streamlit>=1.28.0",
        "sqlparse>=0.4.4",
        "pyyaml>=6.0",
        "jinja2>=3.1.0",
    ],
    extras_require={
        "llm": ["anthropic>=0.30.0"],  # pip install .[llm] 一键安装 LLM 增强
    },
    entry_points={
        "console_scripts": [
            "mapping2sql=cli:cli",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Database",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
