-- ==== DWD.DWD_LN_APPLY_ddl ====
-- ============================================================
-- 程序名称: CREATE_DWD_LN_APPLY
-- 功能描述: 贷款申请主表——含申请信息、审批状态、额度核定等
-- 源表: ODS.LN_APPLY
-- 目标表: DWD.DWD_LN_APPLY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-10
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

CREATE TABLE DWD.DWD_LN_APPLY (
    apply_id  VARCHAR2(32),
    cust_id  VARCHAR2(18),
    cust_name  VARCHAR2(100),
    org_code  VARCHAR2(12),
    product_code  VARCHAR2(8),
    product_name  VARCHAR2(100),
    apply_amt  NUMBER(18,2),
    approve_amt  NUMBER(18,2),
    apply_date  DATE,
    approve_month  VARCHAR2(6),
    status_desc  VARCHAR2(50),
    risk_level_desc  VARCHAR2(30),
    rate_type_desc  VARCHAR2(20),
    rate_pct  NUMBER(8,4),
    term_months  NUMBER(3),
    guarantee_desc  VARCHAR2(30),
    mgr_id  VARCHAR2(50),
    id_mask  VARCHAR2(18),
    create_time  DATE,
    update_time  DATE,
    etl_date  DATE,
    CONSTRAINT pk_DWD_LN_APPLY PRIMARY KEY (apply_id)
);

COMMENT ON TABLE DWD.DWD_LN_APPLY IS '贷款申请主表——含申请信息、审批状态、额度核定等';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.apply_id IS '申请编号(主键)';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.cust_id IS '客户号';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.cust_name IS '客户姓名';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.org_code IS '受理机构';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.product_code IS '贷款产品代码';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.product_name IS '贷款产品名称';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.apply_amt IS '申请金额';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.approve_amt IS '审批金额';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.apply_date IS '申请日期';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.approve_month IS '审批月份(格式化为YYYYMM)';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.status_desc IS '申请状态(多条件CASE WHEN转换)';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.risk_level_desc IS '风险等级(条件转换)';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.rate_type_desc IS '利率类型描述';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.rate_pct IS '年利率(百分比) —— CAST类型转换+运算';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.term_months IS '贷款期限(月)';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.guarantee_desc IS '担保方式(多条件映射)';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.mgr_id IS '客户经理ID-姓名 —— LLM解析: 字符串拼接';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.id_mask IS '身份证号脱敏 —— SUBSTR拼接';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.create_time IS '创建时间';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.update_time IS '更新时间';
COMMENT ON COLUMN DWD.DWD_LN_APPLY.etl_date IS 'ETL日期';


-- ==== DWD.DWD_LN_APPLY_dml ====
-- ============================================================
-- 程序名称: ETL_LN_APPLY_TO_DWD_LN_APPLY
-- 功能描述: 从 ODS.LN_APPLY 同步数据到 DWD.DWD_LN_APPLY
-- 源表: ODS.LN_APPLY
-- 目标表: DWD.DWD_LN_APPLY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-10
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

INSERT INTO DWD.DWD_LN_APPLY
(
    apply_id
    ,cust_id
    ,cust_name
    ,org_code
    ,product_code
    ,product_name
    ,apply_amt
    ,approve_amt
    ,apply_date
    ,approve_month
    ,status_desc
    ,risk_level_desc
    ,rate_type_desc
    ,rate_pct
    ,term_months
    ,guarantee_desc
    ,mgr_id
    ,id_mask
    ,create_time
    ,update_time
    ,etl_date
)
SELECT
    apply_id  -- 申请编号(主键)
    ,cust_id  -- 客户号
    ,CAST(cust_name AS VARCHAR2(100))  -- 客户姓名
    ,org_code  -- 受理机构
    ,product_code  -- 贷款产品代码
    ,CAST(product_name AS VARCHAR2(100))  -- 贷款产品名称
    ,NVL(apply_amt, 0)  -- 申请金额
    ,NVL(approve_amt, 0)  -- 审批金额
    ,apply_date  -- 申请日期
    ,TO_CHAR(approve_date, 'YYYYMM')  -- 审批月份(格式化为YYYYMM)
    ,status  /* 转换规则: 当status='A'则为'审批中', 当status='P'则为'已通过', 当status='R'则为'已拒绝', 当status='D'则为'已撤销', 否则'未知' — 需人工确认 */  AS status_desc  -- 申请状态(多条件CASE WHEN转换)
    ,risk_level  /* 转换规则: 当risk_level='H'则为'高风险', 当risk_level='M'则为'中风险', 否则为'低风险' — 需人工确认 */  AS risk_level_desc  -- 风险等级(条件转换)
    ,rate_type  /* 转换规则: 当rate_type='FIXED'则为'固定利率', 当rate_type='FLOAT'则为'浮动利率', 否则'混合利率' — 需人工确认 */  AS rate_type_desc  -- 利率类型描述
    ,CAST(rate AS NUMBER(8,4))  -- 年利率(百分比) —— CAST类型转换+运算
    ,term_months  -- 贷款期限(月)
    ,guarantee_type  /* 转换规则: 当guarantee_type='CRED'则为'信用', 当guarantee_type='MORT'则为'抵押', 当guarantee_type='PLDG'则为'质押', 当guarantee_type='GUAR'则为'保证', 当guarantee_type='COMB'则为'组合', 否则'其他' — 需人工确认 */  AS guarantee_desc  -- 担保方式(多条件映射)
    ,customer_manager  /* 转换规则: 客户经理的工号和姓名拼接（如MGR001-张三） — 需人工确认 */  AS mgr_id  -- 客户经理ID-姓名 —— LLM解析: 字符串拼接
    ,id_number  /* 转换规则: 取前6位和后4位，中间用****替换 — 需人工确认 */  AS id_mask  -- 身份证号脱敏 —— SUBSTR拼接
    ,create_time  -- 创建时间
    ,update_time  -- 更新时间
    ,etl_date  -- ETL日期
FROM ODS.LN_APPLY  s
;


-- ==== DWD.DWD_LN_APPLY_merge ====
-- ============================================================
-- 程序名称: MERGE_LN_APPLY_TO_DWD_LN_APPLY
-- 功能描述: 增量同步 ODS.LN_APPLY -> DWD.DWD_LN_APPLY
-- 源表: ODS.LN_APPLY
-- 目标表: DWD.DWD_LN_APPLY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-10
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

MERGE INTO DWD.DWD_LN_APPLY  t
USING (
    SELECT
            apply_id  -- 申请编号(主键)
            ,cust_id  -- 客户号
            ,CAST(cust_name AS VARCHAR2(100))  -- 客户姓名
            ,org_code  -- 受理机构
            ,product_code  -- 贷款产品代码
            ,CAST(product_name AS VARCHAR2(100))  -- 贷款产品名称
            ,NVL(apply_amt, 0)  -- 申请金额
            ,NVL(approve_amt, 0)  -- 审批金额
            ,apply_date  -- 申请日期
            ,TO_CHAR(approve_date, 'YYYYMM')  -- 审批月份(格式化为YYYYMM)
            ,status  /* 转换规则: 当status='A'则为'审批中', 当status='P'则为'已通过', 当status='R'则为'已拒绝', 当status='D'则为'已撤销', 否则'未知' — 需人工确认 */  AS status_desc  -- 申请状态(多条件CASE WHEN转换)
            ,risk_level  /* 转换规则: 当risk_level='H'则为'高风险', 当risk_level='M'则为'中风险', 否则为'低风险' — 需人工确认 */  AS risk_level_desc  -- 风险等级(条件转换)
            ,rate_type  /* 转换规则: 当rate_type='FIXED'则为'固定利率', 当rate_type='FLOAT'则为'浮动利率', 否则'混合利率' — 需人工确认 */  AS rate_type_desc  -- 利率类型描述
            ,CAST(rate AS NUMBER(8,4))  -- 年利率(百分比) —— CAST类型转换+运算
            ,term_months  -- 贷款期限(月)
            ,guarantee_type  /* 转换规则: 当guarantee_type='CRED'则为'信用', 当guarantee_type='MORT'则为'抵押', 当guarantee_type='PLDG'则为'质押', 当guarantee_type='GUAR'则为'保证', 当guarantee_type='COMB'则为'组合', 否则'其他' — 需人工确认 */  AS guarantee_desc  -- 担保方式(多条件映射)
            ,customer_manager  /* 转换规则: 客户经理的工号和姓名拼接（如MGR001-张三） — 需人工确认 */  AS mgr_id  -- 客户经理ID-姓名 —— LLM解析: 字符串拼接
            ,id_number  /* 转换规则: 取前6位和后4位，中间用****替换 — 需人工确认 */  AS id_mask  -- 身份证号脱敏 —— SUBSTR拼接
            ,create_time  -- 创建时间
            ,update_time  -- 更新时间
            ,etl_date  -- ETL日期
    FROM ODS.LN_APPLY  s
)  src

ON (t.apply_id = src.apply_id)
WHEN MATCHED THEN
    UPDATE SET
        t.cust_id = src.cust_id
        ,t.cust_name = src.cust_name
        ,t.org_code = src.org_code
        ,t.product_code = src.product_code
        ,t.product_name = src.product_name
        ,t.apply_amt = src.apply_amt
        ,t.approve_amt = src.approve_amt
        ,t.apply_date = src.apply_date
        ,t.approve_month = src.approve_month
        ,t.status_desc = src.status_desc
        ,t.risk_level_desc = src.risk_level_desc
        ,t.rate_type_desc = src.rate_type_desc
        ,t.rate_pct = src.rate_pct
        ,t.term_months = src.term_months
        ,t.guarantee_desc = src.guarantee_desc
        ,t.mgr_id = src.mgr_id
        ,t.id_mask = src.id_mask
        ,t.create_time = src.create_time
        ,t.update_time = src.update_time
        ,t.etl_date = src.etl_date
WHEN NOT MATCHED THEN
    INSERT (
            apply_id
            ,cust_id
            ,cust_name
            ,org_code
            ,product_code
            ,product_name
            ,apply_amt
            ,approve_amt
            ,apply_date
            ,approve_month
            ,status_desc
            ,risk_level_desc
            ,rate_type_desc
            ,rate_pct
            ,term_months
            ,guarantee_desc
            ,mgr_id
            ,id_mask
            ,create_time
            ,update_time
            ,etl_date
    ) VALUES (
            src.apply_id
            ,src.cust_id
            ,src.cust_name
            ,src.org_code
            ,src.product_code
            ,src.product_name
            ,src.apply_amt
            ,src.approve_amt
            ,src.apply_date
            ,src.approve_month
            ,src.status_desc
            ,src.risk_level_desc
            ,src.rate_type_desc
            ,src.rate_pct
            ,src.term_months
            ,src.guarantee_desc
            ,src.mgr_id
            ,src.id_mask
            ,src.create_time
            ,src.update_time
            ,src.etl_date
    )
;


-- ==== DWD.DWD_LN_APPLY_query ====
-- ============================================================
-- 程序名称: QUERY_DWD_LN_APPLY
-- 功能描述: 查询 DWD_LN_APPLY
-- 源表: DWD.DWD_LN_APPLY
-- 目标表: DWD.DWD_LN_APPLY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-10
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

SELECT
    apply_id  -- 申请编号(主键)
    ,cust_id  -- 客户号
    ,cust_name  -- 客户姓名
    ,org_code  -- 受理机构
    ,product_code  -- 贷款产品代码
    ,product_name  -- 贷款产品名称
    ,apply_amt  -- 申请金额
    ,approve_amt  -- 审批金额
    ,apply_date  -- 申请日期
    ,approve_month  -- 审批月份(格式化为YYYYMM)
    ,status_desc  -- 申请状态(多条件CASE WHEN转换)
    ,risk_level_desc  -- 风险等级(条件转换)
    ,rate_type_desc  -- 利率类型描述
    ,rate_pct  -- 年利率(百分比) —— CAST类型转换+运算
    ,term_months  -- 贷款期限(月)
    ,guarantee_desc  -- 担保方式(多条件映射)
    ,mgr_id  -- 客户经理ID-姓名 —— LLM解析: 字符串拼接
    ,id_mask  -- 身份证号脱敏 —— SUBSTR拼接
    ,create_time  -- 创建时间
    ,update_time  -- 更新时间
    ,etl_date  -- ETL日期
FROM DWD.DWD_LN_APPLY  t
;


-- ==== DWD.DWD_LN_REPAY_ddl ====
-- ============================================================
-- 程序名称: CREATE_DWD_LN_REPAY
-- 功能描述: 还款流水表——记录每笔还款明细
-- 源表: ODS.LN_REPAY
-- 目标表: DWD.DWD_LN_REPAY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-10
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

CREATE TABLE DWD.DWD_LN_REPAY (
    repay_id  VARCHAR2(32),
    apply_id  VARCHAR2(32),
    cust_id  VARCHAR2(18),
    repay_amt  NUMBER(18,2),
    repay_principal  NUMBER(18,2),
    repay_interest  NUMBER(18,2),
    repay_date  DATE,
    repay_month  VARCHAR2(6),
    channel_desc  VARCHAR2(30),
    overdue_flag  VARCHAR2(10),
    remark  VARCHAR2(200),
    etl_date  DATE,
    CONSTRAINT pk_DWD_LN_REPAY PRIMARY KEY (repay_id)
);

COMMENT ON TABLE DWD.DWD_LN_REPAY IS '还款流水表——记录每笔还款明细';
COMMENT ON COLUMN DWD.DWD_LN_REPAY.repay_id IS '还款流水号(PK)';
COMMENT ON COLUMN DWD.DWD_LN_REPAY.apply_id IS '关联申请编号';
COMMENT ON COLUMN DWD.DWD_LN_REPAY.cust_id IS '客户号';
COMMENT ON COLUMN DWD.DWD_LN_REPAY.repay_amt IS '还款金额(NVL)';
COMMENT ON COLUMN DWD.DWD_LN_REPAY.repay_principal IS '还款本金';
COMMENT ON COLUMN DWD.DWD_LN_REPAY.repay_interest IS '还款利息';
COMMENT ON COLUMN DWD.DWD_LN_REPAY.repay_date IS '还款日期';
COMMENT ON COLUMN DWD.DWD_LN_REPAY.repay_month IS '还款月份(日期格式化)';
COMMENT ON COLUMN DWD.DWD_LN_REPAY.channel_desc IS '还款渠道描述';
COMMENT ON COLUMN DWD.DWD_LN_REPAY.overdue_flag IS '逾期标识(数值范围条件)';
COMMENT ON COLUMN DWD.DWD_LN_REPAY.remark IS '备注';
COMMENT ON COLUMN DWD.DWD_LN_REPAY.etl_date IS 'ETL日期';


-- ==== DWD.DWD_LN_REPAY_dml ====
-- ============================================================
-- 程序名称: ETL_LN_REPAY_TO_DWD_LN_REPAY
-- 功能描述: 从 ODS.LN_REPAY 同步数据到 DWD.DWD_LN_REPAY
-- 源表: ODS.LN_REPAY
-- 目标表: DWD.DWD_LN_REPAY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-10
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

INSERT INTO DWD.DWD_LN_REPAY
(
    repay_id
    ,apply_id
    ,cust_id
    ,repay_amt
    ,repay_principal
    ,repay_interest
    ,repay_date
    ,repay_month
    ,channel_desc
    ,overdue_flag
    ,remark
    ,etl_date
)
SELECT
    repay_id  -- 还款流水号(PK)
    ,apply_id  -- 关联申请编号
    ,cust_id  -- 客户号
    ,repay_amt  /* 转换规则: 如果repay_amt为空则填0 — 需人工确认 */  -- 还款金额(NVL)
    ,NVL(repay_principal, 0)  -- 还款本金
    ,NVL(repay_interest, 0)  -- 还款利息
    ,repay_date  -- 还款日期
    ,repay_date  /* 转换规则: 对repay_date做日期格式化，取到月份 YYYYMM — 需人工确认 */  AS repay_month  -- 还款月份(日期格式化)
    ,repay_channel  /* 转换规则: 当repay_channel='ONLN'则为'线上', 当repay_channel='CNTR'则为'柜面', 当repay_channel='MOBL'则为'手机银行', 当repay_channel='AUTR'则为'自助终端', 否则'其他' — 需人工确认 */  AS channel_desc  -- 还款渠道描述
    ,当overdue_days=0则为'正常', 当overdue_days>0且overdue_days<=30则为'M1', 当overdue_days>30且overdue_days<=60则为'M2', 当overdue_days>60则为'M3 || '  AS overdue_flag  -- 逾期标识(数值范围条件)
    ,remark  -- 备注
    ,etl_date  -- ETL日期
FROM ODS.LN_REPAY  s
;


-- ==== DWD.DWD_LN_REPAY_merge ====
-- ============================================================
-- 程序名称: MERGE_LN_REPAY_TO_DWD_LN_REPAY
-- 功能描述: 增量同步 ODS.LN_REPAY -> DWD.DWD_LN_REPAY
-- 源表: ODS.LN_REPAY
-- 目标表: DWD.DWD_LN_REPAY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-10
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

MERGE INTO DWD.DWD_LN_REPAY  t
USING (
    SELECT
            repay_id  -- 还款流水号(PK)
            ,apply_id  -- 关联申请编号
            ,cust_id  -- 客户号
            ,repay_amt  /* 转换规则: 如果repay_amt为空则填0 — 需人工确认 */  -- 还款金额(NVL)
            ,NVL(repay_principal, 0)  -- 还款本金
            ,NVL(repay_interest, 0)  -- 还款利息
            ,repay_date  -- 还款日期
            ,repay_date  /* 转换规则: 对repay_date做日期格式化，取到月份 YYYYMM — 需人工确认 */  AS repay_month  -- 还款月份(日期格式化)
            ,repay_channel  /* 转换规则: 当repay_channel='ONLN'则为'线上', 当repay_channel='CNTR'则为'柜面', 当repay_channel='MOBL'则为'手机银行', 当repay_channel='AUTR'则为'自助终端', 否则'其他' — 需人工确认 */  AS channel_desc  -- 还款渠道描述
            ,当overdue_days=0则为'正常', 当overdue_days>0且overdue_days<=30则为'M1', 当overdue_days>30且overdue_days<=60则为'M2', 当overdue_days>60则为'M3 || '  AS overdue_flag  -- 逾期标识(数值范围条件)
            ,remark  -- 备注
            ,etl_date  -- ETL日期
    FROM ODS.LN_REPAY  s
)  src

ON (t.repay_id = src.repay_id)
WHEN MATCHED THEN
    UPDATE SET
        t.apply_id = src.apply_id
        ,t.cust_id = src.cust_id
        ,t.repay_amt = src.repay_amt
        ,t.repay_principal = src.repay_principal
        ,t.repay_interest = src.repay_interest
        ,t.repay_date = src.repay_date
        ,t.repay_month = src.repay_month
        ,t.channel_desc = src.channel_desc
        ,t.overdue_flag = src.overdue_flag
        ,t.remark = src.remark
        ,t.etl_date = src.etl_date
WHEN NOT MATCHED THEN
    INSERT (
            repay_id
            ,apply_id
            ,cust_id
            ,repay_amt
            ,repay_principal
            ,repay_interest
            ,repay_date
            ,repay_month
            ,channel_desc
            ,overdue_flag
            ,remark
            ,etl_date
    ) VALUES (
            src.repay_id
            ,src.apply_id
            ,src.cust_id
            ,src.repay_amt
            ,src.repay_principal
            ,src.repay_interest
            ,src.repay_date
            ,src.repay_month
            ,src.channel_desc
            ,src.overdue_flag
            ,src.remark
            ,src.etl_date
    )
;


-- ==== DWD.DWD_LN_REPAY_query ====
-- ============================================================
-- 程序名称: QUERY_DWD_LN_REPAY
-- 功能描述: 查询 DWD_LN_REPAY
-- 源表: DWD.DWD_LN_REPAY
-- 目标表: DWD.DWD_LN_REPAY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-10
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

SELECT
    repay_id  -- 还款流水号(PK)
    ,apply_id  -- 关联申请编号
    ,cust_id  -- 客户号
    ,repay_amt  -- 还款金额(NVL)
    ,repay_principal  -- 还款本金
    ,repay_interest  -- 还款利息
    ,repay_date  -- 还款日期
    ,repay_month  -- 还款月份(日期格式化)
    ,channel_desc  -- 还款渠道描述
    ,overdue_flag  -- 逾期标识(数值范围条件)
    ,remark  -- 备注
    ,etl_date  -- ETL日期
FROM DWD.DWD_LN_REPAY  t
;


-- ==== DWD.DWD_LN_SUMMARY_ddl ====
-- ============================================================
-- 程序名称: CREATE_DWD_LN_SUMMARY
-- 功能描述: 贷款日汇总表——按产品+机构+日期聚合
-- 源表: ODS.LN_SUMMARY
-- 目标表: DWD.DWD_LN_SUMMARY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-10
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

CREATE TABLE DWD.DWD_LN_SUMMARY (
    product_code  VARCHAR2(8),
    org_code  VARCHAR2(12),
    stat_date  DATE,
    apply_count  NUMBER(10),
    total_apply_amt  NUMBER(20,2),
    total_approve_amt  NUMBER(20,2),
    avg_approve_amt  NUMBER(20,2),
    max_approve_amt  NUMBER(20,2),
    min_approve_amt  NUMBER(20,2),
    etl_date  DATE,
    CONSTRAINT pk_DWD_LN_SUMMARY PRIMARY KEY (product_code, org_code, stat_date)
);

COMMENT ON TABLE DWD.DWD_LN_SUMMARY IS '贷款日汇总表——按产品+机构+日期聚合';
COMMENT ON COLUMN DWD.DWD_LN_SUMMARY.product_code IS '贷款产品代码(PK)';
COMMENT ON COLUMN DWD.DWD_LN_SUMMARY.org_code IS '机构号(PK)';
COMMENT ON COLUMN DWD.DWD_LN_SUMMARY.stat_date IS '统计日期(PK)';
COMMENT ON COLUMN DWD.DWD_LN_SUMMARY.apply_count IS '申请笔数(COUNT聚合)';
COMMENT ON COLUMN DWD.DWD_LN_SUMMARY.total_apply_amt IS '申请总金额(SUM聚合)';
COMMENT ON COLUMN DWD.DWD_LN_SUMMARY.total_approve_amt IS '审批总金额(SUM聚合)';
COMMENT ON COLUMN DWD.DWD_LN_SUMMARY.avg_approve_amt IS '平均审批金额(AVG聚合)';
COMMENT ON COLUMN DWD.DWD_LN_SUMMARY.max_approve_amt IS '最大审批金额(MAX聚合)';
COMMENT ON COLUMN DWD.DWD_LN_SUMMARY.min_approve_amt IS '最小审批金额(MIN聚合)';
COMMENT ON COLUMN DWD.DWD_LN_SUMMARY.etl_date IS 'ETL日期';


-- ==== DWD.DWD_LN_SUMMARY_dml ====
-- ============================================================
-- 程序名称: ETL_LN_SUMMARY_TO_DWD_LN_SUMMARY
-- 功能描述: 从 ODS.LN_SUMMARY 同步数据到 DWD.DWD_LN_SUMMARY
-- 源表: ODS.LN_SUMMARY
-- 目标表: DWD.DWD_LN_SUMMARY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-10
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

INSERT INTO DWD.DWD_LN_SUMMARY
(
    product_code
    ,org_code
    ,stat_date
    ,apply_count
    ,total_apply_amt
    ,total_approve_amt
    ,avg_approve_amt
    ,max_approve_amt
    ,min_approve_amt
    ,etl_date
)
SELECT
    product_code  -- 贷款产品代码(PK)
    ,org_code  -- 机构号(PK)
    ,stat_date  -- 统计日期(PK)
    ,COUNT(apply_id)  -- 申请笔数(COUNT聚合)
    ,SUM(apply_amt)  -- 申请总金额(SUM聚合)
    ,SUM(approve_amt)  -- 审批总金额(SUM聚合)
    ,AVG(approve_amt)  -- 平均审批金额(AVG聚合)
    ,MAX(approve_amt)  -- 最大审批金额(MAX聚合)
    ,MIN(approve_amt)  -- 最小审批金额(MIN聚合)
    ,etl_date  -- ETL日期
FROM ODS.LN_SUMMARY  s
;


-- ==== DWD.DWD_LN_SUMMARY_merge ====
-- ============================================================
-- 程序名称: MERGE_LN_SUMMARY_TO_DWD_LN_SUMMARY
-- 功能描述: 增量同步 ODS.LN_SUMMARY -> DWD.DWD_LN_SUMMARY
-- 源表: ODS.LN_SUMMARY
-- 目标表: DWD.DWD_LN_SUMMARY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-10
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

MERGE INTO DWD.DWD_LN_SUMMARY  t
USING (
    SELECT
            product_code  -- 贷款产品代码(PK)
            ,org_code  -- 机构号(PK)
            ,stat_date  -- 统计日期(PK)
            ,COUNT(apply_id)  -- 申请笔数(COUNT聚合)
            ,SUM(apply_amt)  -- 申请总金额(SUM聚合)
            ,SUM(approve_amt)  -- 审批总金额(SUM聚合)
            ,AVG(approve_amt)  -- 平均审批金额(AVG聚合)
            ,MAX(approve_amt)  -- 最大审批金额(MAX聚合)
            ,MIN(approve_amt)  -- 最小审批金额(MIN聚合)
            ,etl_date  -- ETL日期
    FROM ODS.LN_SUMMARY  s
)  src

ON (t.product_code = src.product_code)
WHEN MATCHED THEN
    UPDATE SET
        t.apply_count = src.apply_count
        ,t.total_apply_amt = src.total_apply_amt
        ,t.total_approve_amt = src.total_approve_amt
        ,t.avg_approve_amt = src.avg_approve_amt
        ,t.max_approve_amt = src.max_approve_amt
        ,t.min_approve_amt = src.min_approve_amt
        ,t.etl_date = src.etl_date
WHEN NOT MATCHED THEN
    INSERT (
            product_code
            ,org_code
            ,stat_date
            ,apply_count
            ,total_apply_amt
            ,total_approve_amt
            ,avg_approve_amt
            ,max_approve_amt
            ,min_approve_amt
            ,etl_date
    ) VALUES (
            src.product_code
            ,src.org_code
            ,src.stat_date
            ,src.apply_count
            ,src.total_apply_amt
            ,src.total_approve_amt
            ,src.avg_approve_amt
            ,src.max_approve_amt
            ,src.min_approve_amt
            ,src.etl_date
    )
;


-- ==== DWD.DWD_LN_SUMMARY_query ====
-- ============================================================
-- 程序名称: QUERY_DWD_LN_SUMMARY
-- 功能描述: 查询 DWD_LN_SUMMARY
-- 源表: DWD.DWD_LN_SUMMARY
-- 目标表: DWD.DWD_LN_SUMMARY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-10
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

SELECT
    product_code  -- 贷款产品代码(PK)
    ,org_code  -- 机构号(PK)
    ,stat_date  -- 统计日期(PK)
    ,apply_count  -- 申请笔数(COUNT聚合)
    ,total_apply_amt  -- 申请总金额(SUM聚合)
    ,total_approve_amt  -- 审批总金额(SUM聚合)
    ,avg_approve_amt  -- 平均审批金额(AVG聚合)
    ,max_approve_amt  -- 最大审批金额(MAX聚合)
    ,min_approve_amt  -- 最小审批金额(MIN聚合)
    ,etl_date  -- ETL日期
FROM DWD.DWD_LN_SUMMARY  t
;

