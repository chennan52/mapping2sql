"""Script to create sample Word mapping document."""
from docx import Document
from docx.shared import Pt, Inches, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

doc = Document()

# Title
title = doc.add_heading("数据映射文档 — Mapping Document", level=1)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER

# Meta info
doc.add_paragraph("")
meta_table = doc.add_table(rows=4, cols=2, style="Light Grid Accent 1")
meta_data = [
    ("系统名称", "核心银行系统 -> 数据仓库"),
    ("文档版本", "v1.0"),
    ("创建日期", "2026-05-07"),
    ("作者", "数据开发团队"),
]
for i, (k, v) in enumerate(meta_data):
    meta_table.rows[i].cells[0].text = k
    meta_table.rows[i].cells[1].text = v

doc.add_paragraph("")

# ── Table Mapping ──
doc.add_heading("一、表级映射", level=2)
doc.add_paragraph("以下表格定义了源表到目标表的映射关系：")

tbl_headers = ["源系统", "源表名", "目标表名", "表描述", "增量键"]
table1 = doc.add_table(rows=3, cols=5, style="Light Grid Accent 1")
for i, h in enumerate(tbl_headers):
    cell = table1.rows[0].cells[i]
    cell.text = h
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True

table1_data = [
    ["核心系统", "ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "账户日汇总表", "etl_date"],
    ["核心系统", "ODS.CUST_INFO", "DWD.DWD_CUST_INFO", "客户信息表", "etl_date"],
]
for i, row_data in enumerate(table1_data):
    for j, val in enumerate(row_data):
        table1.rows[i+1].cells[j].text = val

doc.add_paragraph("")

# ── Column Mapping ──
doc.add_heading("二、字段映射 — 账户日汇总表", level=2)
doc.add_paragraph("ODS.ACCT_DAILY -> DWD.DWD_ACCT_DAILY 字段级映射：")

col_headers = ["源字段名", "源类型", "目标字段名", "目标类型", "转换规则", "备注"]
table2 = doc.add_table(rows=12, cols=6, style="Light Grid Accent 1")
for i, h in enumerate(col_headers):
    cell = table2.rows[0].cells[i]
    cell.text = h
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True

col_data = [
    ["acct_no", "VARCHAR2(20)", "acct_no", "VARCHAR2(20)", "直接映射", "账号(PK)"],
    ["cust_id", "VARCHAR2(18)", "cust_id", "VARCHAR2(18)", "直接映射", "客户号"],
    ["org_code", "VARCHAR2(12)", "org_code", "VARCHAR2(12)", "直接映射", "机构号"],
    ["balance", "NUMBER(18,2)", "balance", "NUMBER(18,2)", "直接映射", "余额"],
    ["status", "CHAR(1)", "status_name", "VARCHAR2(20)",
     "当status=1则'正常'否则当status=2则'冻结'否则'未知'", "账户状态名称"],
    ["open_date", "DATE", "open_month", "VARCHAR2(6)",
     "日期格式化 YYYYMM", "开户月份"],
    ["last_txn_date", "DATE", "last_txn_date", "DATE",
     "空值填1900-01-01", "最后交易日期(NVL)"],
    ["frozen_amt", "NUMBER(18,2)", "frozen_amt", "NUMBER(18,2)",
     "空值填0", "冻结金额(NVL)"],
    ["prod_code", "VARCHAR2(8)", "prod_code", "VARCHAR2(8)", "直接映射", "产品代码"],
    ["acct_type", "VARCHAR2(4)", "acct_type", "VARCHAR2(4)", "直接映射", "账户类型"],
    ["etl_date", "DATE", "etl_date", "DATE", "直接映射", "ETL日期"],
]
for i, row_data in enumerate(col_data):
    for j, val in enumerate(row_data):
        table2.rows[i+1].cells[j].text = val

doc.add_paragraph("")

# ── Business Rules ──
doc.add_heading("三、业务规则说明", level=2)

doc.add_paragraph("1. CASE WHEN 状态转换", style="List Number")
doc.add_paragraph(
    "   status 字段从 CHAR(1) 代码转为 VARCHAR2(20) 中文名称：\n"
    "   - status=1 -> '正常'\n"
    "   - status=2 -> '冻结'\n"
    "   - 其他 -> '未知'"
)

doc.add_paragraph("2. NVL 空值处理", style="List Number")
doc.add_paragraph(
    "   - last_txn_date: 若源值为NULL，默认填 '1900-01-01'\n"
    "   - frozen_amt: 若源值为NULL，默认填 0"
)

doc.add_paragraph("3. 日期格式化", style="List Number")
doc.add_paragraph("   - open_date (DATE类型) -> open_month (VARCHAR2(6)): 格式化为 YYYYMM")

doc.add_paragraph("4. 过滤条件", style="List Number")
doc.add_paragraph("   - 仅同步 etl_date = 当前跑批日期的数据\n"
                   "   - 排除 status = '9' (已注销)的账户")

doc.save("sample_mapping.docx")
print("Created sample_mapping.docx successfully")
