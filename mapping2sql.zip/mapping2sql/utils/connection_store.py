"""Persistent multi-connection configuration store.

Stores API connections in ~/.mapping2sql/connections.json.
API keys are base64-encoded (NOT encrypted — just obfuscation).
"""

import json
import base64
from pathlib import Path
from datetime import datetime
from typing import Optional


class ConnectionStore:
    """Manages named API connections with persistent storage."""

    def __init__(self, store_path: str = None):
        if store_path:
            self._path = Path(store_path)
        else:
            self._path = Path.home() / ".mapping2sql" / "connections.json"
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._data = self._load()

    # ── File I/O ───────────────────────────────────────

    def _load(self) -> dict:
        if self._path.exists():
            try:
                return json.loads(self._path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
        return {"connections": [], "active": None}

    def _save(self) -> None:
        self._path.write_text(
            json.dumps(self._data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    # ── Key encoding ────────────────────────────────────

    @staticmethod
    def _encode_key(key: str) -> str:
        return base64.b64encode(key.encode("utf-8")).decode("utf-8")

    @staticmethod
    def _decode_key(encoded: str) -> str:
        try:
            return base64.b64decode(encoded.encode("utf-8")).decode("utf-8")
        except Exception:
            return encoded  # Fallback for unencoded keys

    # ── CRUD ────────────────────────────────────────────

    def list_connections(self) -> list[dict]:
        """Return all saved connections (keys still encoded, names only)."""
        return [
            {"name": c["name"], "base_url": c.get("base_url", ""),
             "model": c.get("model", "claude-haiku-4-5-20251001"),
             "created_at": c.get("created_at", "")}
            for c in self._data["connections"]
        ]

    def get_connection(self, name: str) -> Optional[dict]:
        """Get full connection details with decoded key."""
        for c in self._data["connections"]:
            if c["name"] == name:
                return {
                    "name": c["name"],
                    "api_key": self._decode_key(c["api_key"]),
                    "base_url": c.get("base_url", ""),
                    "model": c.get("model", "claude-haiku-4-5-20251001"),
                }
        return None

    def add_connection(self, name: str, api_key: str, base_url: str = "",
                       model: str = "claude-haiku-4-5-20251001") -> bool:
        """Add or update a named connection. Returns True if new."""
        encoded_key = self._encode_key(api_key)
        for c in self._data["connections"]:
            if c["name"] == name:
                c["api_key"] = encoded_key
                c["base_url"] = base_url
                c["model"] = model
                c["updated_at"] = datetime.now().isoformat()
                self._save()
                return False
        self._data["connections"].append({
            "name": name,
            "api_key": encoded_key,
            "base_url": base_url,
            "model": model,
            "created_at": datetime.now().isoformat(),
        })
        self._save()
        return True

    def delete_connection(self, name: str) -> bool:
        """Remove a connection by name."""
        before = len(self._data["connections"])
        self._data["connections"] = [
            c for c in self._data["connections"] if c["name"] != name
        ]
        if self._data["active"] == name:
            self._data["active"] = None
        self._save()
        return len(self._data["connections"]) < before

    # ── Active connection ───────────────────────────────

    @property
    def active_name(self) -> Optional[str]:
        return self._data.get("active")

    @active_name.setter
    def active_name(self, name: Optional[str]) -> None:
        self._data["active"] = name
        self._save()

    def get_active(self) -> Optional[dict]:
        """Get the currently active connection details (with decoded key)."""
        if self._data.get("active"):
            return self.get_connection(self._data["active"])
        return None
