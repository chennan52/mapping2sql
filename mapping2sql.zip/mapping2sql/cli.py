#!/usr/bin/env python
"""Mapping2SQL CLI - Mapping document to standardized SQL code generator.

Usage:
    mapping2sql generate -i mapping.xlsx -o output.sql
    mapping2sql generate -i mapping.csv --type ddl --dialect mysql
    mapping2sql validate -i mapping.xlsx
    mapping2sql batch -d ./mappings/ -o ./output/
"""

import sys
import io
import os

# Force UTF-8 mode on Windows for proper Chinese character handling
if sys.platform == "win32":
    os.environ["PYTHONUTF8"] = "1"
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

from pathlib import Path

import click

from core.parser import MappingParser
from core.generator import SQLGenerator
from core.validator import SQLValidator
from core.llm_engine import LLMEngine
from utils.connection_store import ConnectionStore


def _safe_echo(message):
    """Echo message, filtering problematic Unicode for Windows console."""
    # Replace emoji/special Unicode that may not render in terminals
    message = message.replace("❌", "[ERR]")   # cross mark
    message = message.replace("✅", "[OK]")     # check mark
    message = message.replace("⚠", "[WARN]")   # warning
    message = message.replace("ℹ", "[INFO]")   # info
    message = message.replace("❗", "[!]")      # exclamation
    message = message.replace("➕", "[+]")      # plus
    message = message.replace("➖", "[-]")      # minus
    click.echo(message)


def _safe_err(message):
    message = message.replace("❌", "[ERR]")
    message = message.replace("✅", "[OK]")
    click.echo(message, err=True)


@click.group()
@click.version_option(version="1.0.0", prog_name="mapping2sql")
def cli():
    """Mapping2SQL - Mapping doc to standardized SQL code generator.

    Supports Excel (.xlsx), CSV (.csv), Word (.docx) mapping documents.
    Generates Oracle/MySQL SQL code following bank data platform standards.
    """


@cli.command()
@click.option("-i", "--input", "input_path", required=True,
              type=click.Path(exists=True), help="Mapping file path (.xlsx/.csv/.docx)")
@click.option("-o", "--output", "output_path", default=None,
              type=click.Path(), help="Output SQL file path (default: stdout)")
@click.option("--type", "sql_type", default="all",
              type=click.Choice(["ddl", "dml", "merge", "query", "all"]),
              help="SQL type to generate (default: all)")
@click.option("--dialect", default="oracle",
              type=click.Choice(["oracle", "mysql"]),
              help="Database dialect (default: oracle)")
@click.option("--author", default="DATA_TEAM", help="Author name")
@click.option("--connection", "-c", "conn_name", default=None,
              help="Use a saved connection by name (from Web UI connection manager)")
@click.option("--api-key", "api_key", default=None,
              help="Anthropic API key for LLM-powered rule understanding")
@click.option("--api-base", "api_base", default=None,
              help="Custom API base URL (for domestic proxy, e.g. https://api.example.com)")
@click.option("--standards", "config_path", default=None,
              type=click.Path(exists=True), help="SQL standards config file (YAML)")
@click.option("--validate/--no-validate", default=True, help="Validate mapping before generation")
def generate(input_path, output_path, sql_type, dialect, author, conn_name, api_key, api_base, config_path, validate):
    """Generate SQL code from mapping document."""
    _safe_echo(f"[PARSE] Parsing mapping document: {input_path}")

    # Initialize LLM engine: --connection > --api-key > env var
    if conn_name:
        store = ConnectionStore()
        conn = store.get_connection(conn_name)
        if conn:
            api_key = conn["api_key"]
            api_base = conn.get("base_url") or None
            _safe_echo(f"[LLM] Using saved connection: {conn_name}")
        else:
            _safe_echo(f"[WARN] Connection '{conn_name}' not found. Use Web UI to create it, or pass --api-key directly.")
            conn_name = None  # Fall through

    llm = LLMEngine(api_key=api_key, base_url=api_base) if api_key else None
    if llm and llm.is_available:
        _safe_echo(f"[LLM] Testing connection (model: {llm.model})...")
        ok, msg = llm.test_connection()
        if ok:
            _safe_echo(f"[LLM] {msg}")
        else:
            _safe_err(f"[LLM] Connection FAILED: {msg}")
    elif api_key:
        _safe_echo(f"[WARN] LLM not available: {llm.last_error if llm else 'Check API key'}")
    else:
        _safe_echo("[INFO] No API key provided. Using rule-based engine. Pass -c NAME or --api-key for LLM-powered generation.")

    parser = MappingParser()
    try:
        doc = parser.parse(input_path)
    except Exception as e:
        _safe_err(f"[ERR] Parse failed: {e}")
        sys.exit(1)

    _safe_echo(f"[OK] Parsed: {doc.table_count} table mapping(s), {doc.total_column_count} column(s)")

    if validate:
        validator = SQLValidator(dialect=dialect)
        result = validator.validate_document(doc)
        _safe_echo(result.message)

        if not result.is_valid:
            _safe_err("[ERR] Validation failed, fix mapping document and retry")
            sys.exit(1)

    generator = SQLGenerator(dialect=dialect, config_path=config_path, llm_engine=llm)
    results = generator.generate(doc, sql_type=sql_type, author=author)

    # Track engine usage
    if llm and llm.is_available:
        total_llm = 0
        total_regex = 0
        total_llm_failed = 0
        for tm in doc.table_mappings:
            exprs = generator._build_select_expressions(tm)
            for e in exprs:
                if e.get("engine") == "llm":
                    total_llm += 1
                elif e.get("engine") == "llm_failed":
                    total_llm_failed += 1
                elif e.get("engine") == "regex":
                    total_regex += 1
        if total_llm_failed > 0:
            _safe_err(f"[LLM] {total_llm_failed} LLM call(s) failed, fell back to regex. Last error: {llm.last_error}")
        if total_llm > 0:
            _safe_echo(f"[LLM] Engine stats: LLM={total_llm} fields, Regex={total_regex} fields")

    if not results:
        _safe_echo("[WARN] No SQL generated")
        return

    _safe_echo(f"[GEN] Generated {len(results)} SQL statement(s)")

    output_lines = []
    for name, sql in results.items():
        output_lines.append(f"-- ==== {name} ====")
        output_lines.append(sql)
        output_lines.append("")

    full_output = "\n".join(output_lines)

    if output_path:
        Path(output_path).write_text(full_output, encoding="utf-8")
        _safe_echo(f"[SAVE] Saved to: {output_path}")
    else:
        click.echo(full_output)


@cli.command()
@click.option("-i", "--input", "input_path", required=True,
              type=click.Path(exists=True), help="Mapping file path")
def validate(input_path):
    """Validate mapping document completeness and correctness."""
    _safe_echo(f"[VALIDATE] Validating mapping document: {input_path}")

    parser = MappingParser()
    try:
        doc = parser.parse(input_path)
    except Exception as e:
        _safe_err(f"[ERR] Parse failed: {e}")
        sys.exit(1)

    validator = SQLValidator()
    result = validator.validate_document(doc)

    click.echo(f"\n{'='*60}")
    click.echo(f"Document: {input_path}")
    click.echo(f"Table mappings: {doc.table_count}")
    click.echo(f"Column mappings: {doc.total_column_count}")
    click.echo(f"{'='*60}\n")

    for tm in doc.table_mappings:
        completeness = validator.validate_mapping_completeness(tm)
        click.echo(f"\nTable: {tm.source_table} -> {tm.target_table}")
        _safe_echo(completeness.message)

    click.echo(f"\n{'='*60}")
    _safe_echo(result.message)

    sys.exit(0 if result.is_valid else 1)


@cli.command()
@click.option("-d", "--dir", "input_dir", required=True,
              type=click.Path(exists=True), help="Directory containing mapping documents")
@click.option("-o", "--output", "output_dir", required=True,
              type=click.Path(), help="Output directory for SQL files")
@click.option("--type", "sql_type", default="all",
              type=click.Choice(["ddl", "dml", "merge", "query", "all"]))
@click.option("--dialect", default="oracle",
              type=click.Choice(["oracle", "mysql"]))
@click.option("--author", default="DATA_TEAM")
def batch(input_dir, output_dir, sql_type, dialect, author):
    """Batch process all mapping documents in a directory."""
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    extensions = ["*.xlsx", "*.csv", "*.docx"]
    files = []
    for ext in extensions:
        files.extend(input_path.glob(ext))

    if not files:
        _safe_echo(f"[WARN] No mapping documents found in: {input_dir}")
        return

    _safe_echo(f"[DIR] Found {len(files)} mapping document(s)\n")

    parser = MappingParser()
    generator = SQLGenerator(dialect=dialect)
    success = 0
    failed = 0

    for f in files:
        click.echo(f"  Processing: {f.name} ... ", nl=False)
        try:
            doc = parser.parse(str(f))
            results = generator.generate(doc, sql_type=sql_type, author=author)

            out_content = []
            for name, sql in results.items():
                out_content.append(f"-- ==== {name} ====")
                out_content.append(sql)
                out_content.append("")

            out_file = output_path / f"{f.stem}.sql"
            out_file.write_text("\n".join(out_content), encoding="utf-8")
            _safe_echo(f"[OK] -> {out_file.name}")
            success += 1
        except Exception as e:
            _safe_echo(f"[ERR] {e}")
            failed += 1

    _safe_echo(f"\n[BATCH] Done: {success} success, {failed} failed")


@cli.command()
@click.option("--dialect", default="oracle", type=click.Choice(["oracle", "mysql"]),
              help="Database dialect")
def info(dialect):
    """Display supported transformation rules and SQL standards."""
    click.echo(f"""
+==========================================================+
|        Mapping2SQL Agent v1.0                            |
|        Mapping Document -> SQL Code Generator            |
+==========================================================+
|  Supported formats: Excel (.xlsx), CSV (.csv), Word (.docx) |
|  Current dialect: {dialect:<10}                               |
+==========================================================+
|  Supported transformation rules:                         |
|    * Direct mapping                                      |
|    * CASE WHEN conditional logic                         |
|    * Type casting (CAST)                                 |
|    * Aggregation: SUM / AVG / COUNT / MAX / MIN         |
|    * NVL / COALESCE null handling                        |
|    * String concatenation (CONCAT)                       |
|    * Date formatting (TO_CHAR / DATE_FORMAT)             |
|    * Constant / default values                           |
|    * YoY / MoM templates                                 |
|    * Substring extraction (SUBSTR)                       |
+==========================================================+
|  Generated SQL types:                                    |
|    * DDL: CREATE TABLE                                   |
|    * DML: INSERT ... SELECT                              |
|    * MERGE INTO (incremental sync)                       |
|    * Query: SELECT                                       |
+==========================================================+
""")


if __name__ == "__main__":
    cli()
