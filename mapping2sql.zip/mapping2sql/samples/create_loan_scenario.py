import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

wb = openpyxl.Workbook()

# ── Styles ──
header_font = Font(name="微软雅黑", bold=True, size=11)
header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
header_font_white = Font(name="微软雅黑", bold=True, size=11, color="FFFFFF")
thin_border = Border(
    left=Side(style="thin"), right=Side(style="thin"),
    top=Side(style="thin"), bottom=Side(style="thin"),
)
center = Alignment(horizontal="center", vertical="center", wrap_text=True)

def style_header(ws, row, ncols):
    for col in range(1, ncols + 1):
        cell = ws.cell(row=row, column=col)
        cell.font = header_font_white
        cell.fill = header_fill
        cell.alignment = center
        cell.border = thin_border

def style_data(ws, start_row, end_row, ncols):
    for r in range(start_row, end_row + 1):
        for c in range(1, ncols + 1):
            cell = ws.cell(row=r, column=c)
            cell.border = thin_border
            cell.alignment = Alignment(vertical="center", wrap_text=True)

# ============================================================
# Sheet 1: 表级映射
# ============================================================
ws1 = wb.active
ws1.title = "表级映射"

tbl_headers = ["源系统", "源表名", "目标表名", "表描述", "增量键", "过滤条件", "关联条件"]
for i, h in enumerate(tbl_headers, 1):
    ws1.cell(row=1, column=i, value=h)
style_header(ws1, 1, len(tbl_headers))

tbl_data = [
    ["核心信贷系统", "ODS.LN_APPLY", "DWD.DWD_LN_APPLY", "贷款申请主表——含申请信息、审批状态、额度核定等", "etl_date", "apply_status != 'D'", ""],
    ["核心信贷系统", "ODS.LN_REPAY", "DWD.DWD_LN_REPAY", "还款流水表——记录每笔还款明细", "etl_date", "", "LEFT JOIN ODS.LN_APPLY a ON s.apply_id = a.apply_id"],
    ["核心信贷系统", "ODS.LN_SUMMARY", "DWD.DWD_LN_SUMMARY", "贷款日汇总表——按产品+机构+日期聚合", "etl_date", "", ""],
]
for i, row in enumerate(tbl_data, 2):
    for j, val in enumerate(row, 1):
        ws1.cell(row=i, column=j, value=val)
style_data(ws1, 2, len(tbl_data) + 1, len(tbl_headers))

ws1.column_dimensions["A"].width = 14
ws1.column_dimensions["B"].width = 22
ws1.column_dimensions["C"].width = 24
ws1.column_dimensions["D"].width = 45
ws1.column_dimensions["E"].width = 12
ws1.column_dimensions["F"].width = 24
ws1.column_dimensions["G"].width = 42

# ============================================================
# Sheet 2: LN_APPLY 字段映射（复杂转换规则）
# ============================================================
ws2 = wb.create_sheet("LN_APPLY字段映射")

col_headers = ["源字段名", "源类型", "目标字段名", "目标类型", "转换规则", "是否主键", "备注"]
for i, h in enumerate(col_headers, 1):
    ws2.cell(row=1, column=i, value=h)
style_header(ws2, 1, len(col_headers))

apply_cols = [
    ["apply_id", "VARCHAR2(32)", "apply_id", "VARCHAR2(32)", "直接映射", "是", "申请编号(主键)"],
    ["cust_id", "VARCHAR2(18)", "cust_id", "VARCHAR2(18)", "直接映射", "", "客户号"],
    ["cust_name", "VARCHAR2(60)", "cust_name", "VARCHAR2(100)", "直接映射", "", "客户姓名"],
    ["org_code", "VARCHAR2(12)", "org_code", "VARCHAR2(12)", "直接映射", "", "受理机构"],
    ["product_code", "VARCHAR2(8)", "product_code", "VARCHAR2(8)", "直接映射", "", "贷款产品代码"],
    ["product_name", "VARCHAR2(60)", "product_name", "VARCHAR2(100)", "直接映射", "", "贷款产品名称"],
    ["apply_amt", "NUMBER(18,2)", "apply_amt", "NUMBER(18,2)", "空值填0", "", "申请金额"],
    ["approve_amt", "NUMBER(18,2)", "approve_amt", "NUMBER(18,2)", "空值填0", "", "审批金额"],
    ["apply_date", "DATE", "apply_date", "DATE", "直接映射", "", "申请日期"],
    ["approve_date", "DATE", "approve_month", "VARCHAR2(6)", "日期格式化 YYYYMM", "", "审批月份(格式化为YYYYMM)"],
    ["status", "CHAR(1)", "status_desc", "VARCHAR2(50)", "当status='A'则为'审批中', 当status='P'则为'已通过', 当status='R'则为'已拒绝', 当status='D'则为'已撤销', 否则'未知'", "", "申请状态(多条件CASE WHEN转换)"],
    ["risk_level", "CHAR(1)", "risk_level_desc", "VARCHAR2(30)", "当risk_level='H'则为'高风险', 当risk_level='M'则为'中风险', 否则为'低风险'", "", "风险等级(条件转换)"],
    ["rate_type", "VARCHAR2(4)", "rate_type_desc", "VARCHAR2(20)", "当rate_type='FIXED'则为'固定利率', 当rate_type='FLOAT'则为'浮动利率', 否则'混合利率'", "", "利率类型描述"],
    ["rate", "NUMBER(8,6)", "rate_pct", "NUMBER(8,4)", "CAST(rate * 100 AS NUMBER(8,4))", "", "年利率(百分比) —— CAST类型转换+运算"],
    ["term_months", "NUMBER(3)", "term_months", "NUMBER(3)", "直接映射", "", "贷款期限(月)"],
    ["guarantee_type", "VARCHAR2(4)", "guarantee_desc", "VARCHAR2(30)", "当guarantee_type='CRED'则为'信用', 当guarantee_type='MORT'则为'抵押', 当guarantee_type='PLDG'则为'质押', 当guarantee_type='GUAR'则为'保证', 当guarantee_type='COMB'则为'组合', 否则'其他'", "", "担保方式(多条件映射)"],
    ["customer_manager", "VARCHAR2(30)", "mgr_id", "VARCHAR2(50)", "客户经理的工号和姓名拼接（如MGR001-张三）", "", "客户经理ID-姓名 —— LLM解析: 字符串拼接"],
    ["id_number", "VARCHAR2(18)", "id_mask", "VARCHAR2(18)", "取前6位和后4位，中间用****替换", "", "身份证号脱敏 —— SUBSTR拼接"],
    ["create_time", "DATE", "create_time", "DATE", "直接映射", "", "创建时间"],
    ["update_time", "DATE", "update_time", "DATE", "直接映射", "", "更新时间"],
    ["etl_date", "DATE", "etl_date", "DATE", "直接映射", "", "ETL日期"],
]

for i, row in enumerate(apply_cols, 2):
    for j, val in enumerate(row, 1):
        ws2.cell(row=i, column=j, value=val)
style_data(ws2, 2, len(apply_cols) + 1, len(col_headers))

for c, w in zip("ABCDEFG", [16, 14, 16, 14, 55, 10, 40]):
    ws2.column_dimensions[c].width = w

# ============================================================
# Sheet 3: LN_REPAY 字段映射（空值处理+日期）
# ============================================================
ws3 = wb.create_sheet("LN_REPAY字段映射")
for i, h in enumerate(col_headers, 1):
    ws3.cell(row=1, column=i, value=h)
style_header(ws3, 1, len(col_headers))

repay_cols = [
    ["repay_id", "VARCHAR2(32)", "repay_id", "VARCHAR2(32)", "直接映射", "是", "还款流水号(PK)"],
    ["apply_id", "VARCHAR2(32)", "apply_id", "VARCHAR2(32)", "直接映射", "", "关联申请编号"],
    ["cust_id", "VARCHAR2(18)", "cust_id", "VARCHAR2(18)", "直接映射", "", "客户号"],
    ["repay_amt", "NUMBER(18,2)", "repay_amt", "NUMBER(18,2)", "如果repay_amt为空则填0", "", "还款金额(NVL)"],
    ["repay_principal", "NUMBER(18,2)", "repay_principal", "NUMBER(18,2)", "空值填0", "", "还款本金"],
    ["repay_interest", "NUMBER(18,2)", "repay_interest", "NUMBER(18,2)", "空值填0", "", "还款利息"],
    ["repay_date", "DATE", "repay_date", "DATE", "直接映射", "", "还款日期"],
    ["repay_date", "DATE", "repay_month", "VARCHAR2(6)", "对repay_date做日期格式化，取到月份 YYYYMM", "", "还款月份(日期格式化)"],
    ["repay_channel", "VARCHAR2(4)", "channel_desc", "VARCHAR2(30)", "当repay_channel='ONLN'则为'线上', 当repay_channel='CNTR'则为'柜面', 当repay_channel='MOBL'则为'手机银行', 当repay_channel='AUTR'则为'自助终端', 否则'其他'", "", "还款渠道描述"],
    ["overdue_days", "NUMBER(5)", "overdue_flag", "VARCHAR2(10)", "当overdue_days=0则为'正常', 当overdue_days>0且overdue_days<=30则为'M1', 当overdue_days>30且overdue_days<=60则为'M2', 当overdue_days>60则为'M3+'", "", "逾期标识(数值范围条件)"],
    ["remark", "VARCHAR2(200)", "remark", "VARCHAR2(200)", "直接映射", "", "备注"],
    ["etl_date", "DATE", "etl_date", "DATE", "直接映射", "", "ETL日期"],
]

for i, row in enumerate(repay_cols, 2):
    for j, val in enumerate(row, 1):
        ws3.cell(row=i, column=j, value=val)
style_data(ws3, 2, len(repay_cols) + 1, len(col_headers))

for c, w in zip("ABCDEFG", [16, 14, 16, 14, 55, 10, 40]):
    ws3.column_dimensions[c].width = w

# ============================================================
# Sheet 4: LN_SUMMARY 字段映射（聚合汇总）
# ============================================================
ws4 = wb.create_sheet("LN_SUMMARY字段映射")
for i, h in enumerate(col_headers, 1):
    ws4.cell(row=1, column=i, value=h)
style_header(ws4, 1, len(col_headers))

summary_cols = [
    ["product_code", "VARCHAR2(8)", "product_code", "VARCHAR2(8)", "直接映射", "是", "贷款产品代码(PK)"],
    ["org_code", "VARCHAR2(12)", "org_code", "VARCHAR2(12)", "直接映射", "是", "机构号(PK)"],
    ["stat_date", "DATE", "stat_date", "DATE", "直接映射", "是", "统计日期(PK)"],
    ["apply_id", "VARCHAR2(32)", "apply_count", "NUMBER(10)", "COUNT计数", "", "申请笔数(COUNT聚合)"],
    ["apply_amt", "NUMBER(18,2)", "total_apply_amt", "NUMBER(20,2)", "SUM求和", "", "申请总金额(SUM聚合)"],
    ["approve_amt", "NUMBER(18,2)", "total_approve_amt", "NUMBER(20,2)", "SUM求和", "", "审批总金额(SUM聚合)"],
    ["approve_amt", "NUMBER(18,2)", "avg_approve_amt", "NUMBER(20,2)", "AVG平均值", "", "平均审批金额(AVG聚合)"],
    ["approve_amt", "NUMBER(18,2)", "max_approve_amt", "NUMBER(20,2)", "MAX最大值", "", "最大审批金额(MAX聚合)"],
    ["approve_amt", "NUMBER(18,2)", "min_approve_amt", "NUMBER(20,2)", "MIN最小值", "", "最小审批金额(MIN聚合)"],
    ["etl_date", "DATE", "etl_date", "DATE", "直接映射", "", "ETL日期"],
]

for i, row in enumerate(summary_cols, 2):
    for j, val in enumerate(row, 1):
        ws4.cell(row=i, column=j, value=val)
style_data(ws4, 2, len(summary_cols) + 1, len(col_headers))

for c, w in zip("ABCDEFG", [16, 14, 16, 14, 55, 10, 40]):
    ws4.column_dimensions[c].width = w

# ── Save ──
output_path = "samples/test_loan_scenario.xlsx"
wb.save(output_path)
print(f"Created: {output_path}")
print(f"Sheets: {wb.sheetnames}")
print(f"LN_APPLY: {len(apply_cols)} columns")
print(f"LN_REPAY: {len(repay_cols)} columns")
print(f"LN_SUMMARY: {len(summary_cols)} columns")
