# Mapping2SQL 工作流程详解

## 整体架构

```
┌──────────────────────────────────────────────────────────────┐
│                      用户入口                                 │
│              CLI (cli.py)  │  Web UI (app.py)                │
└──────────────┬───────────────────┬───────────────────────────┘
               │                   │
               ▼                   ▼
┌──────────────────────────────────────────────────────────────┐
│                   1. 解析层 (core/parser.py)                  │
│         Excel (.xlsx) / CSV / Word (.docx) → 统一数据模型     │
└──────────────┬───────────────────────────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────────────────────────┐
│                   2. 转换层 (core/transformer.py)              │
│          转换规则 → SQL 表达式  (LLM 优先 + Regex 兜底)       │
└──────────────┬───────────────────────────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────────────────────────┐
│                   3. 生成层 (core/generator.py)               │
│          Jinja2 模板渲染 → DDL / DML / MERGE / Query          │
└──────────────┬───────────────────────────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────────────────────────┐
│                   4. 格式化层 (core/formatter.py)              │
│              关键字大写、逗号前置、缩进规范化                   │
└──────────────┬───────────────────────────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────────────────────────┐
│                   5. 输出                                     │
│           SQL 代码 (终端 / Web UI / 文件下载)                  │
└──────────────────────────────────────────────────────────────┘
```

---

## 第 1 步：文档解析 (`core/parser.py`)

用户上传 Mapping 文档后，`MappingParser` 根据文件扩展名自动选择解析器：

| 格式 | 解析方式 | 关键逻辑 |
|------|----------|----------|
| `.xlsx` | `openpyxl` + `pandas` | 自动识别哪个 Sheet 是表映射、哪个是字段映射；通过关键词（如"源表""目标字段""转换规则"）匹配列 |
| `.csv` | `pandas` | 同样的关键词匹配逻辑 |
| `.docx` | `python-docx` | 提取 Word 表格，识别表头行和数据行 |

解析后的结果是**统一数据模型** (`core/models.py`)：

```
MappingDocument
├── table_mappings: list[TableMapping]
│   ├── source_table: "ODS.LN_APPLY"
│   ├── target_table: "DWD.LN_APPLY"
│   ├── columns: list[ColumnMapping]
│   │   ├── source_column, source_type
│   │   ├── target_column, target_type
│   │   ├── transform_rule (如 "直接映射" / "当status='A'则为'有效'")
│   │   ├── is_pk, nullable, comment
│   ├── filter_condition
│   ├── join_conditions
│   └── business_rules
```

---

## 第 2 步：转换规则 → SQL 表达式 (`core/transformer.py`)

这是整个系统最核心的"智能"部分。每个字段的 `transform_rule` 需要被转成 SQL 表达式，采用**双层策略**：

### Tier 1：Regex 规则解析器 (`utils/rule_parser.py`)

快速匹配常见简单模式：

| 规则描述 | 匹配模式 | 生成结果 |
|----------|----------|----------|
| "直接映射" / "direct" | 关键词匹配 | `s.col` |
| "空值填0" / "为空则填N/A" | NVL/COALESCE 模式 | `NVL(s.col, 0)` |
| "当 X 则为 Y 否则 Z" | CASE WHEN 模式 | `CASE WHEN ... END` |
| "CAST(col AS type)" | 已包含函数名 | 直接使用 |
| "SUM 求和" / "AVG 均值" | 聚合函数关键词 | `SUM(s.col)` |
| "日期格式化 YYYYMMDD" | 日期模式 | `TO_CHAR(s.col, 'YYYYMMDD')` |
| 常量值 `'XX'` / "填'XX'" | 常量模式 | `'XX'` |
| "截取前N位" | SUBSTR 模式 | `SUBSTR(s.col, 1, N)` |

### Tier 2：LLM 引擎 (`core/llm_engine.py`)

当 Regex 匹配置信度不高或规则是复杂自然语言时，调用 Claude API：

```
用户规则: "当客户等级为A且金额大于100万时标记为重点客户，否则为普通客户"
           ↓
LLM 理解  →  CASE WHEN s.cust_level = 'A' AND s.amount > 1000000
              THEN '重点客户' ELSE '普通客户' END
```

**流程**：`TransformEngine.transform()` 先尝试 Regex → 匹配置信度不够 → 调用 `llm.transform_rule_to_sql()` → LLM 返回 SQL 表达式 → 标记 `engine: "llm"` → 如果 LLM 也失败 → 标记 `engine: "llm_failed"`，保留原字段并加注释。

---

## 第 3 步：SQL 生成 (`core/generator.py`)

所有字段的 SQL 表达式确定后，`SQLGenerator` 使用 **Jinja2 模板**生成四种 SQL：

### 3.1 DDL — 建表语句

```sql
CREATE TABLE DWD.LN_APPLY
(
     apply_id     VARCHAR2(32)
    ,cust_name    VARCHAR2(100)
    ,CONSTRAINT pk_ln_apply PRIMARY KEY (apply_id)
);
COMMENT ON TABLE DWD.LN_APPLY IS '贷款申请表';
```

### 3.2 DML — INSERT...SELECT（最常用）

```sql
INSERT INTO DWD.LN_APPLY (apply_id, cust_name, status_desc)
SELECT
     s.apply_id  AS apply_id
    ,s.cust_name  AS cust_name
    ,CASE WHEN s.status='A' THEN '审批中' ELSE '未知' END  AS status_desc
FROM ODS.LN_APPLY  s
;
```

### 3.3 MERGE — 增量合并（UPSERT）

```sql
MERGE INTO DWD.LN_APPLY  t
USING (SELECT ... FROM ODS.LN_APPLY  s)  src
ON (t.apply_id = src.apply_id)
WHEN MATCHED THEN UPDATE SET t.cust_name = src.cust_name
WHEN NOT MATCHED THEN INSERT (...) VALUES (...)
;
```

### 3.4 Query — 查询语句

简单的 `SELECT ... FROM target_table`，用于数据验证。

生成逻辑通过 `_render()` 方法统一处理：

```
context dict → Jinja2 模板渲染 → 去尾随空格 → 压缩多余空行 → format 关键字大小写 → 输出
```

---

## 第 4 步：SQL 格式化 (`core/formatter.py`)

`SQLFormatter` 确保输出符合银行数据中台编码规范：

- **关键字大写**：`select` → `SELECT`，`from` → `FROM`（逐行处理，保护 `--` 注释内容不被修改）
- **逗号前置**：模板已处理，逗号在字段前而非字段后
- **缩进规范**：4 空格缩进
- **文件头注释**：每条 SQL 带标准注释块（程序名称、功能描述、创建人、创建日期）
- **通过 `config/sql_standards.yaml` 可自定义**：不同团队可以覆盖规范配置

---

## 第 5 步：校验 (`core/validator.py`)

生成 SQL 前先校验 Mapping 文档的完整性：

- 字段存在性：目标字段是否都有来源
- 类型兼容性：源类型 → 目标类型是否合理
- 必填字段：NOT NULL 字段是否有默认值或映射
- 主键完整性：主键字段是否正确标记

---

## Web UI 会话流程 (`app.py`)

Web 界面使用 **Streamlit**，聊天式交互，采用**三阶段处理**：

```
用户输入 → Phase A: 意图识别 → Phase B: 执行操作 → Phase C: LLM 自然回复
```

### Phase A：意图识别

先跑**关键词匹配**（快速、可靠），识别动作：

- `生成DDL` / `生成DML` / `全部生成` → `action: "generate"`
- `切换MySQL` / `切换Oracle` → `action: "change_dialect"`
- `展示结构` → `action: "show_structure"`
- `下载` → `action: "download"`
- `帮助` / `你好` → `action: "help"`

如果关键词匹配结果是 `chat`（闲聊），且有 LLM 可用，再调用 `llm.chat_intent()` 做**语义增强**，可能识别出 `generate_query`（复杂分析查询）等关键词无法覆盖的意图。

### Phase B：执行机械操作

根据意图执行实际动作：生成 SQL、切换方言、展示结构等。同时记录 `action_note`（如 `[系统: 已生成 12 条 全部 SQL]`），供 LLM 在下一步参考。

### Phase C：LLM 自然回复

调用 `llm.chat()`，传入会话上下文、历史记录和系统操作摘要，生成温暖的中文回复。例如：

> "已为你生成了贷款申请表的 4 条 Oracle SQL（DDL + DML + MERGE + Query），包含 15 个字段的映射。点击下方展开查看代码，也可以单独下载每个 SQL 文件。"

如果 LLM 不可用，回退到模板回复。

---

## CLI 流程 (`cli.py`)

命令行模式更简洁直接：

```bash
# 单文件生成
mapping2sql generate -i mapping.xlsx -o output.sql --type all --dialect oracle

# 校验模式
mapping2sql validate -i mapping.xlsx

# 批量处理
mapping2sql batch -d ./mappings/ -o ./sql_output/
```

流程与上面相同：解析 → 校验 → 生成 → 格式化 → 输出到文件或标准输出。CLI 模式下 LLM 是可选的（通过 `--api-key` 或 `--connection` 启用）。

---

## 关键设计决策

| 决策 | 说明 |
|------|------|
| **LLM 不强制依赖** | Regex 规则引擎覆盖 80% 常见场景，LLM 作为复杂自然语言的增强 |
| **模板驱动** | Jinja2 模板确保 SQL 结构一致，规范变更只需改模板 |
| **配置化规范** | YAML 文件定义编码规范，不同团队可自定义 |
| **统一数据模型** | 所有格式（Excel/CSV/Word）解析为同一个 `MappingDocument` 模型，生成器不感知原始格式 |
| **双引擎转换** | Regex 优先（快）+ LLM 兜底（智能），兼顾性能和语义理解 |
