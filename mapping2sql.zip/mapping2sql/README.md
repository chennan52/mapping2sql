# Mapping2SQL 智能体

> 数据开发 Mapping 文档 → 标准化 SQL 代码自动生成工具

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-80%20passed-brightgreen.svg)](tests/)

---

## 目录

- [1. 背景与痛点](#1-背景与痛点)
- [2. 功能特性](#2-功能特性)
- [3. 快速开始](#3-快速开始)
- [4. 使用指南](#4-使用指南)
  - [4.1 CLI 命令行](#41-cli-命令行)
  - [4.2 Web 界面](#42-web-界面)
  - [4.3 自然语言交互](#43-自然语言交互)
- [5. Mapping 文档格式](#5-mapping-文档格式)
  - [5.1 Excel 格式](#51-excel-格式)
  - [5.2 CSV 格式](#52-csv-格式)
  - [5.3 Word 格式](#53-word-格式)
  - [5.4 多表关联 (JOIN)](#54-多表关联-join)
- [6. 转换规则引擎](#6-转换规则引擎)
- [7. 生成的 SQL 类型](#7-生成的-sql-类型)
- [8. SQL 编码规范](#8-sql-编码规范)
- [9. LLM 智能增强](#9-llm-智能增强)
- [10. 项目架构](#10-项目架构)
- [11. 配置说明](#11-配置说明)
- [12. 测试](#12-测试)
- [13. 常见问题](#13-常见问题)

---

## 1. 背景与痛点

在银行数据中台日常开发中，ETL 开发人员需要将业务方提供的 **Mapping 文档**（字段映射表）手工转换为 **标准化的 SQL 代码**。这个过程存在三个核心痛点：

| 痛点 | 说明 |
|------|------|
| **效率低** | 手工逐字段编写 SQL，一个中等规模的表（30+ 字段）需要花费 30-60 分钟，且容易出现字段拼写错误、类型不匹配、逻辑遗漏 |
| **同步难** | Mapping 文档频繁更新，SQL 代码难以保持同步，经常出现「文档一套、代码一套」的脱节问题 |
| **难复用** | 相似的 ETL 逻辑（NVL 空值处理、日期格式化、状态码转换）每次从零手写，缺乏模板化和自动化能力 |

Mapping2SQL 解决的核心问题：**上传 Mapping 文档，自动生成符合银行数据中台规范的 DDL / DML / MERGE / Query SQL 代码**。

---

## 2. 功能特性

| 模块 | 特性 | 说明 |
|------|------|------|
| 📥 **多格式解析** | Excel (.xlsx) | 自动识别表级映射 Sheet + 字段级映射 Sheet |
| | CSV (.csv) | 多编码自动检测（UTF-8 / GBK / GB2312） |
| | Word (.docx) | 提取 Word 表格，自动匹配表头行和数据行 |
| 🔍 **智能识别** | 列名模糊匹配 | 支持中英文双语关键词（如「源字段」/「source_column」） |
| | 表名推断 | 从 Sheet 名称、数据内容自动推断源表/目标表 |
| | 主键检测 | 自动识别 PK 标记列（是/否、Y/N、true/false） |
| 🔗 **多表关联** | JOIN 解析 | 支持 LEFT/INNER/RIGHT/FULL JOIN + ON 条件 |
| | 别名推导 | 自动识别表的短别名（如 `r` → `ODS.LN_REPAY`） |
| 🧠 **转换规则** | 规则引擎 | 正则优先 + LLM 兜底，覆盖 12 类常见转换规则 |
| | 方言适配 | Oracle (NVL/TO_CHAR/SUBSTR) / MySQL (COALESCE/DATE_FORMAT/SUBSTRING) |
| 📐 **规范 SQL** | 注释头 | 程序名称、功能描述、源表、目标表、创建人、创建日期 |
| | 排版 | 关键字大写、逗号前置、每字段一行、4 空格缩进 |
| | JOIN | 每个 JOIN 独占行，ON 条件清晰标注 |
| ✅ **自动校验** | 完整性 | 必填字段检查、主键检查 |
| | 兼容性 | 源类型→目标类型兼容性校验 |
| | 规则检查 | 转换规则不完整/含占位符的自动告警 |
| 🌐 **双界面** | CLI (Click) | 单文件 + 批量处理，支持 stdin/stdout |
| | Web (Streamlit) | 文件上传、在线预览、SQL 编辑、一键下载 |
| 🤖 **LLM 增强** | 复杂规则理解 | 自然语言描述→SQL 表达式（如「当客户等级为A且金额>100万则标记为重点」） |
| | 自由查询 | 用自然语言描述查询需求，LLM 根据表结构生成复杂查询 SQL |

---

## 3. 部署环境

### 3.1 系统要求

| 项目 | 最低要求 | 说明 |
|------|----------|------|
| 操作系统 | Windows 10+ / Linux (Ubuntu 20.04+) / macOS 12+ | 跨平台支持，Windows 下自动处理 UTF-8 编码 |
| Python | 3.10+ | 低于 3.10 无法使用 `str.removeprefix()` 等特性 |
| 内存 | ≥ 512 MB | 仅解析+生成（不含 LLM）；大型 Mapping 文档建议 1 GB+ |
| 磁盘 | ≥ 200 MB | 项目本身约 2 MB，主要开销来自 Python 依赖 |
| 网络 | 按需 | 不使用 LLM 时无需联网；使用 LLM 时需能访问 Anthropic API 或代理 |

### 3.2 安装步骤

```bash
# 1. 克隆项目
git clone <repo-url> mapping2sql
cd mapping2sql

# 2. 创建虚拟环境（推荐，避免依赖冲突）
python -m venv venv

# Windows 激活
venv\Scripts\activate
# Linux/macOS 激活
source venv/bin/activate

# 3. 安装核心依赖（必选）
pip install -r requirements.txt

# 4. 安装 LLM 依赖（可选，需要智能理解复杂规则时）
pip install anthropic
```

### 3.3 环境变量

| 变量 | 必须 | 说明 |
|------|------|------|
| `ANTHROPIC_API_KEY` | 否 | Anthropic API 密钥。不配置时 LLM 功能不可用，其余功能正常。 |
| `ANTHROPIC_BASE_URL` | 否 | 自定义 API 代理地址，如 `https://api.example.com`。国内环境需通过代理访问时使用。 |
| `PYTHONUTF8` | 否 | Windows 下 CLI 自动设为 `1`，确保中文输出不乱码。Web 界面无需设置。 |

### 3.4 验证安装

```bash
# 确认 CLI 正常工作（无需 LLM）
python cli.py info

# 运行测试确认核心功能正常
python -m pytest tests/ -q

# 如果安装了 LLM 依赖，测试连接
python -c "from core.llm_engine import LLMEngine; llm = LLMEngine(); print(llm.is_available)"
```

### 3.5 依赖清单

| 包名 | 版本 | 用途 | 必须 |
|------|------|------|------|
| `pandas` | ≥1.5.0 | CSV/Excel 数据解析 | 是 |
| `openpyxl` | ≥3.1.0 | Excel 文件读写 | 是 |
| `python-docx` | ≥0.8.11 | Word 文档表格提取 | 是 |
| `click` | ≥8.1.0 | CLI 命令行框架 | 是 |
| `streamlit` | ≥1.28.0 | Web 界面 | 是 |
| `sqlparse` | ≥0.4.4 | SQL 语法校验与格式化 | 是 |
| `pyyaml` | ≥6.0 | YAML 规范配置文件解析 | 是 |
| `jinja2` | ≥3.1.0 | SQL 模板渲染引擎 | 是 |
| `anthropic` | ≥0.30.0 | LLM 智能增强 | 否 |

### 3.6 网络要求（仅 LLM 功能）

如果启用 LLM 功能，需要机器能访问 Anthropic API：
- **官方地址**：`https://api.anthropic.com`
- **国内代理**：通常由公司提供中转地址，在「连接配置」中填写 Base URL

不使用 LLM 时，整个系统完全离线运行，无需任何网络连接。

### 3.7 启动方式

**启动 Web 界面（推荐）：**

```bash
streamlit run app.py
# 或者
python -m streamlit run app.py
```

浏览器自动打开 `http://localhost:8501`，在聊天框里上传 Mapping 文档即可交互生成 SQL。

常用启动参数：

```bash
# 指定端口
streamlit run app.py --server.port 8888

# 无头模式（不自动打开浏览器）
streamlit run app.py --server.headless true

# 允许外部访问（局域网内其他机器可访问）
streamlit run app.py --server.address 0.0.0.0
```

**使用 CLI 命令行：**

```bash
# 直接生成 SQL（不需要启动服务）
python cli.py generate -i mapping.xlsx -o output.sql

# 查看所有支持的命令
python cli.py --help
```

### 30 秒体验

```bash
# 1. 生成示例 Mapping 文档
python samples/create_loan_scenario.py

# 2. 从示例文档生成全部 SQL
python cli.py generate -i samples/test_loan_scenario.xlsx -o output/test.sql

# 3. 查看生成结果
cat output/test.sql
```

生成结果示例：

```sql
-- ============================================================
-- 程序名称: INSERT_ODS_LN_APPLY_TO_DWD_LN_APPLY
-- 功能描述: 贷款申请数据ETL同步
-- 源表: ODS.LN_APPLY
-- 目标表: DWD.LN_APPLY
-- 增量键: etl_date
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-11
-- ============================================================

INSERT INTO DWD.LN_APPLY (
     apply_id
    ,cust_id
    ,apply_amt
    ,status
    ,create_date
)
SELECT
     s.apply_id  AS apply_id
    ,s.cust_id  AS cust_id
    ,NVL(s.apply_amt, 0)  AS apply_amt
    ,CASE WHEN s.status = 'A' THEN '审批中'
          ELSE '已通过'
     END  AS status_desc
    ,TO_CHAR(s.create_date, 'YYYYMMDD')  AS create_date
FROM ODS.LN_APPLY  s
;
```

---

## 4. 使用指南

### 4.1 CLI 命令行

#### 生成 SQL

```bash
# 基本用法：解析 xlsx 并生成全部 4 类 SQL
python cli.py generate -i mapping.xlsx -o output.sql

# 只生成 DDL
python cli.py generate -i mapping.xlsx --type ddl

# 只生成 INSERT...SELECT
python cli.py generate -i mapping.csv --type dml

# 使用 MySQL 方言
python cli.py generate -i mapping.xlsx --dialect mysql

# 指定创建人
python cli.py generate -i mapping.xlsx --author "张三"

# 使用自定义 SQL 规范配置
python cli.py generate -i mapping.xlsx --standards config/my_standards.yaml

# 跳过校验
python cli.py generate -i mapping.xlsx --no-validate

# 输出到 stdout（不指定 -o）
python cli.py generate -i mapping.xlsx

# 使用 LLM 增强（通过已保存的连接）
python cli.py generate -i mapping.xlsx -c "公司中转站"

# 使用 LLM 增强（直接传 API Key）
python cli.py generate -i mapping.xlsx --api-key "sk-ant-..."
```

#### 校验文档

```bash
python cli.py validate -i mapping.xlsx
```

输出示例：

```
============================================================
Document: mapping.xlsx
Table mappings: 3
Column mappings: 43
============================================================

Table: ODS.LN_APPLY -> DWD.LN_APPLY
[OK] 校验通过

Table: ODS.LN_REPAY -> DWD.LN_REPAY
[WARN] 未指定主键字段，建议至少标记一个主键

============================================================
[OK] 文档包含 3 个表映射, 共 43 个字段映射
```

#### 批量处理

```bash
# 批量处理一个目录下的所有 Mapping 文档
python cli.py batch -d ./mappings/ -o ./sql_output/

# 指定方言和 SQL 类型
python cli.py batch -d ./mappings/ -o ./sql_output/ --dialect mysql --type dml
```

#### 查看帮助

```bash
python cli.py --help
python cli.py generate --help
python cli.py info   # 显示支持的转换规则和 SQL 类型
```

### 4.2 Web 界面

```bash
streamlit run app.py
```

浏览器打开 <http://localhost:8501>。

**操作流程：**

1. **上传文档** — 拖拽或点击上传 `.xlsx` / `.csv` / `.docx` 文件
2. **配置选项** — 侧边栏选择方言（Oracle/MySQL）、修改创建人
3. **自然语言交互** — 在聊天框输入指令：
   - `生成DDL` → 生成建表语句
   - `全部生成` → 生成 DDL + DML + MERGE + Query
   - `用MySQL方言` → 切换方言
   - `展示mapping结构` → 查看解析后的字段映射表
   - `下载SQL` → 下载全部 SQL 文件
4. **在线编辑** — 每个 SQL 块可以点击「编辑」直接修改，然后下载
5. **字段血缘** — 侧边栏「字段血缘」展开查看源→目标的完整映射链路

**LLM 自由查询（需要配置 API Key）：**

在聊天框直接输入自然语言查询需求：
- `帮我统计每个客户的贷款总额，按金额降序排列`
- `查询逾期超过30天的客户`
- `按月份汇总申请金额，计算环比增长率`

LLM 会根据已上传 Mapping 的表结构自动生成对应的 SQL。

### 4.3 自然语言交互

Web 界面支持以下自然语言指令（无需 LLM，关键字匹配）：

| 指令示例 | 效果 |
|----------|------|
| `生成DDL` / `建表` | 生成 CREATE TABLE 语句 |
| `生成DML` / `插入` / `ETL` | 生成 INSERT...SELECT 语句 |
| `生成MERGE` / `增量` / `UPSERT` | 生成 MERGE INTO 语句 |
| `生成Query` / `查询` | 生成查询语句 |
| `全部生成` / `生成全部` | 生成全部 4 类 SQL |
| `用MySQL` / `切换Oracle` | 切换数据库方言 |
| `展示结构` / `查看mapping` | 显示解析后的字段映射表 |
| `下载` | 下载全部 SQL |
| `帮助` | 显示帮助信息 |

---

## 5. Mapping 文档格式

### 5.1 Excel 格式

推荐使用**双 Sheet 结构**：

**Sheet 1 — 表级映射**（可选，用于提供表级元数据）：

| 源表名 | 目标表名 | 源系统 | 表备注 | 增量键 | 过滤条件 | 关联条件 |
|--------|----------|--------|--------|--------|----------|----------|
| ODS.LN_APPLY | DWD.LN_APPLY | CORE | 贷款申请表 | etl_date | status != 'D' | |
| ODS.LN_REPAY | DWD.LN_REPAY | CORE | 还款明细表 | etl_date | | LEFT JOIN ODS.LN_APPLY a ON s.apply_id = a.apply_id |

**Sheet 2 — 字段级映射**（必填）：

| 源字段 | 目标字段 | 源类型 | 目标类型 | 转换规则 | 是否主键 | 备注 |
|--------|----------|--------|----------|----------|----------|------|
| apply_id | apply_id | NUMBER | NUMBER | 直接映射 | 是 | 申请ID |
| cust_name | cust_name | VARCHAR2(100) | VARCHAR2(100) | 直接映射 | | 客户名称 |
| apply_amt | apply_amt | NUMBER | NUMBER | 空值填0 | | 申请金额 |
| status | status_desc | VARCHAR2(20) | VARCHAR2(100) | 当status='A'则为'审批中'否则'已通过' | | 状态描述 |
| create_date | create_date | DATE | VARCHAR2(8) | 日期格式化 YYYYMMDD | | 创建日期 |

> **列名支持模糊匹配**：只要列名关键词命中即可。例如「来源字段名」「src_column」「source_column」都能被正确识别为源字段列。

### 5.2 CSV 格式

CSV 格式只需一个文件，包含字段级映射的所有列。编码支持 UTF-8 / GBK / GB2312（自动检测）。

```csv
源字段,目标字段,源类型,目标类型,转换规则,是否主键,备注
apply_id,apply_id,NUMBER,NUMBER,直接映射,是,申请ID
cust_name,cust_name,VARCHAR2(100),VARCHAR2(100),直接映射,,客户名称
apply_amt,apply_amt,NUMBER,NUMBER,空值填0,,申请金额
```

### 5.3 Word 格式

Word (.docx) 文档中的表格会被自动提取。表格第一行作为列头，后续行作为数据行。支持与 Excel 相同的双表结构（表级元数据表 + 字段级映射表）。

> **注意**：Word 解析对合并单元格的支持有限。建议在 Word 中使用简单表格结构。

### 5.4 多表关联 (JOIN)

在表级映射的「关联条件」列中配置 JOIN 信息，支持以下格式：

```
# 完整格式
LEFT JOIN ODS.LN_APPLY a ON s.apply_id = a.apply_id

# 多个 JOIN 用分号或换行分隔
LEFT JOIN ODS.CUST c ON s.cust_id = c.cust_id;
INNER JOIN ODS.ACCT a ON s.acct_id = a.acct_id

# 简写格式（仅 ON 条件，默认 INNER JOIN）
s.apply_id = r.apply_id
```

生成的 DML 会自动包含 JOIN 子句：

```sql
SELECT ...
FROM ODS.LN_REPAY  s
LEFT JOIN ODS.LN_APPLY a
    ON s.apply_id = a.apply_id
```

---

## 6. 转换规则引擎

规则引擎采用 **两阶段架构**：

1. **正则匹配**（Tier 1）— 快，覆盖 80% 常见场景
2. **LLM 语义理解**（Tier 2）— 处理复杂自然语言规则（需配置 API Key）

### 支持的规则类型

| 规则类型 | Mapping 描述示例 | 生成 SQL (Oracle) | 生成 SQL (MySQL) |
|----------|-----------------|-------------------|-------------------|
| 直接映射 | `直接映射` / `direct` | `s.col` | `s.col` |
| 空值处理 | `空值填0` | `NVL(s.col, 0)` | `COALESCE(s.col, 0)` |
| 条件转换 | `当status='A'则为'审批中'否则'已通过'` | `CASE WHEN status='A' THEN '审批中' ELSE '已通过' END` | 同 Oracle |
| 类型转换 | `CAST(rate * 100 AS NUMBER(8,4))` | `CAST(rate * 100 AS NUMBER(8,4))` | 同 Oracle |
| 求和 | `SUM求和` / `SUM(amount)` | `SUM(amount)` | `SUM(amount)` |
| 平均 | `AVG均值` / `AVG(score)` | `AVG(score)` | `AVG(score)` |
| 计数 | `COUNT计数` / `COUNT(*)` | `COUNT(*)` | `COUNT(*)` |
| 最大值 | `MAX最大值` | `MAX(col)` | `MAX(col)` |
| 最小值 | `MIN最小值` | `MIN(col)` | `MIN(col)` |
| 字符串拼接 | `拼接 机构号 日期` | `org_code \|\| date_str` | `CONCAT(org_code, date_str)` |
| 日期格式化 | `日期格式化 YYYYMMDD` | `TO_CHAR(s.date_col, 'YYYYMMDD')` | `DATE_FORMAT(s.date_col, '%Y%m%d')` |
| 截取子串 | `截取 name 1 4` | `SUBSTR(name, 1, 4)` | `SUBSTRING(name, 1, 4)` |
| 常量填充 | `填'银行'` / `default: 'XX'` | `'银行' AS col` | `'银行' AS col` |
| 同比 | `同比增长率` | `-- TODO: 同比计算\ncol` | 同 Oracle |
| 环比 | `环比增长率` | `-- TODO: 环比计算\ncol` | 同 Oracle |
| 复杂规则 | `当客户等级为A且金额>100万则标记为重点客户` | 由 LLM 生成 | 由 LLM 生成 |

### 复杂规则的处理流程

```
输入: "当客户等级为A且金额>100万则标记为重点客户"
  │
  ├─ Tier 1: 正则匹配 → 置信度 0.3 (< 0.8，不采用)
  │
  ├─ Tier 2: LLM 理解 → 生成 SQL
  │     CASE WHEN cust_level = 'A' AND amount > 1000000
  │          THEN '重点客户' END
  │
  └─ Tier 3: 兜底 → s.col  /* 转换规则: ... — 需人工确认 */
```

---

## 7. 生成的 SQL 类型

### DDL — CREATE TABLE

```sql
CREATE TABLE DWD.LN_APPLY (
     apply_id  NUMBER
    ,cust_id  NUMBER
    ,apply_amt  NUMBER
    ,status_desc  VARCHAR2(100)
    ,create_date  VARCHAR2(8)
    ,CONSTRAINT pk_LN_APPLY PRIMARY KEY (apply_id)
)
;

COMMENT ON TABLE DWD.LN_APPLY IS '贷款申请表';
COMMENT ON COLUMN DWD.LN_APPLY.apply_id IS '申请ID';
COMMENT ON COLUMN DWD.LN_APPLY.apply_amt IS '申请金额';
```

### DML — INSERT...SELECT

```sql
INSERT INTO DWD.LN_APPLY (
     apply_id
    ,cust_id
    ,apply_amt
    ,status_desc
    ,create_date
)
SELECT
     s.apply_id  AS apply_id
    ,s.cust_id  AS cust_id
    ,NVL(s.apply_amt, 0)  AS apply_amt
    ,CASE WHEN s.status = 'A' THEN '审批中'
          ELSE '已通过'
     END  AS status_desc
    ,TO_CHAR(s.create_date, 'YYYYMMDD')  AS create_date
FROM ODS.LN_APPLY  s
;
```

### MERGE INTO — 增量同步

```sql
MERGE INTO DWD.LN_APPLY  t
USING (
    SELECT ...
    FROM ODS.LN_APPLY  s
)  src
ON (t.apply_id = src.apply_id)
WHEN MATCHED THEN
    UPDATE SET
         t.cust_id = src.cust_id
        ,t.apply_amt = src.apply_amt
        ...
WHEN NOT MATCHED THEN
    INSERT (
         apply_id
        ,cust_id
        ,apply_amt
        ...
    ) VALUES (
         src.apply_id
        ,src.cust_id
        ,src.apply_amt
        ...
    )
;
```

### Query — 查询语句

```sql
SELECT
     apply_id
    ,cust_name
    ,apply_amt
FROM DWD.DWD_LN_APPLY  t
;
```

---

## 8. SQL 编码规范

生成的 SQL 遵循银行数据中台标准规范，可通过 `config/sql_standards.yaml` 自定义：

| 规范项 | 默认值 | 说明 |
|--------|--------|------|
| 关键字大小写 | UPPER | SELECT / FROM / WHERE 等 |
| 标识符大小写 | lower | 表名、字段名 |
| 缩进 | 4 空格 | |
| 逗号风格 | leading（前置） | 每个字段前的逗号 |
| 字段排版 | 每字段一行 | SELECT 和 INSERT 列表 |
| 注释头 | 程序名称、源表、目标表、创建人、日期、修改历史 | |
| JOIN 显式标注 | 仅使用显式 JOIN | 禁止逗号隐式联接 |
| ON 条件 | 独立一行缩进 | `ON s.id = t.id` |
| WHERE 条件 | 每个 AND 独占一行 | |
| GROUP BY | 每个字段独占一行 | |

### 自定义规范

```bash
# 通过 CLI 指定
python cli.py generate -i mapping.xlsx --standards config/my_standards.yaml

# 通过 Web UI
# 侧边栏 → 生成设置 → 上传 SQL 规范文件 (.yaml)
```

规范文件格式见 [config/sql_standards.yaml](config/sql_standards.yaml)。

---

## 9. LLM 智能增强

### 连接配置

LLM 增强是可选的。不配置 API Key 时，系统使用纯规则引擎，覆盖 80% 的常见场景。

**Web UI 配置：**
1. 侧边栏 → 连接配置 → 新增连接
2. 填写名称、API Key、Base URL（国内中转站需要）
3. 保存并激活

**CLI 配置：**

```bash
# 方式 1：使用 Web UI 保存的连接
python cli.py generate -i mapping.xlsx -c "公司中转站"

# 方式 2：直接传 API Key
python cli.py generate -i mapping.xlsx --api-key "sk-ant-..."

# 方式 3：自定义 Base URL
python cli.py generate -i mapping.xlsx --api-key "..." --api-base "https://api.example.com"
```

### LLM 的三种使用场景

| 场景 | 说明 |
|------|------|
| **复杂转换规则** | 正则无法匹配的自然语言规则（如多层条件判断） |
| **自然语言→查询** | 在 Web UI 中直接描述查询需求，LLM 根据表结构生成 SQL |
| **意图理解** | 理解用户的非标准表达（如「帮我把表建出来」→ 生成 DDL） |

---

## 10. 项目架构

```
mapping2sql/
├── cli.py                    # CLI 入口 (Click)
├── app.py                    # Web 入口 (Streamlit)
├── setup.py                  # 安装配置
├── requirements.txt          # Python 依赖
│
├── core/                     # 核心引擎
│   ├── models.py             # 统一数据模型 (MappingDocument, TableMapping, ColumnMapping, JoinClause)
│   ├── parser.py             # 多格式解析器 (Excel/CSV/Word → 统一模型)
│   ├── generator.py          # SQL 生成器 (Jinja2 模板 + Python 预处理)
│   ├── transformer.py        # 转换规则引擎 (正则优先 → LLM 兜底)
│   ├── formatter.py          # SQL 格式化器 (关键字大小写 + 结构排版)
│   ├── validator.py          # 校验器 (字段完整性 + 类型兼容性 + SQL 语法)
│   └── llm_engine.py         # LLM 引擎 (Anthropic API 封装)
│
├── utils/                    # 工具模块
│   ├── rule_parser.py        # 自然语言规则解析器 (正则模式匹配)
│   ├── type_mapper.py        # 数据类型映射与兼容性检查
│   ├── connection_store.py   # LLM 连接配置持久化 (JSON 文件存储)
│   └── chat_history.py       # 会话历史存储
│
├── templates/                # Jinja2 SQL 模板
│   ├── create_table.sql.j2   # DDL 模板
│   ├── insert_select.sql.j2  # INSERT...SELECT 模板
│   ├── merge.sql.j2          # MERGE INTO 模板
│   └── query.sql.j2          # 查询模板
│
├── config/                   # 配置
│   └── sql_standards.yaml    # SQL 编码规范 (默认配置)
│
├── samples/                  # 示例 Mapping 文档
│   ├── create_loan_scenario.py   # 生成测试场景 xlsx
│   ├── create_sample_excel.py    # 生成示例 xlsx
│   └── create_sample_word.py     # 生成示例 docx
│
├── tests/                    # 测试
│   ├── conftest.py               # 共享 fixtures (CSV 等)
│   ├── test_smoke.py             # 核心管线冒烟测试 (26 项)
│   ├── test_edge_cases.py        # 边界条件测试 (36 项)
│   └── test_integration.py       # 集成测试 + CSV (18 项)
│
└── output/                   # 生成 SQL 输出目录
```

### 数据流

```
Excel/CSV/Word
     │
     ▼
┌──────────┐     ┌──────────────┐     ┌────────────┐
│  Parser  │ ──▶ │ MappingDoc   │ ──▶ │ Validator  │
│          │     │ .table_maps  │     │ (完整性/   │
│ 自动识别 │     │ .columns[]   │     │  类型校验) │
│ 列名/表名│     └──────────────┘     └────────────┘
└──────────┘                               │
       ┌───────────────────────────────────┘
       ▼
┌──────────────┐     ┌──────────────┐     ┌────────────┐
│ Transformer  │     │  Generator   │     │ Formatter  │
│              │ ──▶ │              │ ──▶ │            │
│ 规则→SQL表达式│     │ Jinja2 渲染  │     │ 关键字大写 │
│ 正则+LLM     │     │ Python 预处理 │     │ 排版规范化 │
└──────────────┘     └──────────────┘     └────────────┘
                                                  │
                                                  ▼
                                            SQL 代码输出
                                       (stdout / 文件 / Web下载)
```

---

## 11. 配置说明

### SQL 规范配置 (config/sql_standards.yaml)

```yaml
dialect: oracle               # 默认方言

naming:
  keyword_case: upper         # SQL 关键字: upper | lower
  identifier_case: lower      # 标识符: upper | lower | original

formatting:
  indent: "    "              # 缩进字符串
  max_line_length: 120        # 最大行宽
  comma_style: leading        # 逗号前置 | trailing（后置）

select_style:
  column_per_line: true       # SELECT 列表每字段一行
  comma_before: true          # 逗号在字段前
  indent_columns: true        # 字段缩进

join:
  explicit_only: true         # 禁止逗号隐式联接
  indent_on: true             # ON 子句缩进
  each_on_newline: true       # 每个 ON 条件一行

where:
  each_condition_newline: true   # AND/OR 条件分行
  operator_align: false          # 操作符对齐

aggregation:
  group_by_newline: true      # GROUP BY 字段分行
  having_newline: true        # HAVING 条件独立行
```

### 环境变量

| 变量 | 说明 |
|------|------|
| `ANTHROPIC_API_KEY` | 默认 LLM API Key（CLI 未传 `--api-key` 时使用） |
| `PYTHONUTF8` | Windows 下自动设为 `1`，确保中文输出正确 |

---

## 12. 测试

### 运行测试

```bash
# 运行全部 80 个测试
python -m pytest tests/ -v

# 只运行冒烟测试（核心管线）
python -m pytest tests/test_smoke.py -v

# 只运行边界条件测试
python -m pytest tests/test_edge_cases.py -v

# 只运行集成测试（需要示例 xlsx 文件）
python -m pytest tests/test_integration.py -v

# 带覆盖率报告
python -m pytest tests/ -v --cov=core --cov-report=term-missing
```

### 测试覆盖概览

| 测试文件 | 测试数 | 覆盖范围 |
|----------|--------|----------|
| `test_smoke.py` | 26 | Parser / Generator / Transformer / Models / Round-trip |
| `test_edge_cases.py` | 36 | 边界条件：空表、无PK、特殊字符、异常输入、校验器、Formatter |
| `test_integration.py` | 18 | CSV 解析、端到端管线、Oracle+MySQL 方言、完整文档验证 |

---

## 13. 常见问题

### Q: 支持哪些 Mapping 文档格式？

Excel (.xlsx/.xls)、CSV (.csv)、Word (.docx)。推荐使用 Excel，功能支持最完整。

### Q: 如何让系统理解我司特有的 Mapping 列名？

系统支持中英文关键词模糊匹配。例如「来源字段」「src_col」「SOURCE_COLUMN」都能被识别为源字段列。如果列名仍然无法识别，可以在 `core/parser.py` 的 `*_KEYWORDS` 类变量中添加自定义关键词。

### Q: 转换规则写中文还是英文？

都可以。规则引擎优先正则匹配中英文常见模式，匹配失败且配置了 LLM 时会自动调用 LLM 理解。

### Q: Oracle 和 MySQL 的区别是什么？

主要体现在函数名：
- 空值处理：Oracle `NVL()` vs MySQL `COALESCE()`
- 日期格式化：Oracle `TO_CHAR()` vs MySQL `DATE_FORMAT()`
- 字符串截取：Oracle `SUBSTR()` vs MySQL `SUBSTRING()`
- 字符串拼接：Oracle `||` vs MySQL `CONCAT()`

### Q: 可以只生成某一种 SQL 吗？

可以。通过 `--type` 参数指定：
```bash
python cli.py generate -i mapping.xlsx --type ddl   # 只生成建表语句
python cli.py generate -i mapping.xlsx --type dml   # 只生成 INSERT
python cli.py generate -i mapping.xlsx --type merge # 只生成 MERGE
```

### Q: 如何添加自定义 SQL 模板？

在 `templates/` 目录下创建新的 `.sql.j2` 文件，然后在 `core/generator.py` 中注册即可。模板使用 Jinja2 语法，上下文变量见 `_base_context()` 方法。

### Q: 如何适配我司的 SQL 编码规范？

复制 `config/sql_standards.yaml`，修改后通过 CLI `--standards` 或 Web UI 上传。支持自定义关键字大小写、逗号风格、缩进宽度、注释格式等。

### Q: 不使用 LLM 的话，功能是否完整？

是的。LLM 仅用于处理复杂自然语言规则。不配置 LLM 时，系统使用纯规则引擎，覆盖直接映射、CASE WHEN、NVL、聚合等 80% 的常见场景。

---

## License

MIT
