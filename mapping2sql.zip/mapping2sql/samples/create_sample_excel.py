"""Script to create sample Excel mapping document."""
import sys
sys.path.insert(0, "..")

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

wb = openpyxl.Workbook()

# Styles
header_font = Font(bold=True, size=11, color="FFFFFF")
header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
thin_border = Border(
    left=Side(style="thin"), right=Side(style="thin"),
    top=Side(style="thin"), bottom=Side(style="thin"),
)
center_align = Alignment(horizontal="center")

def style_header(ws, headers, ncols):
    for i, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=i, value=h)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = center_align
        cell.border = thin_border

def auto_width(ws):
    for col_cells in ws.columns:
        max_length = 0
        col_letter = col_cells[0].column_letter
        for cell in col_cells:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))
        ws.column_dimensions[col_letter].width = min(max_length + 4, 50)

# ── Sheet 1: Table-level mapping ──
ws1 = wb.active
ws1.title = "表级映射"
h1 = ["源系统", "源表名", "目标表名", "表描述", "增量键", "备注"]
style_header(ws1, h1, len(h1))
ws1.append(["核心系统", "ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY",
            "账户日汇总明细表", "etl_date", "每日跑批 T+1"])
ws1.append(["核心系统", "ODS.CUST_INFO", "DWD.DWD_CUST_SUMMARY",
            "客户信息汇总表", "etl_date", "每日跑批 T+1"])
auto_width(ws1)

# ── Sheet 2: Column mapping - Account daily ──
ws2 = wb.create_sheet("字段映射_账户日汇总")
h2 = ["源表名", "目标表名", "源字段名", "源类型", "目标字段名",
      "目标类型", "转换规则", "是否主键", "可空", "备注"]
style_header(ws2, h2, len(h2))
data2 = [
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "acct_no", "VARCHAR2(20)",
     "acct_no", "VARCHAR2(20)", "直接映射", "是", "否", "账号"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "cust_id", "VARCHAR2(18)",
     "cust_id", "VARCHAR2(18)", "直接映射", "否", "否", "客户号"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "org_code", "VARCHAR2(12)",
     "org_code", "VARCHAR2(12)", "直接映射", "否", "否", "机构号"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "currency", "VARCHAR2(3)",
     "currency", "VARCHAR2(3)", "直接映射", "否", "否", "币种"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "balance", "NUMBER(18,2)",
     "balance", "NUMBER(18,2)", "直接映射", "否", "否", "余额"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "avail_balance", "NUMBER(18,2)",
     "avail_balance", "NUMBER(18,2)", "直接映射", "否", "否", "可用余额"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "status", "CHAR(1)",
     "status_name", "VARCHAR2(20)",
     "当status=1则'正常'否则'冻结或未知'",
     "否", "否", "账户状态名称"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "open_date", "DATE",
     "open_date", "DATE", "直接映射", "否", "否", "开户日期"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "open_date", "DATE",
     "open_month", "VARCHAR2(6)", "TO_CHAR open_date YYYYMM", "否", "否", "开户月份"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "last_txn_date", "DATE",
     "last_txn_date", "DATE",
     "空值填1900-01-01", "否", "是", "最后交易日期"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "frozen_amt", "NUMBER(18,2)",
     "frozen_amt", "NUMBER(18,2)", "空值填0", "否", "是", "冻结金额"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "mgr_id", "VARCHAR2(10)",
     "mgr_name", "VARCHAR2(50)", "直接映射", "否", "是", "客户经理ID"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "prod_code", "VARCHAR2(8)",
     "prod_code", "VARCHAR2(8)", "直接映射", "否", "否", "产品代码"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "acct_type", "VARCHAR2(4)",
     "acct_type", "VARCHAR2(4)", "直接映射", "否", "否", "账户类型"],
    ["ODS.ACCT_DAILY", "DWD.DWD_ACCT_DAILY", "etl_date", "DATE",
     "etl_date", "DATE", "直接映射", "否", "否", "ETL日期"],
]
for row_data in data2:
    ws2.append(row_data)
auto_width(ws2)

# ── Sheet 3: Column mapping - Customer summary ──
ws3 = wb.create_sheet("字段映射_客户汇总")
h3 = ["源表名", "目标表名", "源字段名", "源类型", "目标字段名",
      "目标类型", "转换规则", "是否主键", "可空", "备注"]
style_header(ws3, h3, len(h3))
data3 = [
    ["ODS.CUST_INFO", "DWD.DWD_CUST_SUMMARY", "cust_id", "VARCHAR2(18)",
     "cust_id", "VARCHAR2(18)", "直接映射", "是", "否", "客户号"],
    ["ODS.CUST_INFO", "DWD.DWD_CUST_SUMMARY", "cust_name", "VARCHAR2(100)",
     "cust_name", "VARCHAR2(100)", "直接映射", "否", "否", "客户名称"],
    ["ODS.CUST_INFO", "DWD.DWD_CUST_SUMMARY", "org_code", "VARCHAR2(12)",
     "org_code", "VARCHAR2(12)", "直接映射", "否", "否", "所属机构"],
    ["ODS.CUST_INFO", "DWD.DWD_CUST_SUMMARY", "balance", "NUMBER(18,2)",
     "total_balance", "NUMBER(18,2)", "SUM(balance)", "否", "否", "总余额"],
    ["ODS.CUST_INFO", "DWD.DWD_CUST_SUMMARY", "acct_no", "VARCHAR2(20)",
     "acct_count", "NUMBER(10)", "COUNT(acct_no)", "否", "否", "账户数量"],
    ["ODS.CUST_INFO", "DWD.DWD_CUST_SUMMARY", "balance", "NUMBER(18,2)",
     "avg_balance", "NUMBER(18,2)", "AVG(balance)", "否", "否", "平均余额"],
    ["ODS.CUST_INFO", "DWD.DWD_CUST_SUMMARY", "balance", "NUMBER(18,2)",
     "max_balance", "NUMBER(18,2)", "MAX(balance)", "否", "否", "最大余额"],
    ["ODS.CUST_INFO", "DWD.DWD_CUST_SUMMARY", "risk_level", "CHAR(1)",
     "risk_level_desc", "VARCHAR2(20)",
     "当risk_level='H'则'高风险'否则'非高风险'",
     "否", "否", "风险等级描述"],
    ["ODS.CUST_INFO", "DWD.DWD_CUST_SUMMARY", "create_date", "DATE",
     "create_month", "VARCHAR2(6)", "TO_CHAR create_date YYYYMM", "否", "否", "创建月份"],
    ["ODS.CUST_INFO", "DWD.DWD_CUST_SUMMARY", "etl_date", "DATE",
     "etl_date", "DATE", "直接映射", "否", "否", "ETL日期"],
]
for row_data in data3:
    ws3.append(row_data)
auto_width(ws3)

wb.save("sample_mapping.xlsx")
print("Created sample_mapping.xlsx successfully")
