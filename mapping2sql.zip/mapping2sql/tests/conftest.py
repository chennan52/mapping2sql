"""Shared test fixtures."""
import tempfile
from pathlib import Path

import pytest


@pytest.fixture(scope="module")
def sample_csv():
    """Create a minimal CSV mapping file for testing the CSV parser."""
    content = (
        "源字段,目标字段,源类型,目标类型,转换规则,备注,是否主键\n"
        "apply_id,apply_id,NUMBER,NUMBER,直接映射,申请ID,是\n"
        "cust_name,cust_name,VARCHAR2(100),VARCHAR2(100),直接映射,客户名称,\n"
        "apply_amt,apply_amt,NUMBER,NUMBER,直接映射,申请金额,\n"
        "status,status_desc,VARCHAR2(20),VARCHAR2(100),当status='A'则为'审批中'否则'已通过',状态描述,否\n"
        "create_date,create_date,DATE,VARCHAR2(8),日期格式化 YYYYMMDD,创建日期,\n"
    )
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, encoding="utf-8",
    ) as f:
        f.write(content)
        csv_path = f.name

    yield csv_path

    try:
        Path(csv_path).unlink()
    except OSError:
        pass
