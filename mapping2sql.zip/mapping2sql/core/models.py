"""Unified data model for mapping documents."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class JoinClause:
    """Represents a JOIN between the primary source table and another table."""
    join_type: str = "INNER"      # INNER, LEFT, RIGHT, FULL
    table: str = ""               # table to join (schema.table)
    alias: str = ""               # short alias
    on_condition: str = ""        # ON clause (e.g. "s.apply_id = r.apply_id")

    def to_sql(self) -> str:
        """Render as SQL JOIN clause."""
        if not self.table or not self.on_condition:
            return ""
        tbl = self.table
        alias_clause = f" {self.alias}" if self.alias else ""
        return f"{self.join_type} JOIN {tbl}{alias_clause}\n    ON {self.on_condition}"


@dataclass
class ColumnMapping:
    """Single column-level mapping from source to target."""
    source_table: str
    source_column: str
    source_type: str = ""
    target_table: str = ""
    target_column: str = ""
    target_type: str = ""
    transform_rule: str = ""           # e.g. "direct", "CASE WHEN...", "SUM(...)"
    is_pk: bool = False
    nullable: bool = True
    comment: str = ""
    default_value: str = ""            # constant default value
    sort_order: int = 0                # column position in target table

    def __repr__(self):
        return f"{self.source_column} -> {self.target_column} [{self.transform_rule or 'direct'}]"


@dataclass
class TableMapping:
    """Table-level mapping with all column mappings and business rules."""
    source_system: str = ""
    source_schema: str = ""
    source_table: str = ""
    target_schema: str = ""
    target_table: str = ""
    table_comment: str = ""
    columns: list[ColumnMapping] = field(default_factory=list)
    filter_condition: str = ""         # WHERE clause
    join_conditions: list[JoinClause] = field(default_factory=list)  # multi-table JOIN
    group_by: list[str] = field(default_factory=list)
    order_by: list[str] = field(default_factory=list)
    business_rules: list[str] = field(default_factory=list)
    incremental_key: str = ""          # for MERGE/CDC scenarios

    def get_source_columns(self) -> list[str]:
        return [c.source_column for c in self.columns if c.source_column]

    def get_target_columns(self) -> list[str]:
        return [c.target_column for c in self.columns if c.target_column]

    def get_pk_columns(self) -> list[str]:
        return [c.target_column for c in self.columns if c.is_pk]


@dataclass
class MappingDocument:
    """Complete mapping document with metadata and multiple table mappings."""
    title: str = ""
    author: str = ""
    create_date: str = ""
    version: str = "1.0"
    description: str = ""
    table_mappings: list[TableMapping] = field(default_factory=list)

    @property
    def table_count(self) -> int:
        return len(self.table_mappings)

    @property
    def total_column_count(self) -> int:
        return sum(len(tm.columns) for tm in self.table_mappings)
