"""SQL code formatter — applies bank data platform coding standards."""

from datetime import datetime
from pathlib import Path

import sqlparse
import yaml


class SQLFormatter:
    """Applies SQL coding standards from config to generated SQL.

    Two modes:
      - normalize_case(sql) — keyword/identifier case only, preserves layout
      - format(sql) — full reformat (indent, commas, wrap)
    """

    _SQL_KEYWORDS = {
        "SELECT", "FROM", "WHERE", "AND", "OR", "NOT", "IN", "IS", "NULL",
        "INSERT", "INTO", "VALUES", "UPDATE", "SET", "DELETE", "CREATE",
        "TABLE", "ALTER", "DROP", "INDEX", "VIEW", "MERGE", "USING",
        "JOIN", "INNER", "LEFT", "RIGHT", "FULL", "CROSS", "ON",
        "AS", "CASE", "WHEN", "THEN", "ELSE", "END",
        "GROUP", "BY", "ORDER", "ASC", "DESC", "HAVING",
        "COUNT", "SUM", "AVG", "MAX", "MIN", "COALESCE", "NVL",
        "CAST", "DISTINCT", "ALL", "UNION", "EXCEPT", "INTERSECT",
        "PRIMARY", "KEY", "CONSTRAINT", "FOREIGN", "REFERENCES",
        "NOT", "DEFAULT", "CHECK", "UNIQUE",
        "COMMENT", "MATCHED", "COMMIT", "ROLLBACK", "BEGIN", "TRUNCATE",
    }

    def __init__(self, config_path: str = None):
        self.config = self._load_config(config_path)

    def _load_config(self, config_path: str = None) -> dict:
        """Load SQL standards from YAML config file."""
        defaults = {
            "dialect": "oracle",
            "naming": {"keyword_case": "upper", "identifier_case": "lower"},
            "formatting": {
                "indent": "    ",
                "max_line_length": 120,
                "comma_style": "leading",
                "each_column_newline": True,
            },
            "header_template": "",
        }

        if config_path:
            with open(config_path, "r", encoding="utf-8") as f:
                user_config = yaml.safe_load(f)
                if user_config:
                    defaults.update(user_config)
            return defaults

        # Try default config path
        default_path = Path(__file__).parent.parent / "config" / "sql_standards.yaml"
        if default_path.exists():
            with open(default_path, "r", encoding="utf-8") as f:
                user_config = yaml.safe_load(f)
                if user_config:
                    defaults.update(user_config)

        return defaults

    # ── Public API ──────────────────────────────────────

    def normalize_case(self, sql: str) -> str:
        """Normalize keyword and identifier case without touching layout.

        Splits into lines so that -- comments are left untouched.
        """
        import re

        keyword_case = self.config["naming"]["keyword_case"]

        if keyword_case != "upper":
            return sql

        lines = []
        for line in sql.splitlines():
            # Preserve full-line comments untouched
            stripped = line.lstrip()
            if stripped.startswith("--"):
                lines.append(line)
                continue

            # For lines with inline comments, only normalize the code part
            comment_pos = line.find("--")
            if comment_pos >= 0:
                code_part = line[:comment_pos]
                comment_part = line[comment_pos:]
            else:
                code_part = line
                comment_part = ""

            for kw in sorted(self._SQL_KEYWORDS, key=len, reverse=True):
                code_part = re.sub(
                    r'\b' + re.escape(kw) + r'\b',
                    kw.upper(),
                    code_part,
                    flags=re.IGNORECASE,
                )

            lines.append(code_part + comment_part)

        return "\n".join(lines)

        # For identifier_case, we only fix known patterns that template output
        # might have left in the wrong case (table/column names are template-driven
        # and should be correct already; this is a safety net).
        if identifier_case == "lower":
            # Only lowercase unquoted identifiers that sqlparse flags as names
            pass  # template output is already lowercase for identifiers

        return result

    def format(self, sql: str) -> str:
        """Full structural reformat: indent, commas, wrapping.

        Use this for raw/unformatted SQL. For template-generated SQL,
        prefer normalize_case() to preserve the template's layout.
        """
        keyword_case = self.config["naming"]["keyword_case"]
        identifier_case = self.config["naming"]["identifier_case"]

        result = sqlparse.format(
            sql,
            reindent=True,
            keyword_case=keyword_case,
            identifier_case=identifier_case,
            indent_width=4,
            wrap_after=self.config["formatting"]["max_line_length"],
            comma_first=(self.config["formatting"]["comma_style"] == "leading"),
        )

        return result

    def finalize(self, sql: str, metadata: dict = None) -> str:
        """Final formatting pass with metadata (author, date, etc.).

        Args:
            sql: SQL string to finalize
            metadata: dict with keys like author, create_date, description, etc.

        Returns:
            Final formatted SQL
        """
        if not metadata:
            metadata = {}

        # Add header if not already present
        header_template = self.config.get("header_template", "")
        if header_template and not sql.lstrip().startswith("-- ===="):
            header_vars = {
                "program_name": metadata.get("program_name", "ETL_PROCESS"),
                "description": metadata.get("description", ""),
                "source_tables": metadata.get("source_tables", ""),
                "target_table": metadata.get("target_table", ""),
                "author": metadata.get("author", "DATA_TEAM"),
                "create_date": metadata.get("create_date",
                                             datetime.now().strftime("%Y-%m-%d")),
            }
            header = header_template.format(**header_vars)
            sql = header + "\n\n" + sql

        return sql.strip() + "\n"
