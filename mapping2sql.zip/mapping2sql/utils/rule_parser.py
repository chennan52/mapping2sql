"""Natural language rule parser for transformation rules in Mapping documents."""

import re
from typing import Optional


class RuleParser:
    """Parse Chinese/English natural language transformation rules into structured SQL expressions."""

    # Patterns for matching common rule types in Chinese
    PATTERNS = {
        "direct": [
            r"^(直接映射|直接|direct|照搬|原样|不变|无转换)$",
            r"^(源字段|来源字段|取值)$",
        ],
        "constant": [
            r"^(填|填写|填充|默认为|默认值|常量|固定值)[:：]?\s*['\"]?(.+?)['\"]?$",
            r"^(默认|default|constant)\s*[:：]?\s*['\"]?(.+?)['\"]?$",
        ],
        "nvl": [
            r"^(空值|为空|null|NULL|空)\s*(填|替换|转|变)?为?\s*(.+)$",
            r"^(nvl|NVL|coalesce)\((.+)\)$",
        ],
        "case_when": [
            r"^当(.+?)(时|则|，)\s*['\"]?(.+?)['\"]?\s*(否则|不然|else|ELSE)\s*['\"]?(.+?)['\"]?$",
            r"^如果(.+?)(那么|则|，)\s*['\"]?(.+?)['\"]?\s*(否则|不然)\s*['\"]?(.+?)['\"]?$",
        ],
        "type_cast": [
            r"^(转|转为|转换|cast|CAST)\s*(为|成|到)?\s*(.+?)(类型|格式)?$",
            r"^(类型转换|格式转换)[:：]?\s*(.+)$",
        ],
        "sum": [
            r"^(求和|汇总|合计|累加|SUM|sum)\s*[\(（]?\s*(.+?)\s*[\)）]?$",
            r"^(按|按照|根据)(.+?)(汇总|求和|聚合|分组)$",
        ],
        "avg": [r"^(平均|均值|AVG|avg)\s*[\(（]?\s*(.+?)\s*[\)）]?$"],
        "count": [r"^(计数|个数|COUNT|count)\s*[\(（]?\s*(.+?)\s*[\)）]?$"],
        "max": [r"^(最大|最大值|MAX|max)\s*[\(（]?\s*(.+?)\s*[\)）]?$"],
        "min": [r"^(最小|最小值|MIN|min)\s*[\(（]?\s*(.+?)\s*[\)）]?$"],
        "concat": [
            r"^(拼接|连接|合并|CONCAT|concat)\s*(.+?)(和|与|,|，)\s*(.+)$",
            r"^(.+?)\s*[\+\|\|]\s*(.+)$",
        ],
        "substring": [
            r"^(截取|取子串|SUBSTR|substr)\s*[\(（]?\s*(.+?)\s*[,，]\s*(\d+)\s*[,，]?\s*(\d+)?\s*[\)）]?$",
        ],
        "date_format": [
            r"^(TO_CHAR|to_char|DATE_FORMAT|date_format)\s*[\(（]\s*(\w+)\s*[,，]\s*['\"]?(\w+)['\"]?\s*[\)）]$",
            r"^(TO_CHAR|to_char|DATE_FORMAT|date_format)\s+(\w+)\s+(\w+)$",
            r"^(日期格式化?|格式化)\s*[:：]?\s*(\w+)?\s*(\w+)?$",
            r"^(取日期|转日期|TO_DATE|to_date)\s*[\(（]?\s*(.+?)\s*[\)）]?$",
        ],
        "yoy": [
            r"^(同比|同比增长率|YOY|yoy)",
        ],
        "mom": [
            r"^(环比|环比增长率|MOM|mom)",
        ],
    }

    @classmethod
    def parse(cls, rule_text: str) -> dict:
        """Parse a rule text and return structured rule info.

        Returns:
            dict with keys: type, expression, params, confidence
            type: one of 'direct','constant','nvl','case_when','type_cast','sum',
                  'avg','count','max','min','concat','substring','date_format',
                  'yoy','mom','unknown'
        """
        if not rule_text or not rule_text.strip():
            return {"type": "direct", "expression": "", "params": {}, "confidence": 1.0}

        text = rule_text.strip()

        for rule_type, patterns in cls.PATTERNS.items():
            for pattern in patterns:
                match = re.match(pattern, text, re.IGNORECASE)
                if match:
                    result = {"type": rule_type, "params": {}, "confidence": 0.9}
                    groups = match.groups()

                    if rule_type == "constant":
                        result["params"]["value"] = groups[-1]
                        result["expression"] = f"'{groups[-1]}'"
                    elif rule_type == "nvl":
                        result["params"]["field"] = groups[0] if len(groups) > 1 else ""
                        result["params"]["default"] = groups[-1] if len(groups) > 1 else groups[0]
                        result["expression"] = text
                    elif rule_type == "case_when":
                        result["params"]["condition"] = groups[0]
                        result["params"]["then_value"] = groups[2] if len(groups) > 2 else ""
                        result["params"]["else_value"] = groups[4] if len(groups) > 4 else ""
                        result["expression"] = text
                        # Detect multi-condition rules the single-pattern regex can't handle
                        then_val = result["params"]["then_value"]
                        cond_val = result["params"]["condition"]
                        if any(kw in then_val for kw in ("当", "则为", "如果", "那么")):
                            result["confidence"] = 0.3
                        if any(kw in cond_val for kw in ("且", "并且", "同时", "或者")):
                            result["confidence"] = 0.5
                    elif rule_type == "sum":
                        result["params"]["field"] = groups[-1] if len(groups) > 1 else groups[0]
                        result["expression"] = f"SUM({result['params']['field']})"
                    elif rule_type == "avg":
                        result["params"]["field"] = groups[-1] if len(groups) > 1 else groups[0]
                        result["expression"] = f"AVG({result['params']['field']})"
                    elif rule_type == "count":
                        result["params"]["field"] = groups[-1] if len(groups) > 1 else groups[0]
                        result["expression"] = f"COUNT({result['params']['field']})"
                    elif rule_type == "max":
                        result["params"]["field"] = groups[-1] if len(groups) > 1 else groups[0]
                        result["expression"] = f"MAX({result['params']['field']})"
                    elif rule_type == "min":
                        result["params"]["field"] = groups[-1] if len(groups) > 1 else groups[0]
                        result["expression"] = f"MIN({result['params']['field']})"
                    elif rule_type == "concat":
                        result["params"]["fields"] = [g for g in groups if g and g not in ("和", "与", ",")]
                        result["expression"] = text
                    elif rule_type == "substring":
                        result["params"]["field"] = groups[0]
                        result["params"]["start"] = groups[1]
                        result["params"]["length"] = groups[2] if len(groups) > 2 else None
                        result["expression"] = text
                    elif rule_type == "date_format":
                        # Date format patterns: (keyword, field, format) or (keyword, field) or (keyword)
                        if len(groups) >= 3 and groups[2]:
                            result["params"]["field"] = groups[1]
                            result["params"]["format"] = groups[2]
                        elif len(groups) >= 2 and groups[1]:
                            val = groups[1]
                            # If the captured value looks like a date format mask, use it as format
                            if re.match(r'^[YMDymd\-/]+$', val):
                                result["params"]["field"] = ""
                                result["params"]["format"] = val
                            else:
                                result["params"]["field"] = val
                                result["params"]["format"] = "YYYYMMDD"
                        else:
                            result["params"]["field"] = groups[0]
                            result["params"]["format"] = "YYYYMMDD"
                        result["expression"] = text
                    elif rule_type in ("yoy", "mom"):
                        result["expression"] = rule_type
                    else:
                        result["expression"] = rule_type

                    return result

        # Check for SQL-like expressions directly in rule text
        if cls._looks_like_sql(text):
            return {"type": "sql_expression", "expression": text, "params": {}, "confidence": 0.7}

        return {"type": "unknown", "expression": text, "params": {}, "confidence": 0.3}

    @classmethod
    def _looks_like_sql(cls, text: str) -> bool:
        """Check if the text looks like a SQL expression."""
        sql_keywords = ["SELECT", "CASE", "WHEN", "THEN", "ELSE", "END",
                        "SUM(", "COUNT(", "AVG(", "MAX(", "MIN(",
                        "NVL(", "COALESCE(", "DECODE(", "CAST(",
                        "CONCAT(", "SUBSTR(", "TO_CHAR(", "TO_DATE("]
        upper = text.upper()
        return any(kw in upper for kw in sql_keywords)
