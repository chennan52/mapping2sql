"""Multi-format mapping document parser.

Parses Excel (.xlsx), CSV, and Word (.docx) mapping documents into a unified
MappingDocument model with TableMapping and ColumnMapping objects.
"""

import io
from pathlib import Path
from typing import Optional

import pandas as pd

from .models import ColumnMapping, TableMapping, MappingDocument, JoinClause


class MappingParser:
    """Parse mapping documents from Excel, CSV, or Word formats."""

    # Keywords for auto-detecting column roles in mapping sheets
    SOURCE_TABLE_KEYWORDS = ["源表", "来源表", "source table", "ods", "src_table",
                              "源表名", "来源表名", "source_table"]
    TARGET_TABLE_KEYWORDS = ["目标表", "目的表", "target table", "dwd", "dws", "ads",
                              "目标表名", "目的表名", "target_table"]
    SOURCE_COLUMN_KEYWORDS = ["源字段", "来源字段", "source column", "src_col",
                               "源字段名", "来源字段名", "source_column", "source_col"]
    TARGET_COLUMN_KEYWORDS = ["目标字段", "目的字段", "target column", "tgt_col",
                               "目标字段名", "目的字段名", "target_column", "target_col"]
    SOURCE_TYPE_KEYWORDS = ["源类型", "来源类型", "source type", "src_type", "source_type"]
    TARGET_TYPE_KEYWORDS = ["目标类型", "目的类型", "target type", "tgt_type", "target_type"]
    RULE_KEYWORDS = ["转换规则", "转换逻辑", "transform", "rule", "mapping rule",
                      "转换", "规则", "transformation", "transform_rule"]
    COMMENT_KEYWORDS = ["备注", "说明", "comment", "remarks", "描述", "description",
                         "注释", "note"]
    PK_KEYWORDS = ["主键", "primary key", "is_pk", "pk", "是否主键"]
    NULLABLE_KEYWORDS = ["可空", "nullable", "允许为空", "is_nullable"]
    JOIN_KEYWORDS = ["关联条件", "join条件", "join", "关联表", "连接条件",
                     "关联", "join_condition", "join条件/关联表"]

    def parse(self, file_path: str) -> MappingDocument:
        """Parse a mapping file and return a MappingDocument.

        Automatically detects format by file extension.
        """
        path = Path(file_path)
        suffix = path.suffix.lower()

        if suffix in (".xlsx", ".xls"):
            return self._parse_excel(file_path)
        elif suffix == ".csv":
            return self._parse_csv(file_path)
        elif suffix == ".docx":
            return self._parse_word(file_path)
        else:
            raise ValueError(f"不支持的文件格式: {suffix}。支持的格式: .xlsx, .csv, .docx")

    def _parse_excel(self, file_path: str) -> MappingDocument:
        """Parse Excel mapping document.

        Auto-detects which sheet is table-level mapping and which is column-level.
        Typical structure:
          - Sheet1: 表级映射 (source table -> target table metadata)
          - Sheet2: 字段级映射 (column-level mappings)
        """
        xl = pd.ExcelFile(file_path)
        doc = MappingDocument(title=Path(file_path).stem)

        # First pass: collect table-level metadata and column-level data
        table_meta = {}  # source_table -> TableMapping (metadata only, no columns)
        column_mappings = []  # list of (sheet_name, TableMapping)

        for sheet_name in xl.sheet_names:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            if df.empty:
                continue

            df = df.dropna(how="all")
            headers = [str(h).strip() if pd.notna(h) else "" for h in df.columns]
            col_map = self._match_columns(headers)

            if col_map.get("source_column") is not None and col_map.get("target_column") is not None:
                # Column-level mapping sheet
                tm = self._parse_column_sheet(df, col_map, sheet_name=sheet_name)
                column_mappings.append((sheet_name, tm))
            elif col_map.get("source_table") is not None or col_map.get("target_table") is not None:
                # Table-level metadata sheet
                self._collect_table_meta(df, col_map, table_meta)

        # Merge: enrich column-based mappings with table metadata
        used_meta_keys = set()
        for sheet_name, tm in column_mappings:
            key = tm.source_table

            # If table name not in meta, try to infer from sheet name
            if key not in table_meta:
                matched = self._match_sheet_to_table(sheet_name, table_meta, used_meta_keys)
                if matched != "unknown_table":
                    key = matched

            if key in table_meta:
                # Also update source_table from meta
                tm.source_table = key
                meta = table_meta[key]
                if meta.source_system:
                    tm.source_system = meta.source_system
                if meta.source_schema:
                    tm.source_schema = meta.source_schema
                if meta.target_schema:
                    tm.target_schema = meta.target_schema
                if meta.target_table and meta.target_table != "unknown_table":
                    tm.target_table = meta.target_table
                if meta.table_comment:
                    tm.table_comment = meta.table_comment
                if meta.business_rules:
                    tm.business_rules = meta.business_rules
                if meta.filter_condition:
                    tm.filter_condition = meta.filter_condition
                if meta.incremental_key:
                    tm.incremental_key = meta.incremental_key
                if meta.join_conditions:
                    tm.join_conditions = meta.join_conditions
            doc.table_mappings.append(tm)

        return doc

    def _parse_csv(self, file_path: str) -> MappingDocument:
        """Parse CSV mapping document."""
        encodings = ["utf-8", "gbk", "gb2312", "utf-8-sig"]
        df = None
        for enc in encodings:
            try:
                df = pd.read_csv(file_path, encoding=enc)
                break
            except (UnicodeDecodeError, UnicodeError):
                continue

        if df is None:
            raise ValueError(f"无法解析CSV文件编码: {file_path}")

        df = df.dropna(how="all")
        headers = [str(h).strip() if pd.notna(h) else "" for h in df.columns]
        col_map = self._match_columns(headers)

        doc = MappingDocument(title=Path(file_path).stem)

        if col_map.get("source_column") is not None and col_map.get("target_column") is not None:
            table_mapping = self._parse_column_sheet(df, col_map)
            doc.table_mappings.append(table_mapping)

        return doc

    def _parse_word(self, file_path: str) -> MappingDocument:
        """Parse Word (.docx) mapping document by extracting tables.

        Handles both table-level metadata tables and column-level mapping tables,
        merging them together like Excel parsing does.
        """
        from docx import Document

        word_doc = Document(file_path)
        doc = MappingDocument(title=Path(file_path).stem)

        table_meta = {}       # source_table -> TableMapping metadata
        column_mappings = []  # list of TableMapping with columns

        for table in word_doc.tables:
            # Extract headers from first row
            header_row = table.rows[0]
            headers = [cell.text.strip() for cell in header_row.cells]

            if not headers or all(h == "" for h in headers):
                continue

            col_map = self._match_columns(headers)

            # Convert remaining rows to list-of-lists for DataFrame
            rows = []
            for row in table.rows[1:]:
                cells = [cell.text.strip() for cell in row.cells]
                if any(cells):
                    # Pad short rows to match header length
                    while len(cells) < len(headers):
                        cells.append("")
                    rows.append(cells[:len(headers)])

            if not rows:
                continue

            df = pd.DataFrame(rows, columns=headers)

            if col_map.get("source_column") is not None and col_map.get("target_column") is not None:
                # Column-level mapping sheet
                tm = self._parse_column_sheet(df, col_map)
                column_mappings.append(tm)
            elif col_map.get("source_table") is not None or col_map.get("target_table") is not None:
                # Table-level metadata sheet
                self._collect_table_meta(df, col_map, table_meta)

        # Merge table metadata into column mappings
        for tm in column_mappings:
            key = tm.source_table if tm.source_table != "unknown_table" else None

            # If column table has no explicit table names, try to match with metadata
            if key is None or key == "unknown_table":
                if len(table_meta) == 1:
                    # Single meta entry — use it directly
                    key = list(table_meta.keys())[0]
                elif tm.columns:
                    # Try to infer from first column's data
                    first_src_col = tm.columns[0].source_column
                    for meta_key, meta in table_meta.items():
                        if first_src_col in meta_key or meta_key in first_src_col:
                            key = meta_key
                            break
                if key is None and table_meta:
                    # Last resort: use first meta entry with a warning
                    key = list(table_meta.keys())[0]

            if key and key in table_meta:
                meta = table_meta[key]
                if meta.source_system:
                    tm.source_system = meta.source_system
                if meta.source_schema:
                    tm.source_schema = meta.source_schema
                if meta.target_schema:
                    tm.target_schema = meta.target_schema
                if meta.target_table and meta.target_table != "unknown_table":
                    tm.target_table = meta.target_table
                if meta.table_comment:
                    tm.table_comment = meta.table_comment
                if meta.business_rules:
                    tm.business_rules = meta.business_rules
                if meta.filter_condition:
                    tm.filter_condition = meta.filter_condition
                if meta.incremental_key:
                    tm.incremental_key = meta.incremental_key
                if meta.join_conditions:
                    tm.join_conditions = meta.join_conditions

            # Update source_table if we resolved it
            if key and key != "unknown_table":
                tm.source_table = key
                for cm in tm.columns:
                    cm.source_table = key

            doc.table_mappings.append(tm)

        return doc

    def _match_columns(self, headers: list[str]) -> dict:
        """Match header names to known column roles using keyword matching."""
        result = {}
        for i, h in enumerate(headers):
            h_lower = h.lower().replace(" ", "").replace("_", "").replace("-", "")
            for role, keywords in [
                ("source_table", self.SOURCE_TABLE_KEYWORDS),
                ("target_table", self.TARGET_TABLE_KEYWORDS),
                ("source_column", self.SOURCE_COLUMN_KEYWORDS),
                ("target_column", self.TARGET_COLUMN_KEYWORDS),
                ("source_type", self.SOURCE_TYPE_KEYWORDS),
                ("target_type", self.TARGET_TYPE_KEYWORDS),
                ("transform_rule", self.RULE_KEYWORDS),
                ("comment", self.COMMENT_KEYWORDS),
                ("is_pk", self.PK_KEYWORDS),
                ("nullable", self.NULLABLE_KEYWORDS),
                ("join_condition", self.JOIN_KEYWORDS),
            ]:
                if role not in result:
                    for kw in keywords:
                        kw_clean = kw.lower().replace(" ", "").replace("_", "").replace("-", "")
                        if kw_clean in h_lower or h_lower in kw_clean:
                            result[role] = i
                            break
        return result

    def _parse_column_sheet(self, df: pd.DataFrame, col_map: dict,
                             sheet_name: str = "") -> TableMapping:
        """Parse a column-level mapping sheet into a TableMapping.

        Args:
            df: DataFrame with mapping data rows.
            col_map: Column index map from header matching.
            sheet_name: Optional sheet name for table name inference.
        """
        tm = TableMapping()

        src_col_idx = col_map.get("source_column", 0)
        tgt_col_idx = col_map.get("target_column", 1)

        # Extract table-level info from first data row or consistent values
        if "source_table" in col_map:
            tm.source_table = str(df.iloc[0, col_map["source_table"]]) if pd.notna(df.iloc[0, col_map["source_table"]]) else ""
        if "target_table" in col_map:
            tm.target_table = str(df.iloc[0, col_map["target_table"]]) if pd.notna(df.iloc[0, col_map["target_table"]]) else ""

        # If no explicit table columns, try to infer from column prefixes or the first row
        if not tm.source_table:
            tm.source_table = self._infer_table_name(df, "source", sheet_hint=sheet_name)
        if not tm.target_table:
            tm.target_table = self._infer_table_name(df, "target", sheet_hint=sheet_name)

        # Parse each row as a column mapping
        for idx, row in df.iterrows():
            src_col = str(row.iloc[src_col_idx]).strip() if pd.notna(row.iloc[src_col_idx]) else ""
            tgt_col = str(row.iloc[tgt_col_idx]).strip() if pd.notna(row.iloc[tgt_col_idx]) else ""

            if not src_col or not tgt_col:
                continue

            cm = ColumnMapping(
                source_table=tm.source_table,
                source_column=src_col,
                target_table=tm.target_table,
                target_column=tgt_col,
                sort_order=idx,
            )

            # Optional fields
            for field, idx_key in [
                ("source_type", "source_type"),
                ("target_type", "target_type"),
                ("transform_rule", "transform_rule"),
                ("comment", "comment"),
                ("is_pk", "is_pk"),
                ("nullable", "nullable"),
            ]:
                if idx_key in col_map:
                    val = row.iloc[col_map[idx_key]]
                    val_str = str(val).strip() if pd.notna(val) else ""
                    if val_str:
                        if field == "is_pk":
                            cm.is_pk = val_str.lower() in ("yes", "y", "true", "1", "是", "主键")
                        elif field == "nullable":
                            cm.nullable = val_str.lower() not in ("no", "n", "false", "0", "否", "不允许")
                        else:
                            setattr(cm, field, val_str)

            tm.columns.append(cm)

        return tm

    def _collect_table_meta(self, df: pd.DataFrame, col_map: dict,
                             table_meta: dict):
        """Collect table-level metadata into a lookup dict keyed by source table."""
        src_tbl_idx = col_map.get("source_table", 0)
        tgt_tbl_idx = col_map.get("target_table", 1)

        # Look for additional metadata columns
        comment_idx = col_map.get("comment")
        src_sys_idx = None
        inc_key_idx = None
        join_idx = col_map.get("join_condition")  # May be detected via _match_columns

        headers = [str(h).strip() if pd.notna(h) else "" for h in df.columns]
        for i, h in enumerate(headers):
            h_lower = h.lower().replace(" ", "")
            if any(kw in h_lower for kw in ["源系统", "来源系统", "source_system", "sourcesystem"]):
                src_sys_idx = i
            if any(kw in h_lower for kw in ["增量键", "增量", "incremental", "incrementalkey"]):
                inc_key_idx = i
            # Detect join column if not already matched
            if join_idx is None:
                for kw in self.JOIN_KEYWORDS:
                    if kw.lower().replace(" ", "") in h_lower:
                        join_idx = i
                        break

        for _, row in df.iterrows():
            src_tbl = str(row.iloc[src_tbl_idx]).strip() if pd.notna(row.iloc[src_tbl_idx]) else ""
            tgt_tbl = str(row.iloc[tgt_tbl_idx]).strip() if pd.notna(row.iloc[tgt_tbl_idx]) else ""
            if src_tbl and tgt_tbl:
                tm = TableMapping(source_table=src_tbl, target_table=tgt_tbl)
                if comment_idx is not None:
                    val = row.iloc[comment_idx]
                    tm.table_comment = str(val).strip() if pd.notna(val) else ""
                if src_sys_idx is not None:
                    val = row.iloc[src_sys_idx]
                    tm.source_system = str(val).strip() if pd.notna(val) else ""
                if inc_key_idx is not None:
                    val = row.iloc[inc_key_idx]
                    tm.incremental_key = str(val).strip() if pd.notna(val) else ""
                if join_idx is not None:
                    val = row.iloc[join_idx]
                    join_text = str(val).strip() if pd.notna(val) else ""
                    if join_text:
                        tm.join_conditions = self._parse_join_text(join_text)
                table_meta[src_tbl] = tm

    def _parse_join_text(self, text: str) -> list[JoinClause]:
        """Parse a join condition text into JoinClause objects.

        Supports formats like:
          - "LEFT JOIN ODS.LN_REPAY r ON s.apply_id = r.apply_id"
          - "INNER JOIN ods.cust_info c ON s.cust_id = c.cust_id"
          - "s.apply_id = r.apply_id" (bare ON condition — INNER JOIN assumed)
          - Multiple JOINs separated by ";" or newlines
        """
        import re
        joins = []
        # Split on semicolons or newlines for multiple JOINs
        parts = re.split(r'[;\n]+', text)
        for part in parts:
            part = part.strip()
            if not part:
                continue

            join_clause = JoinClause()

            # Try to match "JOIN_TYPE JOIN table alias ON condition"
            pattern = (r'(?P<type>INNER|LEFT|RIGHT|FULL|CROSS)?\s*'
                       r'JOIN\s+'
                       r'(?P<table>[\w.]+)\s+'
                       r'(?P<alias>\w+)\s+'
                       r'ON\s+'
                       r'(?P<on>.+)')
            m = re.match(pattern, part, re.IGNORECASE)
            if m:
                join_clause.join_type = (m.group('type') or 'INNER').upper()
                join_clause.table = m.group('table')
                join_clause.alias = m.group('alias')
                join_clause.on_condition = m.group('on').strip()
                joins.append(join_clause)
                continue

            # Try "bare ON condition" format: "a.col = b.col"
            if re.match(r'^\w+\.\w+\s*=\s*\w+\.\w+', part):
                join_clause.join_type = "INNER"
                join_clause.on_condition = part.strip()
                # Infer table/alias from the condition
                parts_on = re.split(r'\s*=\s*', part, maxsplit=1)
                if len(parts_on) == 2:
                    left_alias = parts_on[0].split('.')[0]
                    right_alias = parts_on[1].split('.')[0]
                    join_clause.alias = right_alias
                joins.append(join_clause)

        return joins

    def _infer_table_name(self, df: pd.DataFrame, which: str,
                            sheet_hint: str = "") -> str:
        """Try to infer table name from column values, data context, or sheet name.

        Args:
            df: DataFrame with data rows.
            which: "source" or "target".
            sheet_hint: Optional sheet name that may contain table name clues.
        """
        # First, try to extract from sheet name (e.g., "LN_APPLY字段映射" → "LN_APPLY")
        if sheet_hint:
            import re
            # Strip common suffixes from sheet name to get table hint
            hint = re.sub(r'[字段映射表]+', '', sheet_hint).strip()
            if hint and len(hint) < 60:
                return hint

        for _, row in df.iterrows():
            for val in row:
                val_str = str(val).strip() if pd.notna(val) else ""
                if "." in val_str and len(val_str) < 100:
                    parts = val_str.split(".")
                    if len(parts) == 2:
                        return val_str
        return "unknown_table"

    def _match_sheet_to_table(self, sheet_name: str, table_meta: dict,
                                used_keys: set) -> str:
        """Match a column-level sheet to a table-level metadata entry.

        Uses sheet name as hint (e.g., 'LN_APPLY字段映射' matches 'ODS.LN_APPLY').
        Skips already-matched meta entries via used_keys.
        """
        # Extract table hint from sheet name
        hint = sheet_name
        for suffix in ['字段映射', '表映射', 'column', 'mapping', '映射', '字段']:
            hint = hint.replace(suffix, '')
        hint = hint.strip()

        if not hint:
            return "unknown_table"

        best_key = None
        for meta_key in table_meta:
            if meta_key in used_keys:
                continue
            # e.g., hint="LN_APPLY" matches meta_key="ODS.LN_APPLY"
            if hint.upper() in meta_key.upper() or meta_key.upper() in hint.upper():
                best_key = meta_key
                break
            # Also try matching just the table name part (after dot)
            table_part = meta_key.split(".")[-1] if "." in meta_key else meta_key
            if hint.upper() in table_part.upper() or table_part.upper() in hint.upper():
                best_key = meta_key
                break

        if best_key:
            used_keys.add(best_key)
            return best_key

        # Last resort: pick first unused meta key
        for meta_key in table_meta:
            if meta_key not in used_keys:
                used_keys.add(meta_key)
                return meta_key

        return "unknown_table"
