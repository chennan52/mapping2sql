-- ==== DWD.DWD_ACCT_DAILY_ddl ====
-- ============================================================
-- 程序名称: CREATE_DWD_ACCT_DAILY
-- 功能描述: 账户日汇总明细表
-- 源表: ODS.ACCT_DAILY
-- 目标表: DWD.DWD_ACCT_DAILY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

CREATE TABLE DWD.DWD_ACCT_DAILY (
    acct_no  VARCHAR2(20)  PRIMARY KEY  NOT NULL,
    cust_id  VARCHAR2(18)  NOT NULL,
    org_code  VARCHAR2(12)  NOT NULL,
    currency  VARCHAR2(3)  NOT NULL,
    balance  NUMBER(18,2)  NOT NULL,
    avail_balance  NUMBER(18,2)  NOT NULL,
    status_name  VARCHAR2(20)  NOT NULL,
    open_date  DATE  NOT NULL,
    open_month  VARCHAR2(6)  NOT NULL,
    last_txn_date  DATE,
    frozen_amt  NUMBER(18,2),
    mgr_name  VARCHAR2(50),
    prod_code  VARCHAR2(8)  NOT NULL,
    acct_type  VARCHAR2(4)  NOT NULL,
    etl_date  DATE  NOT NULL
);

COMMENT ON TABLE DWD.DWD_ACCT_DAILY IS '账户日汇总明细表';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.acct_no IS '账号';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.cust_id IS '客户号';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.org_code IS '机构号';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.currency IS '币种';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.balance IS '余额';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.avail_balance IS '可用余额';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.status_name IS '账户状态名称';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.open_date IS '开户日期';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.open_month IS '开户月份';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.last_txn_date IS '最后交易日期';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.frozen_amt IS '冻结金额';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.mgr_name IS '客户经理ID';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.prod_code IS '产品代码';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.acct_type IS '账户类型';
COMMENT ON COLUMN DWD.DWD_ACCT_DAILY.etl_date IS 'ETL日期';


-- ==== DWD.DWD_ACCT_DAILY_dml ====
-- ============================================================
-- 程序名称: ETL_ACCT_DAILY_TO_DWD_ACCT_DAILY
-- 功能描述: 从 ODS.ACCT_DAILY 同步数据到 DWD.DWD_ACCT_DAILY
-- 源表: ODS.ACCT_DAILY
-- 目标表: DWD.DWD_ACCT_DAILY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

INSERT INTO DWD.DWD_ACCT_DAILY
(
    acct_no
    ,cust_id
    ,org_code
    ,currency
    ,balance
    ,avail_balance
    ,status_name
    ,open_date
    ,open_month
    ,last_txn_date
    ,frozen_amt
    ,mgr_name
    ,prod_code
    ,acct_type
    ,etl_date
)
SELECT
    acct_no  -- 账号
    ,cust_id  -- 客户号
    ,org_code  -- 机构号
    ,currency  -- 币种
    ,balance  -- 余额
    ,avail_balance  -- 可用余额
    ,CASE WHEN status=1 THEN '正常'
       ELSE '冻结或未知'
  END  -- 账户状态名称
    ,open_date  -- 开户日期
    ,TO_CHAR(open_date, 'YYYYMM')  -- 开户月份
    ,NVL(last_txn_date, 1900-01-01)  -- 最后交易日期
    ,NVL(frozen_amt, 0)  -- 冻结金额
    ,CAST(mgr_id AS VARCHAR2(50))  -- 客户经理ID
    ,prod_code  -- 产品代码
    ,acct_type  -- 账户类型
    ,etl_date  -- ETL日期
FROM ODS.ACCT_DAILY  s
;


-- ==== DWD.DWD_ACCT_DAILY_merge ====
-- ============================================================
-- 程序名称: MERGE_ACCT_DAILY_TO_DWD_ACCT_DAILY
-- 功能描述: 增量同步 ODS.ACCT_DAILY -> DWD.DWD_ACCT_DAILY
-- 源表: ODS.ACCT_DAILY
-- 目标表: DWD.DWD_ACCT_DAILY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

MERGE INTO DWD.DWD_ACCT_DAILY  t
USING (
    SELECT
            acct_no  -- 账号
            ,cust_id  -- 客户号
            ,org_code  -- 机构号
            ,currency  -- 币种
            ,balance  -- 余额
            ,avail_balance  -- 可用余额
            ,CASE WHEN status=1 THEN '正常'
       ELSE '冻结或未知'
  END  -- 账户状态名称
            ,open_date  -- 开户日期
            ,TO_CHAR(open_date, 'YYYYMM')  -- 开户月份
            ,NVL(last_txn_date, 1900-01-01)  -- 最后交易日期
            ,NVL(frozen_amt, 0)  -- 冻结金额
            ,CAST(mgr_id AS VARCHAR2(50))  -- 客户经理ID
            ,prod_code  -- 产品代码
            ,acct_type  -- 账户类型
            ,etl_date  -- ETL日期
    FROM ODS.ACCT_DAILY  s
)  src

ON (t.acct_no = src.acct_no)
WHEN MATCHED THEN
    UPDATE SET
        t.cust_id = src.cust_id
        ,t.org_code = src.org_code
        ,t.currency = src.currency
        ,t.balance = src.balance
        ,t.avail_balance = src.avail_balance
        ,t.status_name = src.status_name
        ,t.open_date = src.open_date
        ,t.open_month = src.open_month
        ,t.last_txn_date = src.last_txn_date
        ,t.frozen_amt = src.frozen_amt
        ,t.mgr_name = src.mgr_name
        ,t.prod_code = src.prod_code
        ,t.acct_type = src.acct_type
        ,t.etl_date = src.etl_date
WHEN NOT MATCHED THEN
    INSERT (
            acct_no
            ,cust_id
            ,org_code
            ,currency
            ,balance
            ,avail_balance
            ,status_name
            ,open_date
            ,open_month
            ,last_txn_date
            ,frozen_amt
            ,mgr_name
            ,prod_code
            ,acct_type
            ,etl_date
    ) VALUES (
            src.acct_no
            ,src.cust_id
            ,src.org_code
            ,src.currency
            ,src.balance
            ,src.avail_balance
            ,src.status_name
            ,src.open_date
            ,src.open_month
            ,src.last_txn_date
            ,src.frozen_amt
            ,src.mgr_name
            ,src.prod_code
            ,src.acct_type
            ,src.etl_date
    )
;


-- ==== DWD.DWD_ACCT_DAILY_query ====
-- ============================================================
-- 程序名称: QUERY_DWD_ACCT_DAILY
-- 功能描述: 查询 DWD_ACCT_DAILY
-- 源表: DWD.DWD_ACCT_DAILY
-- 目标表: DWD.DWD_ACCT_DAILY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

SELECT
    acct_no  -- 账号
    ,cust_id  -- 客户号
    ,org_code  -- 机构号
    ,currency  -- 币种
    ,balance  -- 余额
    ,avail_balance  -- 可用余额
    ,status_name  -- 账户状态名称
    ,open_date  -- 开户日期
    ,open_month  -- 开户月份
    ,last_txn_date  -- 最后交易日期
    ,frozen_amt  -- 冻结金额
    ,mgr_name  -- 客户经理ID
    ,prod_code  -- 产品代码
    ,acct_type  -- 账户类型
    ,etl_date  -- ETL日期
FROM DWD.DWD_ACCT_DAILY  t
;


-- ==== DWD.DWD_CUST_SUMMARY_ddl ====
-- ============================================================
-- 程序名称: CREATE_DWD_CUST_SUMMARY
-- 功能描述: 客户信息汇总表
-- 源表: ODS.CUST_INFO
-- 目标表: DWD.DWD_CUST_SUMMARY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

CREATE TABLE DWD.DWD_CUST_SUMMARY (
    cust_id  VARCHAR2(18)  PRIMARY KEY  NOT NULL,
    cust_name  VARCHAR2(100)  NOT NULL,
    org_code  VARCHAR2(12)  NOT NULL,
    total_balance  NUMBER(18,2)  NOT NULL,
    acct_count  NUMBER(10)  NOT NULL,
    avg_balance  NUMBER(18,2)  NOT NULL,
    max_balance  NUMBER(18,2)  NOT NULL,
    risk_level_desc  VARCHAR2(20)  NOT NULL,
    create_month  VARCHAR2(6)  NOT NULL,
    etl_date  DATE  NOT NULL
);

COMMENT ON TABLE DWD.DWD_CUST_SUMMARY IS '客户信息汇总表';
COMMENT ON COLUMN DWD.DWD_CUST_SUMMARY.cust_id IS '客户号';
COMMENT ON COLUMN DWD.DWD_CUST_SUMMARY.cust_name IS '客户名称';
COMMENT ON COLUMN DWD.DWD_CUST_SUMMARY.org_code IS '所属机构';
COMMENT ON COLUMN DWD.DWD_CUST_SUMMARY.total_balance IS '总余额';
COMMENT ON COLUMN DWD.DWD_CUST_SUMMARY.acct_count IS '账户数量';
COMMENT ON COLUMN DWD.DWD_CUST_SUMMARY.avg_balance IS '平均余额';
COMMENT ON COLUMN DWD.DWD_CUST_SUMMARY.max_balance IS '最大余额';
COMMENT ON COLUMN DWD.DWD_CUST_SUMMARY.risk_level_desc IS '风险等级描述';
COMMENT ON COLUMN DWD.DWD_CUST_SUMMARY.create_month IS '创建月份';
COMMENT ON COLUMN DWD.DWD_CUST_SUMMARY.etl_date IS 'ETL日期';


-- ==== DWD.DWD_CUST_SUMMARY_dml ====
-- ============================================================
-- 程序名称: ETL_CUST_INFO_TO_DWD_CUST_SUMMARY
-- 功能描述: 从 ODS.CUST_INFO 同步数据到 DWD.DWD_CUST_SUMMARY
-- 源表: ODS.CUST_INFO
-- 目标表: DWD.DWD_CUST_SUMMARY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

INSERT INTO DWD.DWD_CUST_SUMMARY
(
    cust_id
    ,cust_name
    ,org_code
    ,total_balance
    ,acct_count
    ,avg_balance
    ,max_balance
    ,risk_level_desc
    ,create_month
    ,etl_date
)
SELECT
    cust_id  -- 客户号
    ,cust_name  -- 客户名称
    ,org_code  -- 所属机构
    ,SUM(balance)  -- 总余额
    ,COUNT(acct_no)  -- 账户数量
    ,AVG(balance)  -- 平均余额
    ,MAX(balance)  -- 最大余额
    ,CASE WHEN risk_level='H' THEN '高风险'
       ELSE '非高风险'
  END  -- 风险等级描述
    ,TO_CHAR(create_date, 'YYYYMM')  -- 创建月份
    ,etl_date  -- ETL日期
FROM ODS.CUST_INFO  s
;


-- ==== DWD.DWD_CUST_SUMMARY_merge ====
-- ============================================================
-- 程序名称: MERGE_CUST_INFO_TO_DWD_CUST_SUMMARY
-- 功能描述: 增量同步 ODS.CUST_INFO -> DWD.DWD_CUST_SUMMARY
-- 源表: ODS.CUST_INFO
-- 目标表: DWD.DWD_CUST_SUMMARY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

MERGE INTO DWD.DWD_CUST_SUMMARY  t
USING (
    SELECT
            cust_id  -- 客户号
            ,cust_name  -- 客户名称
            ,org_code  -- 所属机构
            ,SUM(balance)  -- 总余额
            ,COUNT(acct_no)  -- 账户数量
            ,AVG(balance)  -- 平均余额
            ,MAX(balance)  -- 最大余额
            ,CASE WHEN risk_level='H' THEN '高风险'
       ELSE '非高风险'
  END  -- 风险等级描述
            ,TO_CHAR(create_date, 'YYYYMM')  -- 创建月份
            ,etl_date  -- ETL日期
    FROM ODS.CUST_INFO  s
)  src

ON (t.cust_id = src.cust_id)
WHEN MATCHED THEN
    UPDATE SET
        t.cust_name = src.cust_name
        ,t.org_code = src.org_code
        ,t.total_balance = src.total_balance
        ,t.acct_count = src.acct_count
        ,t.avg_balance = src.avg_balance
        ,t.max_balance = src.max_balance
        ,t.risk_level_desc = src.risk_level_desc
        ,t.create_month = src.create_month
        ,t.etl_date = src.etl_date
WHEN NOT MATCHED THEN
    INSERT (
            cust_id
            ,cust_name
            ,org_code
            ,total_balance
            ,acct_count
            ,avg_balance
            ,max_balance
            ,risk_level_desc
            ,create_month
            ,etl_date
    ) VALUES (
            src.cust_id
            ,src.cust_name
            ,src.org_code
            ,src.total_balance
            ,src.acct_count
            ,src.avg_balance
            ,src.max_balance
            ,src.risk_level_desc
            ,src.create_month
            ,src.etl_date
    )
;


-- ==== DWD.DWD_CUST_SUMMARY_query ====
-- ============================================================
-- 程序名称: QUERY_DWD_CUST_SUMMARY
-- 功能描述: 查询 DWD_CUST_SUMMARY
-- 源表: DWD.DWD_CUST_SUMMARY
-- 目标表: DWD.DWD_CUST_SUMMARY
-- 创建人: DATA_TEAM
-- 创建日期: 2026-05-08
-- 修改历史:
--   日期        修改人    修改内容
--   ----------  --------  ----------------------------------
-- ============================================================

SELECT
    cust_id  -- 客户号
    ,cust_name  -- 客户名称
    ,org_code  -- 所属机构
    ,total_balance  -- 总余额
    ,acct_count  -- 账户数量
    ,avg_balance  -- 平均余额
    ,max_balance  -- 最大余额
    ,risk_level_desc  -- 风险等级描述
    ,create_month  -- 创建月份
    ,etl_date  -- ETL日期
FROM DWD.DWD_CUST_SUMMARY  t
;

