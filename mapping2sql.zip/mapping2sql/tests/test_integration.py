"""Integration tests — CSV parsing, end-to-end pipeline, and multi-format coverage."""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.parser import MappingParser
from core.generator import SQLGenerator
from core.models import MappingDocument


# ═══════════════════════════════════════════════════════
# CSV Parser
# ═══════════════════════════════════════════════════════

class TestCSVParser:
    def test_parses_csv(self, sample_csv):
        doc = MappingParser().parse(sample_csv)
        assert doc is not None
        assert doc.table_count == 1
        assert doc.total_column_count == 5

    def test_csv_columns_have_types(self, sample_csv):
        doc = MappingParser().parse(sample_csv)
        tm = doc.table_mappings[0]
        types_found = sum(1 for cm in tm.columns if cm.source_type)
        assert types_found >= 3

    def test_csv_pk_detected(self, sample_csv):
        doc = MappingParser().parse(sample_csv)
        tm = doc.table_mappings[0]
        pks = tm.get_pk_columns()
        assert len(pks) == 1
        assert "apply_id" in pks

    def test_csv_transformation_rules(self, sample_csv):
        doc = MappingParser().parse(sample_csv)
        tm = doc.table_mappings[0]
        rules = [cm.transform_rule for cm in tm.columns if cm.transform_rule]
        assert len(rules) >= 1

    def test_csv_to_sql_generation(self, sample_csv):
        """Full pipeline: CSV parse → SQL generation for all types."""
        doc = MappingParser().parse(sample_csv)
        gen = SQLGenerator(dialect="oracle")
        results = gen.generate(doc, sql_type="all")
        assert len(results) == 4  # ddl, dml, merge, query

        for key, sql in results.items():
            assert "{{" not in sql, f"{key}: template leak"
            assert len(sql) > 80, f"{key}: output too short"

        # DML should reference source columns
        dml_key = [k for k in results if k.endswith("_dml")][0]
        assert "apply_id" in results[dml_key]
        assert "cust_name" in results[dml_key]


# ═══════════════════════════════════════════════════════
# End-to-End Integration (xlsx → parse → generate → verify)
# ═══════════════════════════════════════════════════════

class TestEndToEnd:
    """Full pipeline tests using the loan scenario xlsx."""

    @pytest.fixture(scope="module")
    def test_xlsx(self):
        p = Path(__file__).parent.parent / "samples" / "test_loan_scenario.xlsx"
        if not p.exists():
            pytest.skip("test_loan_scenario.xlsx not found")
        return str(p)

    @pytest.fixture(scope="module")
    def parsed_doc(self, test_xlsx):
        return MappingParser().parse(test_xlsx)

    def test_full_pipeline_all_tables_all_types(self, parsed_doc):
        """Parse + generate all types for all tables in one shot."""
        gen = SQLGenerator(dialect="oracle")
        results = gen.generate(parsed_doc, sql_type="all")

        assert len(results) == 12  # 3 tables x 4 types

        for key, sql in results.items():
            # Every statement must be non-empty
            assert len(sql) > 100, f"{key}: output too short"
            # No template leaks
            assert "{{" not in sql, f"{key}: template leak"
            # Ends with semicolon or newline
            assert sql.rstrip().endswith((";", "\n")), f"{key}: not terminated"

    def test_every_target_column_in_dml(self, parsed_doc):
        """Every mapping column must appear in its DML output."""
        gen = SQLGenerator(dialect="oracle")
        for tm in parsed_doc.table_mappings:
            dml = gen.generate_dml(tm, "TEST")
            for cm in tm.columns:
                assert cm.target_column in dml, \
                    f"{cm.target_column} not in DML for {tm.source_table}"

    def test_every_target_column_in_ddl(self, parsed_doc):
        """Every mapping column must appear in its DDL output."""
        gen = SQLGenerator(dialect="oracle")
        for tm in parsed_doc.table_mappings:
            ddl = gen.generate_ddl(tm, "TEST")
            for cm in tm.columns:
                assert cm.target_column in ddl, \
                    f"{cm.target_column} not in DDL for {tm.source_table}"

    def test_ddl_has_composite_pk(self, parsed_doc):
        """Tables with multiple PK columns should have composite PK constraint."""
        gen = SQLGenerator(dialect="oracle")
        for tm in parsed_doc.table_mappings:
            pks = tm.get_pk_columns()
            if len(pks) > 1:
                ddl = gen.generate_ddl(tm, "TEST")
                pk_list = ", ".join(pks)
                assert pk_list in ddl or "PRIMARY KEY" in ddl.upper()

    def test_dml_join_present_for_repay_table(self, parsed_doc):
        """The REPAY table has a JOIN; verify it's in the DML."""
        gen = SQLGenerator(dialect="oracle")
        for tm in parsed_doc.table_mappings:
            if tm.join_conditions:
                dml = gen.generate_dml(tm, "TEST")
                assert "JOIN" in dml.upper(), \
                    f"JOIN not found in DML for {tm.source_table}"

    def test_merge_update_only_non_pk_columns(self, parsed_doc):
        """MERGE UPDATE SET clause should only list non-PK columns."""
        gen = SQLGenerator(dialect="oracle")
        for tm in parsed_doc.table_mappings:
            merge = gen.generate_merge(tm, "TEST")
            pks = tm.get_pk_columns()
            non_pk = [c for c in tm.columns if not c.is_pk]
            for npk in non_pk:
                assert npk.target_column in merge, \
                    f"non-PK {npk.target_column} missing from MERGE UPDATE"

    def test_keywords_uppercased_by_formatter(self, parsed_doc):
        """Formatter should uppercase SQL keywords in output."""
        gen = SQLGenerator(dialect="oracle")
        for tm in parsed_doc.table_mappings:
            dml = gen.generate_dml(tm, "TEST")
            assert "INSERT INTO" in dml
            assert "SELECT" in dml
            assert "FROM" in dml

    def test_oracle_and_mysql_both_generate_valid(self, parsed_doc):
        """Both dialects should produce syntactically valid output."""
        for dialect in ["oracle", "mysql"]:
            gen = SQLGenerator(dialect=dialect)
            results = gen.generate(parsed_doc, sql_type="all")
            assert len(results) == 12

            for key, sql in results.items():
                assert len(sql) > 100, f"{dialect}/{key}: too short"
                assert "{{" not in sql, f"{dialect}/{key}: template leak"

    def test_single_type_generation(self, parsed_doc):
        """Generate only DML should return exactly 3 statements."""
        gen = SQLGenerator(dialect="oracle")
        results = gen.generate(parsed_doc, sql_type="dml")
        assert len(results) == 3
        for key in results:
            assert key.endswith("_dml")

    def test_invalid_sql_type_raises(self, parsed_doc):
        """Requesting an unknown SQL type should raise ValueError."""
        gen = SQLGenerator(dialect="oracle")
        with pytest.raises(ValueError, match="Unsupported SQL type"):
            gen.generate(parsed_doc, sql_type="invalid_type")

    def test_generate_single_method(self, parsed_doc):
        """generate_single should return a single SQL string."""
        gen = SQLGenerator(dialect="oracle")
        tm = parsed_doc.table_mappings[0]
        sql = gen.generate_single(tm, sql_type="ddl")
        assert isinstance(sql, str)
        assert "CREATE TABLE" in sql

    def test_generate_batch_multiple_docs(self, parsed_doc, test_xlsx):
        """generate_batch should handle multiple documents."""
        gen = SQLGenerator(dialect="oracle")
        # Use the same doc twice as a batch test
        all_results = gen.generate_batch([parsed_doc], sql_type="ddl")
        assert len(all_results) == 3  # 3 tables, DDL only

    def test_mapping_document_metadata(self, parsed_doc):
        """Verify parsed document metadata."""
        assert parsed_doc.table_count == 3
        total = parsed_doc.total_column_count
        assert total == 43  # 21 + 12 + 10
