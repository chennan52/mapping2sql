"""LLM 引擎 — 基于 Claude API 实现自然语言到 SQL 的智能转换。

这是整个系统最核心的"智能体"组件。负责将自然语言描述的转换规则（中/英文）
翻译为精确的 SQL 表达式，处理基于正则的解析器无法理解的复杂多条件逻辑。

职责分为三个层次：
  1. 规则翻译 — transform_rule_to_sql()：将中文规则描述转为 SQL 表达式
     （CASE WHEN、聚合函数、类型转换等）
  2. 自由查询生成 — generate_sql_from_natural_language()：将自然语言分析问题
     转为完整的 SQL 查询语句
  3. 对话交互 — chat() + chat_intent()：理解用户意图，生成自然的中文回复

架构要点：
  - 所有 API 调用均传入 thinking={"type": "disabled"}，关闭 Anthropic SDK
    >=0.100.0 默认启用的扩展思考，确保 response.content 中为 TextBlock
  - _extract_text() 安全遍历 content 列表找到文本响应
  - 所有公开方法静默捕获异常，返回安全的兜底值（None / 空字符串 / fallback dict）
"""

import os
import json
import traceback
from typing import Optional


class LLMEngine:
    """自然语言 → SQL 表达式转换引擎，由 Claude 驱动。

    处理以下场景：
    - 复杂多条件 CASE WHEN 逻辑
    - 带自定义分组和过滤的聚合
    - 中文自然语言描述的数据转换
    - 上下文相关的类型转换和日期格式化

    双层策略：
      - 正则规则解析器（utils/rule_parser.py）覆盖 80% 的简单模式
      - LLM 引擎处理剩余 20%：复杂中文描述、多条件逻辑等正则无法可靠解析的场景

    使用示例：
        llm = LLMEngine(api_key="...", model="claude-haiku-4-5-20251001")
        if llm.is_available:
            sql = llm.transform_rule_to_sql("当status=1则为'有效'否则'无效'",
                                             source_column="status")
    """

    # 规则翻译专用系统提示词，约束输出格式为纯 SQL 表达式
    SYSTEM_PROMPT = """You are a bank data warehouse SQL code generation expert. Your task is to convert natural language transformation rule descriptions into precise SQL expressions.

## Rules
1. Output ONLY the SQL expression, no explanation, no markdown code blocks.
2. Use Oracle SQL syntax by default (NVL, TO_CHAR, etc.). Use MySQL syntax if specified.
3. The source column name is provided in context — use it directly.
4. For aggregation rules, return the aggregate function expression.
5. For CASE WHEN rules, return the full CASE...END expression.
6. If the rule says "直接映射" or "direct", return just the column name.
7. For date formatting, return TO_CHAR(col, 'format') for Oracle, DATE_FORMAT(col, 'format') for MySQL.
8. For NULL handling, return NVL(col, default) for Oracle, COALESCE(col, default) for MySQL.
9. For type casting, return CAST(col AS target_type).
10. Keep the expression clean and production-ready."""

    def __init__(self, api_key: str = None, model: str = "claude-haiku-4-5-20251001",
                 base_url: str = None):
        """初始化 LLM 引擎。

        Anthropic 客户端采用延迟加载（见 client 属性），因此初始化不会因为
        SDK 未安装或 key 无效而报错——错误会推迟到实际 API 调用时才暴露。

        Args:
            api_key: Anthropic API 密钥。为 None 时从环境变量 ANTHROPIC_API_KEY 读取。
            model: 使用的 Claude 模型，默认 Haiku（低延迟、低成本）。
                   transform_rule_to_sql 和 chat_intent 使用 self.model；
                   generate_sql_from_natural_language 固定使用 claude-sonnet-4-6
                   以保证复杂查询的生成质量。
            base_url: 自定义 API 地址，用于国内代理（如 https://api.example.com）。
                      为 None 时从环境变量 ANTHROPIC_BASE_URL 读取。
        """
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self.base_url = base_url or os.environ.get("ANTHROPIC_BASE_URL", "")
        self.model = model
        self._client = None
        self.last_error = None       # 最近一次错误信息，用于诊断
        self.attempted = 0           # 成功完成的 LLM 调用次数
        self.failed = 0              # 失败的 LLM 调用次数
        self._connection_ok = None   # 三态：None=未测试, True=正常, False=失败

    @property
    def is_available(self) -> bool:
        """检查 LLM 引擎是否可用。

        同时满足两个条件才返回 True：
          1. 已配置 API Key（通过构造函数、环境变量或连接管理器）
          2. Anthropic 客户端可成功初始化（SDK 已安装、无导入错误）

        整个代码库中，在调用任何 LLM 方法之前都先检查此属性。
        """
        return bool(self.api_key) and self.client is not None

    @property
    def client(self):
        """延迟加载 Anthropic 客户端实例。

        客户端在首次访问时创建，而非 __init__ 中，好处是：
          - 导入错误（SDK 未安装）推迟到实际使用时才暴露
          - 连接参数可在构造后修改
          - 引擎可在没有 key 的情况下实例化（回退到正则解析）

        Returns:
            Anthropic 客户端实例，SDK 未安装或初始化失败时返回 None。
        """
        if self._client is None and self.api_key:
            try:
                from anthropic import Anthropic
                kwargs = {"api_key": self.api_key}
                if self.base_url:
                    kwargs["base_url"] = self.base_url
                self._client = Anthropic(**kwargs)
            except ImportError:
                self.last_error = "anthropic SDK not installed. Run: pip install anthropic"
                return None
            except Exception as e:
                self.last_error = f"Failed to init Anthropic client: {e}"
                return None
        return self._client

    @staticmethod
    def _extract_text(response) -> str:
        """从 Anthropic API 响应中安全提取文本内容。

        Anthropic SDK >=0.100.0 的 response.content 是一个列表，可能包含多种
        块类型（TextBlock、ThinkingBlock 等）。此方法遍历所有块，返回第一个
        type=="text" 的块的文本内容。

        虽然所有 API 调用都传了 thinking={"type": "disabled"}，实际上只会出现
        TextBlock，但此方法提供了额外的防御性保障。

        Args:
            response: Anthropic Messages API 的响应对象。

        Returns:
            第一个文本类型块的文本内容，未找到时返回空字符串。
        """
        for block in response.content:
            if getattr(block, "type", "") == "text":
                return block.text
        return ""

    def test_connection(self) -> tuple[bool, str]:
        """测试 API 连接是否正常，发送一条最小 ping 请求。

        发送 "ping" 消息（max_tokens=10），验证：
          - API Key 有效（不返回 401/403）
          - Base URL 可达（不返回连接/超时错误）
          - 模型可访问（不返回 404）

        结果缓存在 self._connection_ok 中，可通过 get_stats() 查看。

        Returns:
            (success, message) — success 为 True 表示连接正常。
            失败时 message 是中文诊断信息，分类为：认证失败、权限不足、404、
            连接超时、不可达、未知错误。
        """
        if not self.client:
            return False, self.last_error or "No API key configured"

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=10,
                temperature=0.0,
                thinking={"type": "disabled"},
                system="Reply with just 'ok'.",
                messages=[{"role": "user", "content": "ping"}],
            )
            self._connection_ok = True
            return True, f"连接成功 - 模型: {self.model}"
        except Exception as e:
            self._connection_ok = False
            raw = str(e)
            self.last_error = raw
            # 将多行错误信息压缩为单行，便于在 UI 中显示
            flat = " ".join(raw.replace("\r\n", "\n").replace("\r", "\n").split("\n"))
            flat = " ".join(flat.split())[:200]
            # 根据 HTTP 状态码或异常类型分类，给出可操作的中文提示
            if "401" in flat or "Unauthorized" in flat:
                return False, "认证失败 - API Key 无效或已过期"
            elif "403" in flat or "Forbidden" in flat:
                return False, "权限不足 - 请检查 API Key 权限"
            elif "404" in flat or "Not Found" in flat:
                return False, f"接口 404 - URL 可能不正确: {self.base_url or 'official'}"
            elif "timed out" in flat.lower() or "timeout" in flat.lower():
                return False, f"连接超时 - {self.base_url or 'official'} 无响应"
            elif "Connection" in flat or "connect" in flat or "Name or service" in flat:
                return False, f"无法连接 - {self.base_url or 'official'} 不可达"
            elif flat:
                return False, flat
            else:
                return False, "未知错误 - 请检查 Key 和 Base URL"

    def _record_error(self, e: Exception) -> None:
        """记录一次失败的 LLM 调用。

        在所有公开方法的 try/except 中调用，递增失败计数器并保存错误信息。
        只保留前 200 个字符，避免内存无限增长。
        """
        self.failed += 1
        self.last_error = str(e)[:200]

    def _record_success(self) -> None:
        """记录一次成功的 LLM 调用。

        在 API 响应被成功解析和验证后调用，递增成功计数器。
        与 _record_error 配合，为 get_stats() 提供监控数据。
        """
        self.attempted += 1

    def get_stats(self) -> dict:
        """返回引擎使用统计信息，用于诊断和监控。

        使用场景：
          - CLI 输出：生成完成后展示 LLM vs Regex 的统计
          - Web UI：在侧边栏展示连接状态
          - 调试：检查失败次数和最近的错误信息

        Returns:
            包含 attempted、failed、succeeded、last_error、connection_ok、
            model、base_url 的字典。
        """
        return {
            "attempted": self.attempted,
            "failed": self.failed,
            "succeeded": self.attempted - self.failed if self.attempted >= self.failed else 0,
            "last_error": self.last_error,
            "connection_ok": self._connection_ok,
            "model": self.model,
            "base_url": self.base_url or "Anthropic official",
        }

    # ── 第一层：规则翻译 ──────────────────────────────────────────

    def transform_rule_to_sql(
        self,
        rule_text: str,
        source_column: str,
        source_type: str = "",
        target_column: str = "",
        target_type: str = "",
        dialect: str = "oracle",
    ) -> Optional[str]:
        """将单条自然语言转换规则翻译为 SQL 表达式。

        这是 SQL 生成过程中 TransformEngine.transform() 调用的主要方法。
        Mapping 文档中每个字段的「转换规则」列都会经过此方法处理。

        使用 self.model（默认 Haiku），因为这些调用频繁且每次只需生成简短表达式，
        低延迟和低成本比模型能力更重要。

        Args:
            rule_text: Mapping 文档中的自然语言规则，如"当status='A'则为'有效'否则'无效'"
            source_column: 源表字段名，直接用于生成的 SQL 中。
            source_type: 源字段数据类型，为 LLM 提供上下文。
            target_column: 目标字段名，为 LLM 提供上下文。
            target_type: 目标字段数据类型，用于判断是否需要 CAST。
            dialect: "oracle" 或 "mysql"，决定函数名（NVL vs COALESCE 等）。

        Returns:
            SQL 表达式字符串，如 "CASE WHEN s.status='A' THEN '有效' ELSE '无效' END"。
            LLM 不可用或调用失败时返回 None。
        """
        if not self.client:
            return None

        # 构造包含所有可用上下文的结构化提示词，便于 LLM 做出准确的类型转换和方言选择
        user_prompt = f"""Convert this transformation rule to a SQL expression.

Context:
- Source column: {source_column}{f' ({source_type})' if source_type else ''}
- Target column: {target_column}{f' ({target_type})' if target_type else ''}
- Database: {dialect.upper()}

Rule description: {rule_text}

SQL expression:"""

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=200,
                temperature=0.0,               # 规则翻译需要确定性输出
                thinking={"type": "disabled"},  # 必须关闭——SDK 0.100+ 默认启用扩展思考
                system=self.SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_prompt}],
            )

            sql_expr = self._extract_text(response).strip()
            # 清理 LLM 输出中常见的格式问题：
            #   - markdown 行内代码的反引号
            #   - 末尾分号（模板会统一添加）
            #   - markdown 代码块围栏（```）
            sql_expr = sql_expr.strip("`").strip(";").strip()
            if sql_expr.startswith("```"):
                sql_expr = sql_expr.split("\n", 1)[1] if "\n" in sql_expr else sql_expr
                sql_expr = sql_expr.rsplit("\n```", 1)[0] if "```" in sql_expr else sql_expr
                sql_expr = sql_expr.strip()

            if sql_expr:
                self._record_success()
            return sql_expr if sql_expr else None

        except Exception as e:
            self._record_error(e)
            return None

    # ── 第二层：意图识别 ──────────────────────────────────────────

    def chat_intent(self, user_message: str, context: dict) -> dict:
        """解析用户的自然语言消息，输出结构化意图和中文回复。

        这是 Web UI 聊天的「意图路由器」。它同时完成两件事：
          1. 判断用户想做什么（生成、切换方言、下载等）
          2. 生成一个友好的中文回复

        在 app.py 中的调用流程：
          1. 先执行关键词 parse_intent()（快速、始终可用）
          2. 如果关键词结果为 "chat"（闲聊），再调用本方法判断是否有更具体的意图
          3. 返回的 action 驱动后续的机械操作（生成 SQL 等）

        Args:
            user_message: 用户的原始自然语言输入。
            context: 当前会话状态字典，包含：
                has_file, file_name, table_count, column_count,
                dialect, author, history（最近几条对话记录）。

        Returns:
            包含以下键的字典：
                action: "generate" / "generate_query" / "change_dialect" /
                        "show_structure" / "download" / "help" / "chat" / "fallback"
                sql_type: "ddl" / "dml" / "merge" / "query" / "all"（generate 动作时）
                dialect: "oracle" / "mysql"（change_dialect 动作时）
                response: 友好的中文回复字符串（可能为 None）
        """
        if not self.client:
            return {"action": "fallback", "sql_type": "all",
                    "dialect": None, "response": None}

        ctx_str = json.dumps(context, ensure_ascii=False, indent=2)
        prompt = f"""You are Mapping2SQL, a bank data warehouse SQL code generation assistant. Your job is to understand what the user wants and help them.

## Current session state
{ctx_str}

## User message
{user_message}

## Instructions
1. Understand the user's intent. Supported actions:
   - "generate": user wants to generate DDL/DML/MERGE from mapping document. Set sql_type to "ddl"/"dml"/"merge"/"query"/"all".
   - "generate_query": user wants a custom analytical SQL query (JOIN, GROUP BY, aggregate, window function, CASE WHEN, TOP-N, subquery, etc.). This is NOT simple field mapping — the user is describing a complex query scenario in natural language.
   - "change_dialect": user wants to switch to oracle or mysql. Set dialect.
   - "show_structure": user wants to see the parsed mapping columns.
   - "download": user wants to download generated SQL.
   - "help": user asks for help.
   - "chat": casual chat, greeting, or question.

2. Write a warm, professional Chinese response (1-3 sentences). Be specific about what you're doing or what's available.

3. If the user hasn't uploaded a file yet, gently remind them to upload one first (unless they're just saying hello).

4. Key distinction: "generate" = mapping-based (DDL/DML/MERGE from template). "generate_query" = free-form analytical query described in natural language (统计/分析/关联/排名/环比/同比/etc.)

Return ONLY a JSON object (no markdown, no explanation):
{{"action": "<action>", "sql_type": "all", "dialect": null, "response": "<your Chinese reply>"}}"""

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=300,
                temperature=0.3,               # 轻微随机性，使回复更自然
                thinking={"type": "disabled"},
                system="You are a helpful bank data platform assistant. Always reply in Chinese. Output ONLY valid JSON.",
                messages=[{"role": "user", "content": prompt}],
            )

            text = self._extract_text(response).strip()
            # 去除 markdown 代码块围栏（LLM 有时会把 JSON 包在 ```json ... ``` 里）
            if text.startswith("```"):
                text = text.split("\n", 1)[1] if "\n" in text else text
                text = text.rsplit("\n```", 1)[0] if "```" in text else text
                text = text.strip()
            result = json.loads(text)
            self._record_success()
            return result

        except Exception as e:
            self._record_error(e)
            # 返回 fallback——调用方将使用关键词意图匹配的结果
            return {"action": "fallback", "sql_type": "all",
                    "dialect": None, "response": None}

    # ── 第三层：规则分析（诊断用）────────────────────────────────

    def parse_complex_rule(self, rule_text: str, context: dict = None) -> dict:
        """将复杂自然语言规则拆解为结构化语义组件。

        这是一个诊断/分析方法，不直接生成 SQL。它将规则拆解为语义部分
        （条件、THEN 值、ELSE 值等），可用于：
          - 规则校验：检查 LLM 是否正确理解了规则
          - 规则解释：用通俗语言向用户展示每条规则的含义
          - 调试：对比 LLM 的理解与预期 SQL 输出

        目前使用较少，主要是为未来的规则审计和规则解释功能预留的基础能力。

        Args:
            rule_text: 原始转换规则文本。
            context: 可选的附加信息字典（source_column 等）。

        Returns:
            包含 type、field、condition、then_value、else_value、
            aggregate_func、format、default_value、confidence 的字典。
            失败时返回 {"type": "unknown", ...}。
        """
        if not self.client:
            return {"type": "unknown", "expression": rule_text, "explanation": ""}

        context_str = json.dumps(context or {}, ensure_ascii=False, indent=2)
        user_prompt = f"""Analyze this data transformation rule and return JSON:

Rule: {rule_text}
Context: {context_str}

Return ONLY a JSON object with these fields:
{{
    "type": "direct|case_when|aggregate|type_cast|nvl|date_format|constant|unknown",
    "field": "the source field being transformed",
    "condition": "the WHEN condition if case_when",
    "then_value": "the THEN value if case_when",
    "else_value": "the ELSE value if case_when",
    "aggregate_func": "SUM|AVG|COUNT|MAX|MIN if aggregate",
    "format": "date format string if date_format",
    "default_value": "default value if nvl or constant",
    "confidence": 0.0-1.0
}}"""

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=300,
                temperature=0.0,               # 确定性输出——分析而非创造
                thinking={"type": "disabled"},
                system="You are a data mapping expert. Parse rules into structured JSON. Output ONLY JSON, no explanation.",
                messages=[{"role": "user", "content": user_prompt}],
            )

            text = self._extract_text(response).strip()
            # 去除可能存在的 markdown 代码块围栏
            if text.startswith("```"):
                text = text.split("\n", 1)[1] if "\n" in text else text
                text = text.rsplit("\n```", 1)[0] if "```" in text else text
            self._record_success()
            return json.loads(text)

        except Exception as e:
            self._record_error(e)
            return {"type": "unknown", "expression": rule_text, "explanation": ""}

    # ── 对话回复生成 ─────────────────────────────────────────────

    def chat(self, user_message: str, context: dict, action_note: str = "") -> str:
        """生成自然、温暖的中文对话回复。

        这是 Web UI 三阶段处理的最后一步：
          Phase A: parse_intent() + chat_intent() → 确定要做什么
          Phase B: 执行机械操作（生成 SQL、切换方言等）
          Phase C: 本方法 → 将执行结果包装成自然的中文对话

        核心设计理念：chat() 不决定执行什么操作。它接收 action_note 获知
        已经发生的事情，职责纯粹是将结果以友好的方式传达给用户。

        Args:
            user_message: 用户的原始输入（用于上下文理解，不做指令解析）。
            context: 当前会话状态字典，包含：
                has_file, file_name, table_count, column_count, dialect, history。
            action_note: 系统已执行操作的摘要，如 "[系统: 已生成 12 条 全部 SQL]"。
                         无操作时为空字符串。

        Returns:
            自然的中文回复字符串（2-5 句话），失败时返回空字符串。
            调用方在收到空字符串时回退到模板回复。

        提示词设计要点：
          - Temperature 0.7 使对话语气自然多变
          - 明确要求使用「你」而非「您」，更亲切
          - 提供完整会话上下文，使回复具体相关
          - 要求不要机械复述系统操作细节，而是自然融入对话中
        """
        if not self.client:
            return ""

        ctx_str = json.dumps(context, ensure_ascii=False, indent=2)
        history = context.get("history", [])
        # 取最近 4 条对话记录（截断到 300 字符）以保持对话连贯性
        history_str = "\n".join(
            f"{m['role']}: {m['content'][:300]}" for m in history[-4:]
        ) if history else "(no history)"

        prompt = f"""你是一个银行数据中台的智能助手 Mapping2SQL。请根据当前上下文，对用户的消息给出自然、温暖的中文回复。

## 当前会话状态
- 是否已上传文档: {'是' if context.get('has_file') else '否'}
- 文件名: {context.get('file_name', '') or '(无)'}
- 表数量: {context.get('table_count', 0)}
- 字段数量: {context.get('column_count', 0)}
- 数据库方言: {context.get('dialect', 'oracle')}

## 最近对话历史
{history_str}

## 用户消息
{user_message}

## 系统已执行的操作
{action_note or '(无)'}

## 回复要求
- 用自然、温暖的中文回复（2-5 句话）
- 称呼用户为「你」
- 如果系统已生成了 SQL（action_note 里有），告诉用户可以点击展开查看和下载
- 如果用户还没上传文件，温馨提醒一下
- 如果是打招呼或闲聊，友好回应并告诉用户你能做什么
- 可以问用户需要哪种 SQL（DDL/DML/MERGE/Query/全部）
- 不要用"您"，用"你"
- 不要复述系统操作细节，自然地融入回复中

只输出回复内容，不要加任何前缀或标记。"""

        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=400,
                temperature=0.7,               # 较高温度使对话更自然
                thinking={"type": "disabled"},
                system="你是一个银行数据中台的智能助手，名叫 Mapping2SQL。你的回复自然、温暖、专业，像一个乐于助人的同事。始终用中文回复。",
                messages=[{"role": "user", "content": prompt}],
            )
            text = self._extract_text(response).strip()
            self._record_success()
            return text
        except Exception as e:
            self._record_error(e)
            return ""

    # ── 自由查询生成 ─────────────────────────────────────────────

    def generate_sql_from_natural_language(
        self,
        description: str,
        tables: list[str] = None,
        dialect: str = "oracle",
        schema_context: str = "",
    ) -> Optional[str]:
        """根据自然语言描述的分析问题，生成完整、生产可用的 SQL 查询。

        这是比 transform_rule_to_sql() 更高层次的能力。它不是翻译单条字段规则，
        而是生成带有标准格式、中文注释、符合银行数据中台规范的完整多行 SQL 查询。

        固定使用 claude-sonnet-4-6（而非 self.model），原因是：
          - 这类查询通常较复杂（JOIN、GROUP BY、窗口函数、子查询）
          - 质量优先于延迟——这些是面向用户的分析查询
          - 更高的 token 成本由查询的复杂度所证明是值得的

        在 Web UI 中，当 chat_intent() 返回 action="generate_query" 时触发。

        Args:
            description: 查询的自然语言描述，
                         如"统计每个部门的贷款总额，按金额降序，取前10"
            tables: 可用的表名列表，为 LLM 提供上下文。
            dialect: "oracle" 或 "mysql"，决定函数名。
            schema_context: 完整的表/字段 schema markdown 字符串，
                           由 app.py 中的 build_schema_context() 根据解析后的文档生成。

        Returns:
            完整的格式化 SQL 查询字符串，失败时返回 None。
        """
        if not self.client:
            return None

        table_context = f"\nAvailable tables: {', '.join(tables)}" if tables else ""
        schema_block = f"\n\n## Available table schemas:\n{schema_context}" if schema_context else ""

        user_prompt = f"""Generate a {dialect.upper()} SQL query based on this natural language description:

"{description}"{table_context}{schema_block}

Follow bank data platform standards:
- Uppercase SQL keywords (SELECT, FROM, WHERE, JOIN, ON, AND, OR, GROUP BY, ORDER BY, CASE, WHEN, THEN, ELSE, END)
- Leading comma style (comma before each column, not after)
- Each column on its own line
- Chinese comments for each column (-- 注释)
- Standard header comment block (程序名称, 功能描述, 创建人, 创建日期)
- Use meaningful table aliases
- For complex queries, add inline comments explaining key logic
- Oracle syntax: NVL, TO_CHAR, TRUNC, ADD_MONTHS, etc.
- MySQL syntax: COALESCE, DATE_FORMAT, DATE_ADD, etc.

Return ONLY the SQL code, no markdown code blocks, no explanation before or after."""

        try:
            response = self.client.messages.create(
                model="claude-sonnet-4-6",     # 复杂查询生成固定使用 Sonnet
                max_tokens=2000,               # 完整 SQL 查询需要更大的 token 预算
                temperature=0.0,               # SQL 必须正确，不需要创造性
                thinking={"type": "disabled"},
                system=self.SYSTEM_PROMPT + "\n\nGenerate complete, production-ready SQL following bank standards.",
                messages=[{"role": "user", "content": user_prompt}],
            )

            sql = self._extract_text(response).strip()
            # 去除 markdown 代码块围栏（LLM 有时会把 SQL 包在 ```sql ... ``` 里）
            if sql.startswith("```"):
                sql = sql.split("\n", 1)[1] if "\n" in sql else sql
                sql = sql.rsplit("\n```", 1)[0] if "```" in sql else sql
            self._record_success()
            return sql.strip()

        except Exception as e:
            self._record_error(e)
            return None
